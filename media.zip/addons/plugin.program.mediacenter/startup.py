# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:21
import shutil #line:22
import urllib2 ,urllib #line:23
import re #line:24
import uservar #line:25
import time #line:26
import json #line:27
import speedtest #line:28
from shutil import copyfile #line:29
from datetime import date ,datetime ,timedelta #line:30
from resources .libs import extract ,downloader ,downloaderbg ,downloaderwiz ,notify ,loginit ,debridit ,traktit ,maintenance ,skinSwitch ,uploadLog ,wizard as wiz #line:31
ADDON_ID =uservar .ADDON_ID #line:33
ADDONTITLE =uservar .ADDONTITLE #line:34
ADDON =wiz .addonId (ADDON_ID )#line:35
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:36
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:37
ADDONID =wiz .addonInfo (ADDON_ID ,'id')#line:38
DIALOG =xbmcgui .Dialog ()#line:39
DP =xbmcgui .DialogProgress ()#line:40
DP2 =xbmcgui .DialogProgressBG ()#line:41
HOME =xbmc .translatePath ('special://home/')#line:42
PROFILE =xbmc .translatePath ('special://profile/')#line:43
KODIHOME =xbmc .translatePath ('special://xbmc/')#line:44
ADDONS =os .path .join (HOME ,'addons')#line:45
KODIADDONS =os .path .join (KODIHOME ,'addons')#line:46
USERDATA =os .path .join (HOME ,'userdata')#line:47
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:48
PACKAGES =os .path .join (ADDONS ,'packages')#line:49
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:50
FANART =os .path .join (ADDONPATH ,'fanart.jpg')#line:51
ICON =os .path .join (ADDONPATH ,'icon.png')#line:52
ART =os .path .join (ADDONPATH ,'resources','art')#line:53
SKIN =xbmc .getSkinDir ()#line:54
BUILDNAME =wiz .getS ('buildname')#line:55
DEFAULTSKIN =wiz .getS ('defaultskin')#line:56
DEFAULTNAME =wiz .getS ('defaultskinname')#line:57
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:58
BUILDVERSION =wiz .getS ('buildversion')#line:59
BUILDLATEST =wiz .getS ('latestversion')#line:60
BUILDCHECK =wiz .getS ('lastbuildcheck')#line:61
DISABLEUPDATE =wiz .getS ('disableupdate')#line:62
AUTOCLEANUP =wiz .getS ('autoclean')#line:63
AUTOCACHE =wiz .getS ('clearcache')#line:64
AUTOPACKAGES =wiz .getS ('clearpackages')#line:65
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:66
AUTOFEQ =wiz .getS ('autocleanfeq')#line:67
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:68
TRAKTSAVE =wiz .getS ('traktlastsave')#line:69
REALSAVE =wiz .getS ('debridlastsave')#line:70
LOGINSAVE =wiz .getS ('loginlastsave')#line:71
INSTALLMETHOD =wiz .getS ('installmethod')#line:72
KEEPTRAKT =wiz .getS ('keeptrakt')#line:73
KEEPREAL =wiz .getS ('keepdebrid')#line:74
KEEPLOGIN =wiz .getS ('keeplogin')#line:75
INSTALLED =wiz .getS ('installed')#line:76
EXTRACT =wiz .getS ('extract')#line:77
EXTERROR =wiz .getS ('errors')#line:78
NOTIFY =wiz .getS ('notify')#line:79
NOTEDISMISS =wiz .getS ('notedismiss')#line:80
NOTEID =wiz .getS ('noteid')#line:81
NOTIFY2 =wiz .getS ('notify2')#line:82
NOTEDISMISS2 =wiz .getS ('notedismiss2')#line:83
NOTEID2 =wiz .getS ('noteid2')#line:84
NOTIFY3 =wiz .getS ('notify3')#line:85
NOTEDISMISS3 =wiz .getS ('notedismiss3')#line:86
NOTEID3 =wiz .getS ('noteid3')#line:87
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else HOME #line:88
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:89
NOTEID =0 if NOTEID ==""else int (NOTEID )#line:90
NOTEID2 =0 if NOTEID2 ==""else int (NOTEID2 )#line:91
NOTEID3 =0 if NOTEID3 ==""else int (NOTEID3 )#line:92
AUTOFEQ =int (AUTOFEQ )if AUTOFEQ .isdigit ()else 1 #line:93
TODAY =date .today ()#line:94
TOMORROW =TODAY +timedelta (days =1 )#line:95
TWODAYS =TODAY +timedelta (days =2 )#line:96
THREEDAYS =TODAY +timedelta (days =3 )#line:97
ONEWEEK =TODAY +timedelta (days =7 )#line:98
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:99
EXCLUDES =uservar .EXCLUDES #line:100
SPEEDFILE =speedtest .SPEEDFILE #line:101
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:102
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:103
NOTIFICATION =uservar .NOTIFICATION #line:104
NOTIFICATION2 =uservar .NOTIFICATION2 #line:105
NOTIFICATION3 =uservar .NOTIFICATION3 #line:106
ENABLE =uservar .ENABLE #line:107
UNAME =speedtest .UNAME #line:108
HEADERMESSAGE =uservar .HEADERMESSAGE #line:109
AUTOUPDATE =uservar .AUTOUPDATE #line:110
WIZARDFILE =uservar .WIZARDFILE #line:111
AUTOINSTALL =uservar .AUTOINSTALL #line:112
REPOID =uservar .REPOID #line:113
REPOADDONXML =uservar .REPOADDONXML #line:114
REPOZIPURL =uservar .REPOZIPURL #line:115
REPOID18 =uservar .REPOID18 #line:116
REPOADDONXML18 =uservar .REPOADDONXML18 #line:117
REPOZIPURL18 =uservar .REPOZIPURL18 #line:118
COLOR1 =uservar .COLOR1 #line:119
COLOR2 =uservar .COLOR2 #line:120
TMDB_NEW_API =uservar .TMDB_NEW_API #line:121
WORKING =True if wiz .workingURL (SPEEDFILE )==True else False #line:122
FAILED =False #line:123
xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:124
AddonID ='plugin.program.mediacenter'#line:126
packagesdir =xbmc .translatePath (os .path .join ('special://home/addons/packages',''))#line:127
thumbnails =xbmc .translatePath ('special://home/userdata/Thumbnails')#line:128
dialog =xbmcgui .Dialog ()#line:129
setting =xbmcaddon .Addon ().getSetting #line:130
iconpath =xbmc .translatePath (os .path .join ('special://home/addons/'+AddonID ,'icon.png'))#line:131
notify_mode =setting ('notify_mode')#line:132
auto_clean =setting ('startup.cache')#line:133
filesize_thumb =int (setting ('filesizethumb_alert'))#line:135
total_size2 =0 #line:138
total_size =0 #line:139
count =0 #line:140
def disply_hwr ():#line:142
   O000000OOO0000OOO =tmdb_list (TMDB_NEW_API )#line:143
   OOOO00OOOOOOO0OO0 =str ((getHwAddr ('eth0'))*O000000OOO0000OOO )#line:144
   O0O0OO00OOOO00OO0 =(OOOO00OOOOOOO0OO0 [1 ]+OOOO00OOOOOOO0OO0 [2 ]+OOOO00OOOOOOO0OO0 [5 ]+OOOO00OOOOOOO0OO0 [7 ])#line:151
   OOO00OO000000O0OO =(ADDON .getSetting ("action"))#line:152
   wiz .setS ('action',str (O0O0OO00OOOO00OO0 ))#line:154
def getHwAddr (OO000O00O0O000OO0 ):#line:155
   import subprocess ,time #line:156
   O0O000OOO00O0O00O ='windows'#line:157
   if xbmc .getCondVisibility ('system.platform.android'):#line:158
       O0O000OOO00O0O00O ='android'#line:159
   if (O0O000OOO00O0O00O =='android'):#line:160
     OOO00O0O0000O0OOO =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:161
     OO0OO00OO0O0OOOOO =re .compile ('link/ether (.+?) brd').findall (str (OOO00O0O0000O0OOO ))#line:163
     O0O000O0O0OOOOOO0 =0 #line:164
     for OOO000O00OOO00O0O in OO0OO00OO0O0OOOOO :#line:165
      if OO0OO00OO0O0OOOOO !='00:00:00:00:00:00':#line:166
          OOO00O0000O00OOOO =OOO000O00OOO00O0O #line:167
          O0O000O0O0OOOOOO0 =O0O000O0O0OOOOOO0 +int (OOO00O0000O00OOOO .replace (':',''),16 )#line:168
   else :#line:170
       OOOO00OO000OOO0OO =0 #line:171
       O0O000O0O0OOOOOO0 =0 #line:172
       O000O000O0OO0OO0O =[]#line:173
       O0O00000O000O0OOO =os .popen ("getmac").read ()#line:174
       O0O00000O000O0OOO =O0O00000O000O0OOO .split ("\n")#line:175
       for OOO0OOO0OOOOO0O00 in O0O00000O000O0OOO :#line:177
            O0OO0OO0OOOO0OO0O =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',OOO0OOO0OOOOO0O00 ,re .I )#line:178
            if O0OO0OO0OOOO0OO0O :#line:179
                OO0OO00OO0O0OOOOO =O0OO0OO0OOOO0OO0O .group ().replace ('-',':')#line:180
                O000O000O0OO0OO0O .append (OO0OO00OO0O0OOOOO )#line:181
                O0O000O0O0OOOOOO0 =O0O000O0O0OOOOOO0 +int (OO0OO00OO0O0OOOOO .replace (':',''),16 )#line:184
       '''
       while(1):
         mac_address = xbmc.getInfoLabel("network.macaddress")
         logging.warning(mac_address)
         if mac_address!="Busy" and  mac_address!=' עסוק':
    
            break
         else:
           x=x+1
           time.sleep(1)
           if x>30:
            break
       '''#line:198
   return O0O000O0O0OOOOOO0 #line:200
def decode (O0O0OOOO0000O00OO ,O0OO0O0OOOO00O00O ):#line:201
    import base64 #line:202
    OO000OO00OOOOOO00 =[]#line:203
    if (len (O0O0OOOO0000O00OO ))!=4 :#line:205
     return 10 #line:206
    O0OO0O0OOOO00O00O =base64 .urlsafe_b64decode (O0OO0O0OOOO00O00O )#line:207
    for O0O0000OOOOOO00O0 in range (len (O0OO0O0OOOO00O00O )):#line:209
        OOOO0000O000O0OOO =O0O0OOOO0000O00OO [O0O0000OOOOOO00O0 %len (O0O0OOOO0000O00OO )]#line:210
        OO0O00000O0O00O00 =chr ((256 +ord (O0OO0O0OOOO00O00O [O0O0000OOOOOO00O0 ])-ord (OOOO0000O000O0OOO ))%256 )#line:211
        OO000OO00OOOOOO00 .append (OO0O00000O0O00O00 )#line:212
    return "".join (OO000OO00OOOOOO00 )#line:213
def tmdb_list (OO00O00OOOOOO0OO0 ):#line:214
    O00O00O0000O0OO00 =decode ("7643",OO00O00OOOOOO0OO0 )#line:217
    return int (O00O00O0000O0OO00 )#line:220
def u_list (OO0OO00O0OO0OOOO0 ):#line:221
    from math import sqrt #line:223
    O000OO0O0OOOOO0O0 =tmdb_list (TMDB_NEW_API )#line:224
    O0OOOO000OOO0O0OO =str ((getHwAddr ('eth0'))*O000OO0O0OOOOO0O0 )#line:226
    O000OOO0OOO0OO0O0 =int (O0OOOO000OOO0O0OO [1 ]+O0OOOO000OOO0O0OO [2 ]+O0OOOO000OOO0O0OO [5 ]+O0OOOO000OOO0O0OO [7 ])#line:227
    O00O0OOOOOO0000OO =(ADDON .getSetting ("pass"))#line:229
    OO0OOOOOO0OO0O000 =(str (round (sqrt ((O000OOO0OOO0OO0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:234
    if '.'in OO0OOOOOO0OO0O000 :#line:235
     OO0OOOOOO0OO0O000 =(str (round (sqrt ((O000OOO0OOO0OO0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:236
    if O00O0OOOOOO0000OO ==OO0OOOOOO0OO0O000 :#line:237
      OOOO0O0000OO0000O =OO0OO00O0OO0OOOO0 #line:239
    else :#line:241
       if STARTP ()and STARTP2 ()=='ok':#line:242
         return OO0OO00O0OO0OOOO0 #line:244
       OOOO0O0000OO0000O ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:245
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:246
       sys .exit ()#line:247
    return OOOO0O0000OO0000O #line:248
try :#line:249
   disply_hwr ()#line:250
except :#line:251
   pass #line:252
def checkidupdate ():#line:255
				wiz .setS ("notedismiss","true")#line:257
				OO00OO0OO000OOO00 =wiz .workingURL (NOTIFICATION )#line:258
				O00OOOOO00O0O00OO ="Media Center"#line:260
				O00O0O00000O00O0O =wiz .checkBuild (O00OOOOO00O0O00OO ,'gui')#line:261
				OOOO0O0OOO00O00OO =O00OOOOO00O0O00OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:262
				if not wiz .workingURL (O00O0O00000O00O0O )==True :return #line:263
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:264
				O00OO00O0OOOO00OO =os .path .join (PACKAGES ,'%s_guisettings.zip'%OOOO0O0OOO00O00OO )#line:267
				try :os .remove (O00OO00O0OOOO00OO )#line:268
				except :pass #line:269
				if 'google'in O00O0O00000O00O0O :#line:271
				   O0O0OO0OOOO000O00 =googledrive_download (O00O0O00000O00O0O ,O00OO00O0OOOO00OO ,DP2 ,wiz .checkBuild (O00OOOOO00O0O00OO ,'filesize'))#line:272
				else :#line:275
				  downloaderbg .download3 (O00O0O00000O00O0O ,O00OO00O0OOOO00OO ,DP2 )#line:276
				xbmc .sleep (100 )#line:277
				DP2 .create ('[B][COLOR=green]מתקין                         [/COLOR][/B]')#line:278
				DP2 .update (100 ,message ='[B][COLOR=yellow]אנא המתן ...                    [/COLOR][/B]')#line:280
				extract .all (O00OO00O0OOOO00OO ,HOME )#line:282
				DP2 .close ()#line:283
				wiz .defaultSkin ()#line:284
				wiz .lookandFeelData ('save')#line:285
				wiz .kodi17Fix ()#line:286
				xbmc .executebuiltin ("ReloadSkin()")#line:287
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]המערכת עודכנה בהצלחה![/COLOR]'%COLOR2 )#line:288
				debridit .debridIt ('restore','all')#line:289
				traktit .traktIt ('restore','all')#line:290
				if INSTALLMETHOD ==1 :O0OOOO0O0O0O0O000 =1 #line:291
				elif INSTALLMETHOD ==2 :O0OOOO0O0O0O0O000 =0 #line:292
				else :DP2 .close ()#line:293
def checkUpdate ():#line:299
	O0O000OOOO000OOOO =wiz .getS ('buildname')#line:300
	O0OO0O000OO00OOO0 =wiz .getS ('buildversion')#line:301
	O0O00OOO0OO00OOOO =wiz .openURL (SPEEDFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:302
	O0O0OOOOO000OOOOO =re .compile ('name="%s".+?ersion="(.+?)".+?con="(.+?)".+?anart="(.+?)"'%O0O000OOOO000OOOO ).findall (O0O00OOO0OO00OOOO )#line:303
	if len (O0O0OOOOO000OOOOO )>0 :#line:304
		OOOOOOO00O00O0O00 =O0O0OOOOO000OOOOO [0 ][0 ]#line:305
		O00O000OO0OOOO0O0 =O0O0OOOOO000OOOOO [0 ][1 ]#line:306
		OO0000O00O0OOOO0O =O0O0OOOOO000OOOOO [0 ][2 ]#line:307
		wiz .setS ('latestversion',OOOOOOO00O00O0O00 )#line:308
		if OOOOOOO00O00O0O00 >O0OO0O000OO00OOO0 :#line:309
			if DISABLEUPDATE =='false':#line:310
				wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Opening Update Window"%(O0OO0O000OO00OOO0 ,OOOOOOO00O00O0O00 ),xbmc .LOGNOTICE )#line:311
				notify .updateWindow (O0O000OOOO000OOOO ,O0OO0O000OO00OOO0 ,OOOOOOO00O00O0O00 ,O00O000OO0OOOO0O0 ,OO0000O00O0OOOO0O )#line:312
			else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s] Update Window Disabled"%(O0OO0O000OO00OOO0 ,OOOOOOO00O00O0O00 ),xbmc .LOGNOTICE )#line:313
		else :wiz .log ("[Check Updates] [Installed Version: %s] [Current Version: %s]"%(O0OO0O000OO00OOO0 ,OOOOOOO00O00O0O00 ),xbmc .LOGNOTICE )#line:314
	else :wiz .log ("[Check Updates] ERROR: Unable to find build version in build text file",xbmc .LOGERROR )#line:315
wiz .log ("[Auto Update Wizard] Started",xbmc .LOGNOTICE )#line:350
if AUTOUPDATE =='Yes':#line:351
	input =(ADDON .getSetting ("autoupdate"))#line:352
	xbmc .executebuiltin ("UpdateLocalAddons")#line:353
	xbmc .executebuiltin ("UpdateAddonRepos")#line:354
	wiz .wizardUpdate ('startup')#line:355
	checkUpdate ()#line:357
else :wiz .log ("[Auto Update Wizard] Not Enabled",xbmc .LOGNOTICE )#line:359
wiz .log ("[Auto Install Repo] Started",xbmc .LOGNOTICE )#line:363
if AUTOINSTALL =='No'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=17 and KODIV <18 :#line:364
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Mediacenter','Please Wait....')))#line:365
	workingxml =wiz .workingURL (REPOADDONXML )#line:366
	if workingxml ==True :#line:367
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML ),'addon',ret ='version',attrs ={'id':REPOID })#line:368
		if len (ver )>0 :#line:369
			installzip ='%s-%s.zip'%(REPOID ,ver [0 ])#line:370
			workingrepo =wiz .workingURL (REPOZIPURL +installzip )#line:371
			if workingrepo ==True :#line:372
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:373
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:374
				lib =os .path .join (PACKAGES ,installzip )#line:375
				try :os .remove (lib )#line:376
				except :pass #line:377
				downloader .download (REPOZIPURL +installzip ,lib ,DP )#line:378
				extract .all (lib ,ADDONS ,DP )#line:379
				try :#line:380
					f =open (os .path .join (ADDONS ,REPOID ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:381
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID })#line:382
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID ,'icon.png'))#line:383
				except :#line:384
					pass #line:385
				if KODIV >=17 :wiz .addonDatabase (REPOID ,1 )#line:386
				DP .close ()#line:387
				xbmc .sleep (500 )#line:388
				wiz .forceUpdate (True )#line:389
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:390
				xbmc .executebuiltin ("ReloadSkin()")#line:391
				xbmc .executebuiltin ("ActivateWindow(home)")#line:392
			else :#line:395
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:396
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:397
		else :#line:398
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:399
	else :#line:400
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:401
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:402
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:403
elif os .path .exists (os .path .join (ADDONS ,REPOID )):wiz .log ("[Auto Install Repo] Repository already installed")#line:404
if AUTOINSTALL =='No'and not os .path .exists (os .path .join (ADDONS ,REPOID ))and KODIV >=18 :#line:407
	workingxml =wiz .workingURL (REPOADDONXML18 )#line:408
	xbmc .executebuiltin ((u'Notification(%s,%s)'%('Mediacenter','Please Wait....')))#line:409
	if BUILDNAME =="":#line:410
		try :#line:411
			os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:412
		except :#line:413
				pass #line:414
	if workingxml ==True :#line:415
		ver =wiz .parseDOM (wiz .openURL (REPOADDONXML18 ),'addon',ret ='version',attrs ={'id':REPOID18 })#line:416
		if len (ver )>0 :#line:417
			installzip ='%s-%s.zip'%(REPOID18 ,ver [0 ])#line:418
			workingrepo =wiz .workingURL (REPOZIPURL18 +installzip )#line:419
			if workingrepo ==True :#line:420
				DP .create (ADDONTITLE ,'מוריד ממשק התקנה חדשני, אנא המתן....','','Please Wait')#line:421
				if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:422
				lib =os .path .join (PACKAGES ,installzip )#line:423
				try :os .remove (lib )#line:424
				except :pass #line:425
				downloader .download (REPOZIPURL18 +installzip ,lib ,DP )#line:426
				extract .all (lib ,ADDONS ,DP )#line:427
				try :#line:428
					f =open (os .path .join (ADDONS ,REPOID18 ,'addon.xml'),mode ='r');g =f .read ();f .close ()#line:429
					name =wiz .parseDOM (g ,'addon',ret ='name',attrs ={'id':REPOID18 })#line:430
					wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,name [0 ]),"[COLOR %s]Add-on updated[/COLOR]"%COLOR2 ,icon =os .path .join (ADDONS ,REPOID18 ,'icon.png'))#line:431
				except :#line:432
					pass #line:433
				if KODIV >=17 :wiz .addonDatabase (REPOID18 ,1 )#line:434
				DP .close ()#line:435
				xbmc .sleep (500 )#line:436
				wiz .forceUpdate (True )#line:437
				wiz .log ("[Auto Install Repo] Successfully Installed",xbmc .LOGNOTICE )#line:438
				xbmc .executebuiltin ("ReloadSkin()")#line:439
				xbmc .executebuiltin ("ActivateWindow(home)")#line:440
			else :#line:443
				wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid url for zip![/COLOR]"%COLOR2 )#line:444
				wiz .log ("[Auto Install Repo] Was unable to create a working url for repository. %s"%workingrepo ,xbmc .LOGERROR )#line:445
		else :#line:446
			wiz .log ("Invalid URL for Repo Zip",xbmc .LOGERROR )#line:447
	else :#line:448
		wiz .LogNotify ("[COLOR %s]Repo Install Error[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid addon.xml file![/COLOR]"%COLOR2 )#line:449
		wiz .log ("[Auto Install Repo] Unable to read the addon.xml file.",xbmc .LOGERROR )#line:450
elif not AUTOINSTALL =='Yes':wiz .log ("[Auto Install Repo] Not Enabled",xbmc .LOGNOTICE )#line:452
elif os .path .exists (os .path .join (ADDONS ,REPOID18 )):wiz .log ("[Auto Install Repo] Repository already installed")#line:453
def setuname ():#line:454
    O0OOOO0OO00O000OO =''#line:455
    O0O00O0OO0O000000 =xbmc .Keyboard (O0OOOO0OO00O000OO ,'הכנס שם משתמש')#line:456
    O0O00O0OO0O000000 .doModal ()#line:457
    if O0O00O0OO0O000000 .isConfirmed ():#line:458
           O0OOOO0OO00O000OO =O0O00O0OO0O000000 .getText ()#line:459
           wiz .setS ('user',str (O0OOOO0OO00O000OO ))#line:460
def STARTP2 ():#line:461
	if BUILDNAME =="Media Center":#line:462
		OOO00O000000OO00O =(ADDON .getSetting ("user"))#line:463
		O00000OOOOOOOOOO0 =(UNAME )#line:464
		OOOO0OO0O0O000OO0 =urllib2 .urlopen (O00000OOOOOOOOOO0 )#line:465
		OO000O0O0OOOOO0O0 =OOOO0OO0O0O000OO0 .readlines ()#line:466
		if not OOO00O000000OO00O +'\r\n'in OO000O0O0OOOOO0O0 :#line:467
			O0O0000O000OOO0O0 =DIALOG .yesno ("%s"%ADDONTITLE ,"[COLOR %s]ברוכים הבאים"%(COLOR2 ),"נא להכניס את שם המשתמש שלכם[/COLOR]",nolabel ='[B][COLOR white]ביטול[/COLOR][/B]',yeslabel ='[B][COLOR green]אישור[/COLOR][/B]')#line:468
			if O0O0000O000OOO0O0 :#line:470
				ADDON .openSettings ()#line:471
				sys .exit ()#line:472
			else :#line:473
				sys .exit ()#line:474
		return 'ok'#line:478
def skinWIN ():#line:481
	idle ()#line:482
	O0OOOOOO00OO0000O =glob .glob (os .path .join (ADDONS ,'skin*'))#line:483
	OOOOOO0O000O0OOO0 =[];OO000O00O00OOOO0O =[]#line:484
	for O0O0OOO00O00O00O0 in sorted (O0OOOOOO00OO0000O ,key =lambda O00O0O00O00OO000O :O00O0O00O00OO000O ):#line:485
		O0O0OOO00O0OO0000 =os .path .split (O0O0OOO00O00O00O0 [:-1 ])[1 ]#line:486
		O0OO00OOO0O0O00OO =os .path .join (O0O0OOO00O00O00O0 ,'addon.xml')#line:487
		if os .path .exists (O0OO00OOO0O0O00OO ):#line:488
			OO000OOO0OOO0O00O =open (O0OO00OOO0O0O00OO )#line:489
			OOO000O00O00O0OOO =OO000OOO0OOO0O00O .read ()#line:490
			OO0OOOO0O000OO000 =parseDOM2 (OOO000O00O00O0OOO ,'addon',ret ='id')#line:491
			O0OO0O000O00O000O =O0O0OOO00O0OO0000 if len (OO0OOOO0O000OO000 )==0 else OO0OOOO0O000OO000 [0 ]#line:492
			try :#line:493
				O0O0OOOO0O0OO0000 =xbmcaddon .Addon (id =O0OO0O000O00O000O )#line:494
				OOOOOO0O000O0OOO0 .append (O0O0OOOO0O0OO0000 .getAddonInfo ('name'))#line:495
				OO000O00O00OOOO0O .append (O0OO0O000O00O000O )#line:496
			except :#line:497
				pass #line:498
	O0OO0OOOOOOO0O000 =[];O000O0O00000O0OO0 =0 #line:499
	O00O0OOOOO000OO00 =["Current Skin -- %s"%currSkin ()]+OOOOOO0O000O0OOO0 #line:500
	O000O0O00000O0OO0 =DIALOG .select ("Select the Skin you want to swap with.",O00O0OOOOO000OO00 )#line:501
	if O000O0O00000O0OO0 ==-1 :return #line:502
	else :#line:503
		OO00OO00OOO000000 =(O000O0O00000O0OO0 -1 )#line:504
		O0OO0OOOOOOO0O000 .append (OO00OO00OOO000000 )#line:505
		O00O0OOOOO000OO00 [O000O0O00000O0OO0 ]="%s"%(OOOOOO0O000O0OOO0 [OO00OO00OOO000000 ])#line:506
	if O0OO0OOOOOOO0O000 ==None :return #line:507
	for O00O0OO00OOOOO0O0 in O0OO0OOOOOOO0O000 :#line:508
		swapSkins (OO000O00O00OOOO0O [O00O0OO00OOOOO0O0 ])#line:509
def currSkin ():#line:511
	return xbmc .getSkinDir ('Container.PluginName')#line:512
def fix17update ():#line:514
	if KODIV >=17 and KODIV <18 :#line:515
		wiz .kodi17Fix ()#line:516
		xbmc .sleep (4000 )#line:517
		try :#line:518
			O0OO0OO0OOOOO00O0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:519
			O00OOO00OO0OOOO00 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:520
			os .rename (O0OO0OO0OOOOO00O0 ,O00OOO00OO0OOOO00 )#line:521
		except :#line:522
				pass #line:523
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:524
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:525
		fixfont ()#line:526
		O000O0OOOOO0000OO =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:527
		try :#line:529
			O0O0OOOO000000000 =open (O000O0OOOOO0000OO ,'r')#line:530
			O00O0O000000OO0OO =O0O0OOOO000000000 .read ()#line:531
			O0O0OOOO000000000 .close ()#line:532
			O00O0OO0O0O0O0OOO ='<import addon="xbmc.gui" version="5.14.0(.+?)/>'#line:533
			O000O00OO000O00O0 =re .compile (O00O0OO0O0O0O0OOO ).findall (O00O0O000000OO0OO )[0 ]#line:534
			O0O0OOOO000000000 =open (O000O0OOOOO0000OO ,'w')#line:535
			O0O0OOOO000000000 .write (O00O0O000000OO0OO .replace ('<import addon="xbmc.gui" version="5.14.0%s/>'%O000O00OO000O00O0 ,'<import addon="xbmc.gui" version="5.12.0"/>'))#line:536
			O0O0OOOO000000000 .close ()#line:537
		except :#line:538
				pass #line:539
		wiz .kodi17Fix ()#line:540
		O000O0OOOOO0000OO =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:541
		try :#line:542
			O0O0OOOO000000000 =open (O000O0OOOOO0000OO ,'r')#line:543
			O00O0O000000OO0OO =O0O0OOOO000000000 .read ()#line:544
			O0O0OOOO000000000 .close ()#line:545
			O00O0OO0O0O0O0OOO ='<keyboardlayouts default="true(.+?)/keyboardlayouts>'#line:546
			O000O00OO000O00O0 =re .compile (O00O0OO0O0O0O0OOO ).findall (O00O0O000000OO0OO )[0 ]#line:547
			O0O0OOOO000000000 =open (O000O0OOOOO0000OO ,'w')#line:548
			O0O0OOOO000000000 .write (O00O0O000000OO0OO .replace ('<keyboardlayouts default="true%s/keyboardlayouts>'%O000O00OO000O00O0 ,'<keyboardlayouts>English QWERTY|Hebrew QWERTY</keyboardlayouts>'))#line:549
			O0O0OOOO000000000 .close ()#line:550
		except :#line:551
				pass #line:552
		swapSkins ('skin.Premium.mod')#line:553
	xbmcgui .Dialog ().ok ("Fix",'גירסת הקודי אינה תואמת את גירסת הבילד, לתיקון הבעיה נא ללחוץ אישור. הקודי יסגר לאחר הפעולה.')#line:554
	os ._exit (1 )#line:555
def fix18update ():#line:556
	if KODIV >=18 :#line:557
		xbmc .sleep (4000 )#line:558
		if BUILDNAME =="":#line:559
			try :#line:560
				os .remove (os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db"))#line:561
			except :#line:562
				pass #line:563
		try :#line:564
			OO00O0000O00O0OO0 =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos107.db")#line:565
			OOO0O0O0O0OOOOOOO =os .path .join (xbmc .translatePath ("special://userdata/"),"Database","MyVideos116.db")#line:566
			os .rename (OO00O0000O00O0OO0 ,OOO0O0O0O0OOOOOOO )#line:567
		except :#line:568
				pass #line:569
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"locale.language","value":"resource.language.he_il"}}')#line:570
		xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"subtitles.font","value":"ntkl.ttf"}}')#line:571
		fixfont ()#line:572
		OOO0O0000OO000OO0 =os .path .join (xbmc .translatePath ("special://home/"),"addons","skin.Premium.mod","addon.xml")#line:573
		try :#line:574
			O00OOOOO0O0O0O000 =open (OOO0O0000OO000OO0 ,'r')#line:575
			O0OOO00O0OOOO0OOO =O00OOOOO0O0O0O000 .read ()#line:576
			O00OOOOO0O0O0O000 .close ()#line:577
			O00OOOOO00OO0OO00 ='<import addon="xbmc.gui" version="5.12.0(.+?)/>'#line:578
			OOO000000O0000O0O =re .compile (O00OOOOO00OO0OO00 ).findall (O0OOO00O0OOOO0OOO )[0 ]#line:579
			O00OOOOO0O0O0O000 =open (OOO0O0000OO000OO0 ,'w')#line:580
			O00OOOOO0O0O0O000 .write (O0OOO00O0OOOO0OOO .replace ('<import addon="xbmc.gui" version="5.12.0%s/>'%OOO000000O0000O0O ,'<import addon="xbmc.gui" version="5.14.0"/>'))#line:581
			O00OOOOO0O0O0O000 .close ()#line:582
		except :#line:583
				pass #line:584
		wiz .kodi17Fix ()#line:585
		OOO0O0000OO000OO0 =os .path .join (xbmc .translatePath ("special://userdata"),"guisettings.xml")#line:586
		try :#line:587
			O00OOOOO0O0O0O000 =open (OOO0O0000OO000OO0 ,'r')#line:588
			O0OOO00O0OOOO0OOO =O00OOOOO0O0O0O000 .read ()#line:589
			O00OOOOO0O0O0O000 .close ()#line:590
			O00OOOOO00OO0OO00 ='<setting id="locale.keyboardlayouts" default="true(.+?)/setting>'#line:591
			OOO000000O0000O0O =re .compile (O00OOOOO00OO0OO00 ).findall (O0OOO00O0OOOO0OOO )[0 ]#line:592
			O00OOOOO0O0O0O000 =open (OOO0O0000OO000OO0 ,'w')#line:593
			O00OOOOO0O0O0O000 .write (O0OOO00O0OOOO0OOO .replace ('<setting id="locale.keyboardlayouts" default="true%s/setting>'%OOO000000O0000O0O ,'<setting id="locale.keyboardlayouts">English QWERTY|Hebrew QWERTY</setting>'))#line:594
			O00OOOOO0O0O0O000 .close ()#line:595
		except :#line:596
				pass #line:597
		swapSkins ('skin.Premium.mod')#line:598
	xbmcgui .Dialog ().ok ("Fix",'לחץ אישור')#line:599
	os ._exit (1 )#line:600
def swapSkins (O0O00O0OOOOO00O00 ,title ="Error"):#line:601
	O00OO0OO0OOO0OOO0 ='lookandfeel.skin'#line:602
	OOO0O0OOO0OOO0000 =O0O00O0OOOOO00O00 #line:603
	O00000O0O0O0OO0OO =getOld (O00OO0OO0OOO0OOO0 )#line:604
	O0O00O00OOO0OOOO0 =O00OO0OO0OOO0OOO0 #line:605
	setNew (O0O00O00OOO0OOOO0 ,OOO0O0OOO0OOO0000 )#line:606
	OOO00O00O0OO000OO =0 #line:607
	while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and OOO00O00O0OO000OO <100 :#line:608
		OOO00O00O0OO000OO +=1 #line:609
		xbmc .sleep (1 )#line:610
	if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:611
		xbmc .executebuiltin ('SendClick(11)')#line:612
	return True #line:613
def getOld (OO0O00O0O00OO0000 ):#line:615
	try :#line:616
		OO0O00O0O00OO0000 ='"%s"'%OO0O00O0O00OO0000 #line:617
		OO00OOOOOO00O00O0 ='{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}'%(OO0O00O0O00OO0000 )#line:618
		O0O00O00O000O000O =xbmc .executeJSONRPC (OO00OOOOOO00O00O0 )#line:620
		O0O00O00O000O000O =simplejson .loads (O0O00O00O000O000O )#line:621
		if O0O00O00O000O000O .has_key ('result'):#line:622
			if O0O00O00O000O000O ['result'].has_key ('value'):#line:623
				return O0O00O00O000O000O ['result']['value']#line:624
	except :#line:625
		pass #line:626
	return None #line:627
def setNew (O00OO0O00O0000O00 ,O0OO0O000O0O0O0OO ):#line:630
	try :#line:631
		O00OO0O00O0000O00 ='"%s"'%O00OO0O00O0000O00 #line:632
		O0OO0O000O0O0O0OO ='"%s"'%O0OO0O000O0O0O0OO #line:633
		O0O0O000OOOO0OO00 ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}'%(O00OO0O00O0000O00 ,O0OO0O000O0O0O0OO )#line:634
		OO0O0OOO00O0OO0OO =xbmc .executeJSONRPC (O0O0O000OOOO0OO00 )#line:636
	except :#line:637
		pass #line:638
	return None #line:639
def idle ():#line:640
	return xbmc .executebuiltin ('Dialog.Close(busydialog)')#line:641
def fixfont ():#line:642
	O000OOOOOOO000O00 =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.GetSettings","id":1}')#line:643
	OOOOOO0OOO000OOO0 =json .loads (O000OOOOOOO000O00 );#line:645
	OOO0000O0000OOO00 =OOOOOO0OOO000OOO0 ["result"]["settings"]#line:646
	O00O00O0OO0OOOO0O =[O0OOO00O00OOO00O0 for O0OOO00O00OOO00O0 in OOO0000O0000OOO00 if O0OOO00O00OOO00O0 ["id"]=="audiooutput.audiodevice"][0 ]#line:648
	OOOOO0OO0O0OO00OO =O00O00O0OO0OOOO0O ["options"];#line:649
	O000OOOO00OOO0000 =O00O00O0OO0OOOO0O ["value"];#line:650
	O0O0OO0O0OO00000O =[O00OOOO000O0000OO for (O00OOOO000O0000OO ,OO0O000OOO0OOO000 )in enumerate (OOOOO0OO0O0OO00OO )if OO0O000OOO0OOO000 ["value"]==O000OOOO00OOO0000 ][0 ];#line:652
	OO000OO000OO0O000 =(O0O0OO0O0OO00000O +1 )%len (OOOOO0OO0O0OO00OO )#line:654
	O0OO00OO000000OOO =OOOOO0OO0O0OO00OO [OO000OO000OO0O000 ]["value"]#line:656
	O0OO00000000O0OO0 =OOOOO0OO0O0OO00OO [OO000OO000OO0O000 ]["label"]#line:657
	O0OO00O00OOO0O00O =xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":40},"id":1}')#line:659
	try :#line:661
		O00OO0000O0O000OO =json .loads (O0OO00O00OOO0O00O );#line:662
		if O00OO0000O0O000OO ["result"]!=True :#line:664
			raise Exception #line:665
	except :#line:666
		sys .stderr .write ("Error switching audio output device")#line:667
		raise Exception #line:668
def checkSkin ():#line:671
	wiz .log ("[Build Check] Invalid Skin Check Start")#line:672
	OOO0O00O000000OOO =wiz .getS ('defaultskin')#line:673
	OOOO00OOO0OOO00O0 =wiz .getS ('defaultskinname')#line:674
	OO0OO0OO0OOOOOOO0 =wiz .getS ('defaultskinignore')#line:675
	O00OOO0OO00O00OO0 =False #line:676
	if not OOO0O00O000000OOO =='':#line:677
		if os .path .exists (os .path .join (ADDONS ,OOO0O00O000000OOO )):#line:678
			if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to set the skin back to:[/COLOR]",'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO00OOO0OOO00O0 )):#line:679
				O00OOO0OO00O00OO0 =OOO0O00O000000OOO #line:680
				OO00000OOOO00OO0O =OOOO00OOO0OOO00O0 #line:681
			else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true');O00OOO0OO00O00OO0 =False #line:682
		else :wiz .setS ('defaultskin','');wiz .setS ('defaultskinname','');OOO0O00O000000OOO ='';OOOO00OOO0OOO00O0 =''#line:683
	if OOO0O00O000000OOO =='':#line:684
		O00OOOOO00OOOO00O =[]#line:685
		OOOOOO0O000000OO0 =[]#line:686
		for O00OOO0O0OO000O0O in glob .glob (os .path .join (ADDONS ,'skin.*/')):#line:687
			O000O00OOOOOOO000 ="%s/addon.xml"%O00OOO0O0OO000O0O #line:688
			if os .path .exists (O000O00OOOOOOO000 ):#line:689
				OO0OO00OO0OO0OOO0 =open (O000O00OOOOOOO000 ,mode ='r');O0000O0OO00000O0O =OO0OO00OO0OO0OOO0 .read ().replace ('\n','').replace ('\r','').replace ('\t','');OO0OO00OO0OO0OOO0 .close ();#line:690
				OO00OO000OO00O0O0 =wiz .parseDOM (O0000O0OO00000O0O ,'addon',ret ='id')#line:691
				OO0O0O0OOO0OOO0OO =wiz .parseDOM (O0000O0OO00000O0O ,'addon',ret ='name')#line:692
				wiz .log ("%s: %s"%(O00OOO0O0OO000O0O ,str (OO00OO000OO00O0O0 [0 ])),xbmc .LOGNOTICE )#line:693
				if len (OO00OO000OO00O0O0 )>0 :OOOOOO0O000000OO0 .append (str (OO00OO000OO00O0O0 [0 ]));O00OOOOO00OOOO00O .append (str (OO0O0O0OOO0OOO0OO [0 ]))#line:694
				else :wiz .log ("ID not found for %s"%O00OOO0O0OO000O0O ,xbmc .LOGNOTICE )#line:695
			else :wiz .log ("ID not found for %s"%O00OOO0O0OO000O0O ,xbmc .LOGNOTICE )#line:696
		if len (OOOOOO0O000000OO0 )>0 :#line:697
			if len (OOOOOO0O000000OO0 )>1 :#line:698
				if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that the skin has been set back to [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,SKIN [5 :].title ()),"Would you like to view a list of avaliable skins?[/COLOR]"):#line:699
					OOOOO0OOO0OOOO0O0 =DIALOG .select ("Select skin to switch to!",O00OOOOO00OOOO00O )#line:700
					if OOOOO0OOO0OOOO0O0 ==-1 :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:701
					else :#line:702
						O00OOO0OO00O00OO0 =OOOOOO0O000000OO0 [OOOOO0OOO0OOOO0O0 ]#line:703
						OO00000OOOO00OO0O =O00OOOOO00OOOO00O [OOOOO0OOO0OOOO0O0 ]#line:704
				else :wiz .log ("Skin was not reset",xbmc .LOGNOTICE );wiz .setS ('defaultskinignore','true')#line:705
	if O00OOO0OO00O00OO0 :#line:712
		skinSwitch .swapSkins (O00OOO0OO00O00OO0 )#line:713
		O0OOOO0OO00O0O0OO =0 #line:714
		xbmc .sleep (1000 )#line:715
		while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOOO0OO00O0O0OO <150 :#line:716
			O0OOOO0OO00O0O0OO +=1 #line:717
			xbmc .sleep (200 )#line:718
		if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:720
			wiz .ebi ('SendClick(11)')#line:721
			wiz .lookandFeelData ('restore')#line:722
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Skin Swap Timed Out![/COLOR]'%COLOR2 )#line:723
	wiz .log ("[Build Check] Invalid Skin Check End",xbmc .LOGNOTICE )#line:724
while xbmc .Player ().isPlayingVideo ():#line:726
	xbmc .sleep (1000 )#line:727
if KODIV >=17 :#line:729
	NOW =datetime .now ()#line:730
	temp =wiz .getS ('kodi17iscrap')#line:731
	if not temp =='':#line:732
		if temp >str (NOW -timedelta (minutes =2 )):#line:733
			wiz .log ("Killing Start Up Script")#line:734
			sys .exit ()#line:735
	wiz .log ("%s"%(NOW ))#line:736
	wiz .setS ('kodi17iscrap',str (NOW ))#line:737
	xbmc .sleep (1000 )#line:738
	if not wiz .getS ('kodi17iscrap')==str (NOW ):#line:739
		wiz .log ("Killing Start Up Script")#line:740
		sys .exit ()#line:741
	else :#line:742
		wiz .log ("Continuing Start Up Script")#line:743
wiz .log ("[Path Check] Started",xbmc .LOGNOTICE )#line:745
path =os .path .split (ADDONPATH )#line:746
if not ADDONID ==path [1 ]:DIALOG .ok (ADDONTITLE ,'[COLOR %s]Please make sure that the plugin folder is the same as the ADDON_ID.[/COLOR]'%COLOR2 ,'[COLOR %s]Plugin ID:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,ADDONID ),'[COLOR %s]Plugin Folder:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,path ));wiz .log ("[Path Check] ADDON_ID and plugin folder doesnt match. %s / %s "%(ADDONID ,path ))#line:747
else :wiz .log ("[Path Check] Good!",xbmc .LOGNOTICE )#line:748
if KODIADDONS in ADDONPATH :#line:751
	wiz .log ("Copying path to addons dir",xbmc .LOGNOTICE )#line:752
	if not os .path .exists (ADDONS ):os .makedirs (ADDONS )#line:753
	newpath =xbmc .translatePath (os .path .join ('special://home/addons/',ADDONID ))#line:754
	if os .path .exists (newpath ):#line:755
		wiz .log ("Folder already exists, cleaning House",xbmc .LOGNOTICE )#line:756
		wiz .cleanHouse (newpath )#line:757
		wiz .removeFolder (newpath )#line:758
	try :#line:759
		wiz .copytree (ADDONPATH ,newpath )#line:760
	except Exception as e :#line:761
		pass #line:762
	wiz .forceUpdate (True )#line:763
try :#line:765
	mybuilds =xbmc .translatePath (MYBUILDS )#line:766
	if not os .path .exists (mybuilds ):xbmcvfs .mkdirs (mybuilds )#line:767
except :#line:768
	pass #line:769
wiz .log ("[Installed Check] Started",xbmc .LOGNOTICE )#line:771
if KODIV >=17 and SKIN in ['skin.confluence','skin.estuary']and not BUILDNAME =="":#line:775
			wiz .kodi17Fix ()#line:776
			fix18update ()#line:777
			fix17update ()#line:778
if INSTALLED =='true':#line:781
    input =(ADDON .getSetting ("rdbuild"))#line:782
    if KEEPTRAKT =='true':traktit .traktIt ('restore','all');wiz .log ('[Installed Check] Restoring Trakt Data',xbmc .LOGNOTICE )#line:784
    if KEEPREAL =='true':debridit .debridIt ('restore','all');wiz .log ('[Installed Check] Restoring Real Debrid Data',xbmc .LOGNOTICE )#line:785
    if input =='true':loginit .loginIt ('restore','all');wiz .log ('[Installed Check] Restoring Login Data',xbmc .LOGNOTICE )#line:786
    wiz .clearS ('install')#line:787
wiz .log ("[Notifications] Started",xbmc .LOGNOTICE )#line:872
if ENABLE =='Yes'and BUILDNAME =="Media Center":#line:874
	input =(ADDON .getSetting ("autoupdate"))#line:875
	if not NOTIFY =='true':#line:876
		url =wiz .workingURL (NOTIFICATION )#line:877
		if url ==True :#line:878
			id ,msg =wiz .splitNotify (NOTIFICATION )#line:879
			if not id ==False :#line:880
				try :#line:881
					id =int (id );NOTEID =int (NOTEID )#line:882
					if id ==NOTEID :#line:883
						if NOTEDISMISS =='false':#line:884
							debridit .debridIt ('update','all')#line:885
							traktit .traktIt ('update','all')#line:886
							checkidupdate ()#line:887
						else :wiz .log ("[Notifications] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:888
					elif id >NOTEID :#line:889
						wiz .log ("[Notifications] id: %s"%str (id ),xbmc .LOGNOTICE )#line:890
						wiz .setS ('noteid',str (id ))#line:891
						wiz .setS ('notedismiss','false')#line:892
						debridit .debridIt ('update','all')#line:894
						traktit .traktIt ('update','all')#line:895
						checkidupdate ()#line:896
						wiz .log ("[Notifications] Complete",xbmc .LOGNOTICE )#line:898
				except Exception as e :#line:899
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:900
			else :wiz .log ("[Notifications] Text File not formated Correctly")#line:901
		else :wiz .log ("[Notifications] URL(%s): %s"%(NOTIFICATION ,url ),xbmc .LOGNOTICE )#line:902
	else :wiz .log ("[Notifications] Turned Off",xbmc .LOGNOTICE )#line:903
else :wiz .log ("[Notifications] Not Enabled",xbmc .LOGNOTICE )#line:904
wiz .log ("[Notifications2] Started",xbmc .LOGNOTICE )#line:906
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18":#line:907
	if not NOTIFY2 =='true':#line:908
		url =wiz .workingURL (NOTIFICATION2 )#line:909
		if url ==True :#line:910
			id ,msg =wiz .splitNotify (NOTIFICATION2 )#line:911
			if not id ==False :#line:912
				try :#line:913
					id =int (id );NOTEID2 =int (NOTEID2 )#line:914
					if id ==NOTEID2 :#line:915
						if NOTEDISMISS2 =='false':#line:916
							notify .notification2 (msg )#line:917
						else :wiz .log ("[Notifications2] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:918
					elif id >NOTEID2 :#line:919
						wiz .log ("[Notifications2] id: %s"%str (id ),xbmc .LOGNOTICE )#line:920
						wiz .setS ('noteid2',str (id ))#line:921
						wiz .setS ('notedismiss2','false')#line:922
						notify .notification2 (msg =msg )#line:923
						wiz .log ("[Notifications2] Complete",xbmc .LOGNOTICE )#line:924
				except Exception as e :#line:925
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:926
			else :wiz .log ("[Notifications2] Text File not formated Correctly")#line:927
		else :wiz .log ("[Notifications2] URL(%s): %s"%(NOTIFICATION2 ,url ),xbmc .LOGNOTICE )#line:928
	else :wiz .log ("[Notifications2] Turned Off",xbmc .LOGNOTICE )#line:929
else :wiz .log ("[Notifications2] Not Enabled",xbmc .LOGNOTICE )#line:930
wiz .log ("[Notifications3] Started",xbmc .LOGNOTICE )#line:932
if ENABLE =='Yes'and BUILDNAME ==" Kodi Premium 18"or BUILDNAME ==" Kodi Premium":#line:933
	if not NOTIFY3 =='true':#line:934
		url =wiz .workingURL (NOTIFICATION3 )#line:935
		if url ==True :#line:936
			id ,msg =wiz .splitNotify (NOTIFICATION3 )#line:937
			if not id ==False :#line:938
				try :#line:939
					id =int (id );NOTEID3 =int (NOTEID3 )#line:940
					if id ==NOTEID3 :#line:941
						if NOTEDISMISS3 =='false':#line:942
							notify .notification3 (msg )#line:943
						else :wiz .log ("[Notifications3] id[%s] Dismissed"%int (id ),xbmc .LOGNOTICE )#line:944
					elif id >NOTEID3 :#line:945
						wiz .log ("[Notifications3] id: %s"%str (id ),xbmc .LOGNOTICE )#line:946
						wiz .setS ('noteid3',str (id ))#line:947
						wiz .setS ('notedismiss3','false')#line:948
						notify .notification3 (msg =msg )#line:949
						wiz .log ("[Notifications3] Complete",xbmc .LOGNOTICE )#line:950
				except Exception as e :#line:951
					wiz .log ("Error on Notifications Window: %s"%str (e ),xbmc .LOGERROR )#line:952
			else :wiz .log ("[Notifications3] Text File not formated Correctly")#line:953
		else :wiz .log ("[Notifications3] URL(%s): %s"%(NOTIFICATION3 ,url ),xbmc .LOGNOTICE )#line:954
	else :wiz .log ("[Notifications3] Turned Off",xbmc .LOGNOTICE )#line:955
else :wiz .log ("[Notifications3] Not Enabled",xbmc .LOGNOTICE )#line:956
wiz .log ("[Trakt Data] Started",xbmc .LOGNOTICE )#line:957
if KEEPTRAKT =='true':#line:958
	if TRAKTSAVE <=str (TODAY ):#line:959
		wiz .log ("[Trakt Data] Saving all Data",xbmc .LOGNOTICE )#line:960
		traktit .autoUpdate ('all')#line:961
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:962
	else :#line:963
		wiz .log ("[Trakt Data] Next Auto Save isnt until: %s / TODAY is: %s"%(TRAKTSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:964
else :wiz .log ("[Trakt Data] Not Enabled",xbmc .LOGNOTICE )#line:965
wiz .log ("[Real Debrid Data] Started",xbmc .LOGNOTICE )#line:967
if KEEPREAL =='true':#line:968
	if REALSAVE <=str (TODAY ):#line:969
		wiz .log ("[Real Debrid Data] Saving all Data",xbmc .LOGNOTICE )#line:970
		debridit .autoUpdate ('all')#line:971
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:972
	else :#line:973
		wiz .log ("[Real Debrid Data] Next Auto Save isnt until: %s / TODAY is: %s"%(REALSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:974
else :wiz .log ("[Real Debrid Data] Not Enabled",xbmc .LOGNOTICE )#line:975
wiz .log ("[Login Data] Started",xbmc .LOGNOTICE )#line:977
if KEEPLOGIN =='true':#line:978
	if LOGINSAVE <=str (TODAY ):#line:979
		wiz .log ("[Login Data] Saving all Data",xbmc .LOGNOTICE )#line:980
		loginit .autoUpdate ('all')#line:981
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:982
	else :#line:983
		wiz .log ("[Login Data] Next Auto Save isnt until: %s / TODAY is: %s"%(LOGINSAVE ,str (TODAY )),xbmc .LOGNOTICE )#line:984
else :wiz .log ("[Login Data] Not Enabled",xbmc .LOGNOTICE )#line:985
wiz .log ("[Auto Clean Up] Started",xbmc .LOGNOTICE )#line:987
if AUTOCLEANUP =='true':#line:988
	service =False #line:989
	days =[TODAY ,TOMORROW ,THREEDAYS ,ONEWEEK ]#line:990
	feq =int (float (AUTOFEQ ))#line:991
	if AUTONEXTRUN <=str (TODAY )or feq ==0 :#line:992
		service =True #line:993
		next_run =days [feq ]#line:994
		wiz .setS ('nextautocleanup',str (next_run ))#line:995
	else :wiz .log ("[Auto Clean Up] Next Clean Up %s"%AUTONEXTRUN ,xbmc .LOGNOTICE )#line:996
	if service ==True :#line:997
		AUTOCACHE =wiz .getS ('clearcache')#line:998
		AUTOPACKAGES =wiz .getS ('clearpackages')#line:999
		AUTOTHUMBS =wiz .getS ('clearthumbs')#line:1000
		if AUTOCACHE =='true':wiz .log ('[Auto Clean Up] Cache: On',xbmc .LOGNOTICE );wiz .clearCache (True )#line:1001
		else :wiz .log ('[Auto Clean Up] Cache: Off',xbmc .LOGNOTICE )#line:1002
		if AUTOTHUMBS =='true':wiz .log ('[Auto Clean Up] Old Thumbs: On',xbmc .LOGNOTICE );wiz .oldThumbs ()#line:1003
		else :wiz .log ('[Auto Clean Up] Old Thumbs: Off',xbmc .LOGNOTICE )#line:1004
		if AUTOPACKAGES =='true':wiz .log ('[Auto Clean Up] Packages: On',xbmc .LOGNOTICE );wiz .clearPackagesStartup ()#line:1005
		else :wiz .log ('[Auto Clean Up] Packages: Off',xbmc .LOGNOTICE )#line:1006
else :wiz .log ('[Auto Clean Up] Turned off',xbmc .LOGNOTICE )#line:1007
wiz .setS ('kodi17iscrap','')#line:1009
for dirpath ,dirnames ,filenames in os .walk (packagesdir ):#line:1078
	count =0 #line:1079
	for f in filenames :#line:1080
		count +=1 #line:1081
		fp =os .path .join (dirpath ,f )#line:1082
		total_size +=os .path .getsize (fp )#line:1083
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1084
for dirpath2 ,dirnames2 ,filenames2 in os .walk (thumbnails ):#line:1091
	for f2 in filenames2 :#line:1092
		fp2 =os .path .join (dirpath2 ,f2 )#line:1093
		total_size2 +=os .path .getsize (fp2 )#line:1094
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1095
if int (total_sizetext2 )>filesize_thumb :#line:1097
		maintenance .deleteThumbnails ()#line:1099
total_sizetext ="%.0f"%(total_size /1024000.0 )#line:1101
total_sizetext2 ="%.0f"%(total_size2 /1024000.0 )#line:1102
if notify_mode =='true':xbmc .executebuiltin ('XBMC.Notification(%s, %s, %s, %s)'%('Maintenance Status','Packages: '+str (total_sizetext )+' MB' ' - Images: '+str (total_sizetext2 )+' MB','5000',iconpath ))#line:1104
time .sleep (3 )#line:1105
STARTP2 ()#line:1106
